package pe.agendaclara.app;

import android.content.*;

public final class SystemReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())){SharedPreferences.Editor e=Prefs.get(c).edit();for(String key:Prefs.get(c).getAll().keySet())if(key.startsWith("photo_tap_"))e.remove(key);e.apply();}
        PendingResult result=goAsync();
        new Thread(()->{try{CompletedTaskCleanup.run(c);Reminders.rebuild(c);TaskWidget.refresh(c);PhotoWidget.refresh(c);}finally{result.finish();}},"restore-reminders").start();
    }
}
