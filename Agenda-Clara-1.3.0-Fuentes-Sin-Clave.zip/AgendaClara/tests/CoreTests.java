import pe.agendaclara.app.*;
import java.time.*;
import java.util.*;

public final class CoreTests {
    static int checks=0;
    static ZoneId zone=ZoneId.of("America/Lima");
    static long now=ZonedDateTime.of(2026,10,21,8,0,0,0,zone).toInstant().toEpochMilli();
    static void check(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
    static MessageParser.Proposal parse(String s){return MessageParser.parseOne(s,now,zone,false);}
    static void date(MessageParser.Proposal p,int day,int h,int m){
        ZonedDateTime d=Instant.ofEpochMilli(p.due).atZone(zone);
        check(d.getDayOfMonth()==day&&d.getHour()==h&&d.getMinute()==m,"Unexpected date: "+d);
    }
    public static void main(String[] args){
        MessageParser.Proposal p=parse("Entregar informe mañana a las 3 pm");check(p.hasExplicitSchedule(),"Clear relative deadline");date(p,22,15,0);
        p=parse("Presentar trabajo el 23/10/2026 a las 8:30 am");check(p.hasExplicitSchedule(),"Numeric full date");date(p,23,8,30);
        p=parse("Reunión el 25 de octubre de 2026 a las 15:45");check(p.hasExplicitSchedule(),"Written date 24h");date(p,25,15,45);
        p=parse("Examen pasado mañana a las 12 am");check(p.hasExplicitSchedule(),"Midnight");date(p,23,0,0);
        p=parse("Enviar informe mañana a las 12 pm");check(p.hasExplicitSchedule(),"Noon");date(p,22,12,0);
        p=parse("Entregar trabajo mañana a las 8");check(!p.hasExplicitSchedule()&&p.ambiguous,"Missing AM/PM");
        p=parse("Tarea mañana");check(p.dateKnown&&!p.timeKnown&&!p.hasExplicitSchedule(),"No fabricated time");
        p=parse("Entregar informe a las 3 pm");check(!p.dateKnown&&!p.hasExplicitSchedule(),"No fabricated date");
        p=parse("Hola, ¿cómo estás?");check(!p.action&&!p.hasExplicitSchedule(),"Not a task");
        p=parse("No hay tarea mañana a las 5 pm");check(!p.action&&!p.hasExplicitSchedule(),"Negation");
        p=parse("Ya entregué el informe el 23/10/2026 a las 4 pm");check(!p.hasExplicitSchedule(),"Already completed");
        p=parse("Reunión cancelada mañana a las 5 pm");check(!p.hasExplicitSchedule(),"Cancelled");
        p=parse("¿Entregar informe mañana a las 3 pm?");check(!p.hasExplicitSchedule()&&p.ambiguous,"Question requires review");
        p=parse("Entregar informe el 31/02/2026 a las 3 pm");check(!p.hasExplicitSchedule()&&!p.dateKnown,"Invalid date");
        p=parse("Entregar informe el 23/10 a las 3 pm");check(!p.hasExplicitSchedule()&&p.ambiguous,"Missing year reviewed");
        p=parse("Entregar informe viernes a las 3 pm");check(!p.hasExplicitSchedule()&&p.dateKnown,"Weekday reviewed");
        p=parse("Entregar informe hoy a las 7 am");check(!p.hasExplicitSchedule(),"Past deadline");
        p=parse("Entregar informe mañana a las 3 pm o pasado mañana a las 4 pm");check(!p.hasExplicitSchedule(),"Multiple dates");
        p=parse("Entregar informe mañana a las 3 pm o a las 5 pm");check(!p.hasExplicitSchedule(),"Multiple hours");
        p=parse("Enviar informe el 23/10/2026 a las 8 de la mañana");check(p.hasExplicitSchedule(),"Morning isn't tomorrow");date(p,23,8,0);
        p=parse("Entregar informe en 3 días a las 15:00");check(p.hasExplicitSchedule(),"Relative days");date(p,24,15,0);
        p=parse("Entregar informe mañana a las 13 pm");check(!p.hasExplicitSchedule(),"Invalid 12 hour time");
        p=parse("Quizá entregar informe mañana a las 3 pm");check(!p.hasExplicitSchedule(),"Conditional");
        List<MessageParser.Proposal> many=MessageParser.parse("Entregar informe mañana a las 3 pm\nExamen pasado mañana a las 10 am",now,zone,false);check(many.size()==2&&many.get(0).hasExplicitSchedule()&&many.get(1).hasExplicitSchedule(),"Two separate tasks");
        Task finished=new Task();finished.done=true;finished.completedAt=now;
        check(TaskExpiryPolicy.expiresAt(finished)==now+3600000L,"Finish timestamp + one hour");
        check(!TaskExpiryPolicy.expired(finished,now+3599999L),"Preserve completed until the last millisecond");
        check(TaskExpiryPolicy.expired(finished,now+3600000L),"Delete at the 60-minute boundary");
        finished.done=false;check(!TaskExpiryPolicy.expired(finished,now+7200000L),"Never delete active tasks");
        finished.done=true;finished.completedAt=0;check(!TaskExpiryPolicy.expired(finished,now+7200000L),"Do not infer missing completion timestamp");
        Task t=new Task();t.due=now+86400000L;check(TaskLogic.status(t,now).equals("Urgente"),"1 day urgent");
        t.due=now+2*86400000L;check(TaskLogic.status(t,now).equals("Urgente"),"48h inclusive");
        t.due=now+3*86400000L;check(TaskLogic.status(t,now).equals("Pendiente"),"3 days pending");
        t.due=now+7*86400000L;check(TaskLogic.status(t,now).equals("Pendiente"),"7 days inclusive");
        t.due=now+8*86400000L;check(TaskLogic.status(t,now).equals("Próxima"),"8 days upcoming");
        t.due=now-1;check(TaskLogic.status(t,now).equals("Vencida"),"Overdue");
        t.done=true;check(TaskLogic.status(t,now).equals("Completada"),"Done wins");
        t.done=false;t.due=0;check(TaskLogic.status(t,now).equals("Sin fecha"),"Undated");
        t.urgent=true;check(TaskLogic.status(t,now).equals("Urgente"),"Manual urgent");
        t.urgent=false;t.due=now+10*86400000L;t.offsets="10080,4320,1440,60,0";t.repeatMinutes=0;
        check(TaskLogic.nextAlarm(t,now)==t.due-10080*60000L,"One week alert");
        long first=t.due-10080*60000L;
        check(TaskLogic.nextAlarm(t,first)==t.due-4320*60000L,"Advance to 3 day alert");
        t.repeatMinutes=1440;check(TaskLogic.nextAlarm(t,first)==first+86400000L,"Repeat daily from first alert");
        check(TaskLogic.nextAlarm(t,t.due-1)==t.due,"Final due alert");
        check(TaskLogic.nextAlarm(t,t.due)==-1,"No repeat past due");
        t.done=true;check(TaskLogic.nextAlarm(t,now)==-1,"No reminder for done");
        t.done=false;t.due=0;check(TaskLogic.nextAlarm(t,now)==-1,"No reminder for undated");
        t.due=now+86400000L;t.offsets="";check(TaskLogic.nextAlarm(t,now)==-1,"No offsets means no repeats");
        check(TaskLogic.offsets("60,60,-1,cat,0,5256001").size()==2,"Sanitize offsets");
        ZoneId ny=ZoneId.of("America/New_York");
        long dstNow=ZonedDateTime.of(2026,3,7,8,0,0,0,ny).toInstant().toEpochMilli();
        p=MessageParser.parseOne("Entregar informe mañana a las 2:30 am",dstNow,ny,false);check(!p.hasExplicitSchedule(),"DST gap needs review");
        check(!DoubleTapGate.completes(-1,1000,400),"First tap only");
        check(DoubleTapGate.completes(1000,1250,400),"Double tap recognized");
        check(!DoubleTapGate.completes(1000,1500,400),"Late tap is not double");
        check(DoubleTapGate.completes(1000,1000,400),"Queued distinct taps may share delivery time");
        check(!DoubleTapGate.completes(2000,1000,400),"Reboot or clock reset rejected");
        check(DoubleTapGate.completes(1000,1400,400),"Maximum window included");
        check(DoubleTapGate.completes(1000,1040,400),"Minimum window included");
        check(!DoubleTapGate.completes(1000,1401,400),"Outside window rejected");
        p=parse("Taller mañana a las 4 pm");check(p.action&&p.dateKnown&&p.timeKnown,"Workshop detected");
        p=parse("Evento mañana a las 2 pm");check(p.action,"Event detected");
        System.out.println("{\"checks\":"+checks+",\"passed\":"+checks+",\"failed\":0,\"scope\":\"JVM parser, urgency and reminder calculation\"}");
    }
}
