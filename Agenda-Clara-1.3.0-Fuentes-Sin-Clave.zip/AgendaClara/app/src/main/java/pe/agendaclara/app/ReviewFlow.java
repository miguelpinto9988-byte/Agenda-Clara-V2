package pe.agendaclara.app;

import android.content.*;
import java.time.ZoneId;
import java.util.*;

/** Incoming messages create review proposals only. Saving belongs to the editor. */
public final class ReviewFlow {
    public static final String DATA_CHANGED="pe.agendaclara.app.DATA_CHANGED";
    public static void changed(Context c){c.sendBroadcast(new Intent(DATA_CHANGED).setPackage(c.getPackageName()));}
    public static int receive(Context c,String chatKey,String text,long timestamp){
        Store db=Store.get(c);Store.Chat chat=db.getChat(chatKey);long now=System.currentTimeMillis();
        if(!Prefs.get(c).getBoolean("capture",false)||chat==null||!chat.selected)return 0;
        long since=Math.max(chat.selectedSince,Prefs.get(c).getLong("capture_since",now));
        if(timestamp<since||timestamp>now+60000L||now-timestamp>86400000L)return 0;
        int count=0;
        for(MessageParser.Proposal p:MessageParser.parse(text,timestamp,ZoneId.systemDefault(),false)){
            long id=db.offerProposal(p,"WhatsApp · "+chat.title,timestamp,Store.hash(chatKey+"\n"+timestamp+"\n"+p.original));
            if(id>0){Store.Inbox box=db.pending(id);if(box!=null)Reminders.showProposal(c,box);count++;}
        }
        if(count>0)changed(c);return count;
    }
    /** Linked history is explicitly authorized by chat selection; live notification guards remain separate. */
    public static int analyzeLinked(Context c,String chatKey,boolean historical,String liveMessageId){
        Store db=Store.get(c);Store.Chat chat=db.getChat(chatKey);
        if(chat==null||!chat.selected||chat.jid.isEmpty()||!Prefs.get(c).getBoolean("wa_reading",false))return 0;
        if(historical)db.trimMessages(chatKey,Prefs.get(c).getInt("wa_history_days",90));
        List<ConversationAnalyzer.Message> messages=db.messages(chatKey,historical?4000:120);
        if(!historical){Set<String> known=new HashSet<>();for(ConversationAnalyzer.Message m:messages)known.add(m.id);List<ConversationAnalyzer.Message> references=new ArrayList<>();for(ConversationAnalyzer.Message m:messages)if(!m.reply.isEmpty()&&!known.contains(m.reply)){ConversationAnalyzer.Message original=db.message(chatKey,m.reply);if(original!=null){references.add(original);known.add(original.id);}}messages.addAll(references);}
        List<ConversationAnalyzer.Finding> findings=ConversationAnalyzer.analyze(messages,ZoneId.systemDefault(),System.currentTimeMillis());
        Set<String> origins=new HashSet<>(),ids=new HashSet<>();for(ConversationAnalyzer.Message m:messages)ids.add(m.id);
        int count=0;
        for(ConversationAnalyzer.Finding f:findings){
            if(!db.getChat(chatKey).selected||!Prefs.get(c).getBoolean("wa_reading",false))return count;
            origins.add(Store.hash(chat.key+"\n"+f.key));long id=db.offerLinked(f,chat,historical);
            if(id>0){count++;if(!historical&&f.message.id.equals(liveMessageId)&&Prefs.get(c).getBoolean("wa_notify",true)){Store.Inbox box=db.pending(id);if(box!=null)Reminders.showProposal(c,box);}}
        }
        for(long id:db.withdrawMissing(chatKey,ids,origins))Reminders.cancelProposal(c,id);
        if(historical)db.trimMessages(chatKey,Prefs.get(c).getInt("wa_history_days",90));
        changed(c);return count;
    }
}
