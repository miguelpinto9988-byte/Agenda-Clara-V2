package pe.agendaclara.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class CompletedTaskReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        final PendingResult pending=goAsync();
        new Thread(()->{try{CompletedTaskCleanup.run(context);}finally{pending.finish();}},"cleanup-completed-tasks").start();
    }
}
