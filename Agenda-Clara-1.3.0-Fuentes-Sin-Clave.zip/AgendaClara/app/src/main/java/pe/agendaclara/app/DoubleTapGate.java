package pe.agendaclara.app;
/** Pure timing rule. The caller stores state per widget and uses elapsedRealtime. */
public final class DoubleTapGate {
    public static boolean completes(long previous,long now,int maxDelay){return previous>=0&&now>=previous&&now-previous<=maxDelay;}
}
