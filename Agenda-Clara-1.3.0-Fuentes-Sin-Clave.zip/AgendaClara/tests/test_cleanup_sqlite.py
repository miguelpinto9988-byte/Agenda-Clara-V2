#!/usr/bin/env python3
"""SQLite behavioral tests of the Android schema upgrade and cleanup predicate.
Does NOT simulate AlarmManager or Android installation.
"""
import sqlite3
from pathlib import Path

source = Path(__file__).resolve().parents[1] / 'app/src/main/java/pe/agendaclara/app/Store.java'
code=source.read_text(encoding='utf-8')
assert 'completed_at INTEGER NOT NULL DEFAULT 0' in code
assert 'AND completed_at<=?' in code
assert 'UPDATE tasks SET completed_at=? WHERE done=1 AND completed_at=0' in code

conn=sqlite3.connect(':memory:')
conn.execute('CREATE TABLE tasks(id INTEGER PRIMARY KEY,title TEXT, done INTEGER NOT NULL DEFAULT 0,completed_at INTEGER NOT NULL DEFAULT 0)')
now=1750000000000
conn.executemany('INSERT INTO tasks(id,title,done,completed_at) VALUES(?,?,?,?)',[
    (1,'Activa',0,0),
    (2,'Acaba de completarse',1,now-3599999),
    (3,'Completa hace una hora',1,now-3600000),
    (4,'Completa hace dos horas',1,now-7200000),
    (5,'Migrada sin timestamp',1,0),
])
count=conn.execute('DELETE FROM tasks WHERE done=1 AND completed_at>0 AND completed_at<=?',(now-3600000,)).rowcount
assert count==2,count
assert [r[0] for r in conn.execute('SELECT id FROM tasks ORDER BY id')]==[1,2,5]
# Backfill migrated rows for a full hour, rather than retroactively deleting unknown completions.
conn.execute('UPDATE tasks SET completed_at=? WHERE done=1 AND completed_at=0',(now,))
assert conn.execute('DELETE FROM tasks WHERE done=1 AND completed_at>0 AND completed_at<=?',(now-3600000,)).rowcount==0
assert conn.execute('DELETE FROM tasks WHERE done=1 AND completed_at>0 AND completed_at<=?',(now+3600000-3600000,)).rowcount==2
# Undo resets the timer and does not remove the task.
conn.execute('UPDATE tasks SET done=0, completed_at=0 WHERE id=1')
assert conn.execute('DELETE FROM tasks WHERE done=1 AND completed_at>0 AND completed_at<=?',(now+10000000,)).rowcount==0
assert conn.execute('SELECT id FROM tasks').fetchall()==[(1,)]
print('{"sqlite_checks":8,"passed":8,"failed":0,"scope":"schema migration and one-hour SQL predicate"}')
