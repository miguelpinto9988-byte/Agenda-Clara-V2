#include <jni.h>
#include <stdlib.h>
#include <string.h>

extern char *ACCommand(char *input);
extern char *ACPoll(void);

static jbyteArray result(JNIEnv *env, char *value) {
    if (!value) return NULL;
    size_t size = strlen(value);
    jbyteArray out = (*env)->NewByteArray(env, (jsize)size);
    if (out) (*env)->SetByteArrayRegion(env, out, 0, (jsize)size, (jbyte *)value);
    free(value);
    return out;
}

JNIEXPORT jbyteArray JNICALL Java_pe_agendaclara_app_WhatsAppNative_command(JNIEnv *env, jclass cls, jbyteArray data) {
    if (!data) return NULL;
    jsize size = (*env)->GetArrayLength(env, data);
    if (size < 2 || size > 1048576) return NULL;
    char *input = malloc((size_t)size + 1);
    if (!input) return NULL;
    (*env)->GetByteArrayRegion(env, data, 0, size, (jbyte *)input);
    input[size] = 0;
    char *response = ACCommand(input);
    free(input);
    return result(env, response);
}

JNIEXPORT jbyteArray JNICALL Java_pe_agendaclara_app_WhatsAppNative_poll(JNIEnv *env, jclass cls) {
    return result(env, ACPoll());
}
