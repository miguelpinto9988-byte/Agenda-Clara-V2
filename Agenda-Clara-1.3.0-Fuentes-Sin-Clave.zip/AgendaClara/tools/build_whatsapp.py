#!/usr/bin/env python3
"""Build the pinned, local WhatsApp transport. No backend or account is contacted by this build."""
import argparse, os, pathlib, subprocess, json, hashlib
p=argparse.ArgumentParser()
p.add_argument('--go',type=pathlib.Path,required=True)
p.add_argument('--ndk',type=pathlib.Path,required=True)
p.add_argument('--abis',default='arm64-v8a,x86_64')
a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[1]
ndk=a.ndk.resolve()/'toolchains/llvm/prebuilt/linux-x86_64/bin'
targets={'arm64-v8a':('arm64','aarch64-linux-android26-clang'),'x86_64':('amd64','x86_64-linux-android26-clang'),'armeabi-v7a':('arm','armv7a-linux-androideabi26-clang')}
report=[]
for abi in a.abis.split(','):
 arch,cc=targets[abi];out=root/'app/src/main/jniLibs'/abi/'libagendawa.so';out.parent.mkdir(parents=True,exist_ok=True)
 env=dict(os.environ,GOOS='android',GOARCH=arch,CGO_ENABLED='1',CC=str(ndk/cc),GOTOOLCHAIN='local',CGO_CFLAGS='-O2 -DSQLITE_TEMP_STORE=3',CGO_LDFLAGS='-Wl,-z,max-page-size=16384')
 if arch=='arm':env['GOARM']='7'
 subprocess.run([str(a.go.resolve()),'build','-buildvcs=false','-trimpath','-buildmode=c-shared','-tags','sqlite_omit_load_extension','-ldflags=-s -w','-o',str(out),'.'],cwd=root/'whatsapp-native',env=env,check=True)
 out.with_suffix('.h').unlink(missing_ok=True)
 report.append({'abi':abi,'size':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
 print(abi,out.stat().st_size,flush=True)
(root/'verification/whatsapp-native-build.json').write_text(json.dumps(report,indent=2)+'\n')
