package pe.agendaclara.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.service.notification.*;
import java.util.concurrent.*;

/** Discovers notification metadata; reads message bodies only for selected chats. */
public final class WhatsAppListener extends NotificationListenerService {
    public static final String REFRESH="pe.agendaclara.app.REFRESH_CHATS";
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private boolean registered=false;
    private final BroadcastReceiver refresh=new BroadcastReceiver(){public void onReceive(Context c,Intent i){scan();}};
    private void submit(Runnable r){if(!worker.isShutdown())try{worker.execute(r);}catch(RejectedExecutionException ignored){}}
    private boolean enabled(){return !Prefs.get(this).getBoolean("wa_reading",false)&&Prefs.get(this).getBoolean("discover",Prefs.get(this).getBoolean("capture",false));}
    @Override public void onCreate(){
        super.onCreate();IntentFilter f=new IntentFilter(REFRESH);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(refresh,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(refresh,f);
        registered=true;
    }
    @Override public void onListenerConnected(){super.onListenerConnected();scan();}
    private void scan(){
        if(!enabled())return;
        try{StatusBarNotification[] list=getActiveNotifications();if(list!=null)for(StatusBarNotification n:list)inspect(n,false);}catch(SecurityException|IllegalStateException ignored){}
    }
    @Override public void onNotificationPosted(StatusBarNotification sbn){inspect(sbn,true);}
    private String str(CharSequence s){return s==null?"":s.toString().trim();}
    private void inspect(StatusBarNotification sbn,boolean incoming){
        if(sbn==null||!enabled())return;String pkg=sbn.getPackageName();
        if(!"com.whatsapp".equals(pkg)&&!"com.whatsapp.w4b".equals(pkg))return;
        Notification n=sbn.getNotification();if(n==null||(n.flags&Notification.FLAG_GROUP_SUMMARY)!=0||sbn.isOngoing()||n.extras==null)return;
        Bundle e=n.extras;String group=str(e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));
        String title=group.isEmpty()?str(e.getCharSequence(Notification.EXTRA_TITLE)):group;
        if(title.isEmpty()||title.length()>180||title.matches("(?i).*\\b\\d+ (chats|mensajes|messages).*"))return;
        final String name=title;final String key=Store.chatKey(pkg,n.getShortcutId(),title);
        submit(()->{
            Store db=Store.get(this);if(db.observeChat(key,pkg,name,!group.isEmpty(),System.currentTimeMillis()))ReviewFlow.changed(this);
            Store.Chat chat=db.getChat(key);
            if(!incoming||!Prefs.get(this).getBoolean("capture",false)||chat==null||!chat.selected)return;
            // Intentionally after selection: active scans never extract existing messages.
            Parcelable[] messages=e.getParcelableArray(Notification.EXTRA_MESSAGES);
            if(messages!=null&&messages.length>0){
                if(Build.VERSION.SDK_INT>=30){
                    for(Notification.MessagingStyle.Message msg:Notification.MessagingStyle.Message.getMessagesFromBundleArray(messages)){
                        String text=str(msg.getText());if(!text.isEmpty())ReviewFlow.receive(this,key,text,msg.getTimestamp()>0?msg.getTimestamp():sbn.getPostTime());
                    }
                }else for(Parcelable item:messages)if(item instanceof Bundle){Bundle msg=(Bundle)item;String text=str(msg.getCharSequence("text"));if(!text.isEmpty())ReviewFlow.receive(this,key,text,msg.getLong("time",sbn.getPostTime()));}
            }else{
                String text=str(e.getCharSequence(Notification.EXTRA_BIG_TEXT));if(text.isEmpty())text=str(e.getCharSequence(Notification.EXTRA_TEXT));
                if(!text.isEmpty())ReviewFlow.receive(this,key,text,sbn.getPostTime());
            }
        });
    }
    @Override public void onDestroy(){if(registered)unregisterReceiver(refresh);worker.shutdown();super.onDestroy();}
}
