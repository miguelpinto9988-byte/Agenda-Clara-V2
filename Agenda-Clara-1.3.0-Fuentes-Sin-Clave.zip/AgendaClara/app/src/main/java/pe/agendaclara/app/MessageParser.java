package pe.agendaclara.app;

import java.text.Normalizer;
import java.time.*;
import java.util.*;
import java.util.regex.*;

/** Deterministic Spanish parser. A proposal is not a verified assignment. */
public final class MessageParser {
    private static final Pattern RX_0=Pattern.compile("\\b(\\d{1,2})[/-](\\d{1,2})(?:[/-](\\d{2}|\\d{4}))?\\b");
    private static final Pattern RX_1=Pattern.compile("\\b(pasado manana|manana|hoy)\\b");
    private static final Pattern RX_2=Pattern.compile("\\b(?:dentro de|en)\\s+(\\d{1,3})\\s+(dias?|semanas?)\\b");
    private static final Pattern RX_3=Pattern.compile("\\b(?:(?:a las?|hora)\\s+)?(\\d{1,2})(?::([0-5]\\d))?\\s*(a\\.?\\s*m\\.?|p\\.?\\s*m\\.?|h(?:oras?)?\\b|de la manana|de la tarde|de la noche)?",Pattern.CASE_INSENSITIVE);
    public static final class Proposal {
        public String title="",original="",reason="";
        public long due=0;
        public boolean action,dateKnown,timeKnown,ambiguous;
        public boolean hasExplicitSchedule(){return action&&dateKnown&&timeKnown&&!ambiguous&&due>0;}
    }
    static String normalize(String s) {
        return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT);
    }
    public static List<Proposal> parse(String text,long now,ZoneId zone,boolean manual) {
        List<Proposal> out=new ArrayList<>();
        if(text==null||text.trim().isEmpty())return out;
        String bounded=text.length()>12000?text.substring(0,12000):text;
        String[] lines=bounded.split("(?:\\r?\\n)+|;\\s*");
        for(String line:lines) {
            if(line.trim().isEmpty())continue;
            Proposal p=parseOne(line,now,zone,manual);
            if(p.action||manual)out.add(p);
            if(out.size()==40)break;
        }
        if(!manual&&lines.length>1&&out.size()<=1){
            Proposal combined=parseOne(bounded,now,zone,false);
            if(combined.action){out.clear();out.add(combined);}
        }
        return out;
    }
    public static Proposal parseOne(String text,long now,ZoneId zone,boolean manual) {
        Proposal p=new Proposal();p.original=text.trim();
        p.title=p.original.replaceFirst("^\\s*(?:[-*•]|\\d+[.)])\\s*","");
        if(p.title.length()>180)p.title=p.title.substring(0,177)+"…";
        String s=normalize(text);
        ActivityClassifier.Result classification=ActivityClassifier.classify(text,false);
        if(classification.closed&&!manual){p.ambiguous=true;p.reason=classification.reason;return p;}
        if(classification.uncertain){p.ambiguous=true;p.reason=classification.reason;}
        LocalDate today=Instant.ofEpochMilli(now).atZone(zone).toLocalDate(),date=null;
        int dateMatches=0;
        Matcher explicit=RX_0.matcher(s);
        while(explicit.find()){
            dateMatches++;
            try{
                int year=explicit.group(3)==null?today.getYear():Integer.parseInt(explicit.group(3));
                if(year<100)year+=2000;
                date=LocalDate.of(year,Integer.parseInt(explicit.group(2)),Integer.parseInt(explicit.group(1)));
                if(explicit.group(3)==null){p.ambiguous=true;p.reason="La fecha no incluye año. Confírmalo.";}
            }catch(DateTimeException e){p.ambiguous=true;p.reason="Fecha no válida.";date=null;}
        }
        String[] months={"enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"};
        Matcher words=Pattern.compile("\\b(\\d{1,2})\\s+de\\s+("+String.join("|",months)+"|setiembre)(?:\\s+(?:de|del)\\s+(\\d{4}))?\\b").matcher(s);
        while(words.find()){
            dateMatches++;
            int month=Arrays.asList(months).indexOf(words.group(2))+1;if(words.group(2).equals("setiembre"))month=9;
            try{
                date=LocalDate.of(words.group(3)==null?today.getYear():Integer.parseInt(words.group(3)),month,Integer.parseInt(words.group(1)));
                if(words.group(3)==null){p.ambiguous=true;p.reason="La fecha no incluye año. Confírmalo.";}
            }catch(DateTimeException e){date=null;p.ambiguous=true;p.reason="Fecha no válida.";}
        }
        Matcher rel=RX_1.matcher(s);
        while(rel.find()){
            // "de/por/en la mañana" is a time of day, not tomorrow.
            String before=s.substring(Math.max(0,rel.start()-7),rel.start());
            if(rel.group(1).equals("manana")&&before.matches(".*(?:de la |por la |en la )$"))continue;
            dateMatches++;date=today.plusDays(rel.group(1).equals("pasado manana")?2:rel.group(1).equals("manana")?1:0);
        }
        if(dateMatches==0){
            Matcher in=RX_2.matcher(s);
            if(in.find()){date=today.plusDays(Long.parseLong(in.group(1))*(in.group(2).startsWith("semana")?7:1));dateMatches++;}
        }
        if(dateMatches==0){
            String[] days={"lunes","martes","miercoles","jueves","viernes","sabado","domingo"};
            for(int i=0;i<7;i++)if(Pattern.compile("\\b"+days[i]+"\\b").matcher(s).find()){
                int add=(i+1-today.getDayOfWeek().getValue()+7)%7;
                date=today.plusDays(add);dateMatches++;
                p.ambiguous=true;p.reason="Confirma la fecha del día de la semana.";
            }
        }
        if(dateMatches>1){p.ambiguous=true;p.reason="Se encontraron varias referencias de fecha. Revisa la fecha límite.";}
        p.dateKnown=date!=null;
        Matcher time=RX_3.matcher(s);
        int timeMatches=0,h=0,m=0;
        while(time.find()){
            String raw=time.group();
            boolean hasPrefix=raw.matches("^(a las?|hora)\\s+.*"),hasColon=time.group(2)!=null,hasSuffix=time.group(3)!=null;
            if(!hasPrefix&&!hasColon&&!hasSuffix)continue;
            int hour=Integer.parseInt(time.group(1)),minute=time.group(2)==null?0:Integer.parseInt(time.group(2));
            if(hour>23){p.ambiguous=true;p.reason="Hora no válida.";continue;}
            String suffix=time.group(3)==null?"":time.group(3).replaceAll("[.\\s]","");
            boolean am=suffix.startsWith("a")||suffix.contains("manana");
            boolean pm=suffix.startsWith("p")||suffix.contains("tarde")||suffix.contains("noche");
            if((am||pm)&&(hour<1||hour>12)){p.ambiguous=true;p.reason="Hora de 12 horas no válida.";continue;}
            timeMatches++;
            if(am||pm)hour=(hour%12)+(pm?12:0);
            else if(hour>=1&&hour<=12&&!suffix.startsWith("h")){
                p.ambiguous=true;p.reason="Falta indicar a. m. o p. m.";
            }
            h=hour;m=minute;p.timeKnown=true;
        }
        if(timeMatches>1){p.ambiguous=true;p.reason="Se encontraron varias horas. Elige la hora límite.";}
        if(date!=null){
            try{
                LocalDateTime ldt=date.atTime(p.timeKnown?h:0,p.timeKnown?m:0);
                List<ZoneOffset> valid=zone.getRules().getValidOffsets(ldt);
                if(valid.size()!=1){p.ambiguous=true;p.reason="La hora coincide con un cambio horario.";}
                p.due=ldt.atZone(zone).toInstant().toEpochMilli();
                if(p.timeKnown&&p.due<=now){p.ambiguous=true;p.reason="La fecha y hora detectadas ya pasaron.";}
            }catch(DateTimeException e){p.due=0;p.ambiguous=true;p.reason="No se pudo interpretar la fecha.";}
        }
        classification=ActivityClassifier.classify(text,p.dateKnown);
        p.action=classification.candidate;
        if(classification.closed||classification.uncertain){p.action=false;p.ambiguous=true;}
        String scheduleReason=p.reason;
        if(!p.dateKnown)scheduleReason="Falta la fecha: elígela antes de programar.";
        else if(!p.timeKnown)scheduleReason="Falta la hora: elígela o indica fin del día.";
        else if(scheduleReason.isEmpty())scheduleReason="Confirma la fecha y la hora antes de guardar.";
        p.reason=(classification.reason.isEmpty()?"Interpretación local: revisa el contenido.":classification.reason)+" "+scheduleReason;
        return p;
    }
}
