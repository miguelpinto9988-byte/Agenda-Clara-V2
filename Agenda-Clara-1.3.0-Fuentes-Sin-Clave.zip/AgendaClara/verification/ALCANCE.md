# Verificación de Agenda Clara 1.2

Esta carpeta corresponde al APK 1.2 con versionCode 3 y el certificado original. No contiene conversaciones ni cuentas personales.

## Comprobaciones terminadas

- `core-tests-v12.jsonl`: 60 comprobaciones de fechas, avisos, prioridad y doble toque, más 76 del filtro, contexto, fechas históricas e importación. La prueba sintética de 4.000 mensajes tardó 277 ms en la JVM del contenedor; esta medición no representa el rendimiento de un teléfono.
- `native-transport-tests.jsonl`: tres pruebas Go con detector de carreras activado, SQLite local y mensajes sintéticos: filtrar historial antes de extraer texto de grupos sin autorización, bloquear consultas anteriores sin permiso y evitar persistir cuerpos inline de historial ajeno a la selección. No inicia sesión ni envía solicitudes a una cuenta real.
- `static-audit-v12.json`: 74 comprobaciones de fuentes, permisos, componentes privados, ausencia de guardado automático en rutas entrantes y estructura del APK.
- `native-elf.json` y `whatsapp-native-build.json`: biblioteca JNI real compilada para ARM64 y x86_64, símbolos JNI y segmentos alineados a 16 KB.
- `build-and-signature-v12.txt`: firma v2/v3 y certificado SHA-256 original `9232f9e8bc93197d2d402800d11a6c1027b6f2f42210c4f12ea237420df96eb3`.

## Pruebas Android

La ejecución completa pasó **56 comprobaciones** en el emulador Android API 35, sobre el APK cuyo SHA-256 consta en `runtime-v12.json`. Los resultados están en `runtime-v12.txt` y `runtime-v12.json`.

Se verificaron la migración y conservación de datos, notificaciones reales Agregar/No agregar, guardado solo desde el editor, consentimiento de grupo y cambio de color, interpretación de historial sintético respecto de su fecha original, exclusión de una pregunta, cancelación citada, pausa, revocación y borrado de textos, conservación de tareas, cota de 4.000 mensajes, carga de JNI real y SQLite privado sin cuenta, bloqueo de petición histórica sin consentimiento, lectura y escritura de un calendario local con ID estable y doble toque en un widget real de Android. El grupo de comunidad de la prueba se introdujo como metadato sintético; esa comprobación valida la lista antes de recibir mensajes, no la consulta a una cuenta real.

Los intentos anteriores se conservan con su número y no se presentan como ejecuciones completas.

El primer intento verificó migración a base v3 y conservación de la tarea sembrada en la versión original, flujo real de notificaciones Agregar/No agregar, editor y ausencia de guardado automático. Se detuvo al buscar un botón del diálogo por accesibilidad; se observó un ANR del lanzador Quickstep en el emulador sin aceleración. El segundo intento tampoco pudo pulsarlo mediante accesibilidad. El ensayo actual pulsa el botón real del diálogo dentro de la actividad, al igual que las pruebas del editor. El tercer intento se cerró por una llamada anidada de la instrumentación al hilo principal, localizada en `ReviewInstrumentation.java`; se corrigió el ensayo. No llegó a cargar el módulo JNI. Los intentos interrumpidos no validaron el resto del flujo.

## Pendiente de verificar con tus cuentas

No se ha enlazado una cuenta personal de WhatsApp. No se han observado tus comunidades ni tus chats, recibido un historial real, solicitado páginas reales al teléfono principal ni recibido una propuesta a partir de tus mensajes. Las consultas de catálogo e historial están implementadas y compiladas, pero su resultado con tu cuenta requiere probarlo en el teléfono.

No se ha autenticado una cuenta Google en el emulador. Las comprobaciones del Calendar Provider, cuando consten en el informe Android, utilizan un calendario local sintético; no demuestran una subida a Google.

No se ha probado ARM64 en un teléfono físico ni se ha medido consumo de batería. Los filtros locales no ofrecen comprensión completa del lenguaje ni identificación segura de qué tareas siguen pendientes. El historial está limitado por la sincronización de WhatsApp, el periodo elegido y la cota local de 4.000 mensajes por grupo. El código de la vinculación es no oficial; la app y la guía muestran el aviso de WhatsApp antes de usarlo.
