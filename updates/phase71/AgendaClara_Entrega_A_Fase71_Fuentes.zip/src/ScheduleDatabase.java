package pe.agendaclara.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

/** Version 2: up to ten isolated schedules and a stable per-schedule course directory.
 * The original sessions and ids are preserved in-place in onUpgrade. */
public final class ScheduleDatabase extends SQLiteOpenHelper {
    public static final int MAX_SCHEDULES=10;
    private static volatile ScheduleDatabase instance;
    private final Context context;
    public static ScheduleDatabase get(Context c){if(instance==null){synchronized(ScheduleDatabase.class){if(instance==null)instance=new ScheduleDatabase(c.getApplicationContext());}}return instance;}
    private ScheduleDatabase(Context c){super(c,"class_schedule.db",null,2);context=c.getApplicationContext();}
    public static final class Timetable {
        public final long id;
        public final String name;
        Timetable(long id,String name){this.id=id;this.name=name;}
    }
    public static final class Course {
        public final long id,scheduleId;
        public final String name;
        Course(long id,long scheduleId,String name){this.id=id;this.scheduleId=scheduleId;this.name=name;}
    }
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS schedules (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE COLLATE NOCASE)");
        db.execSQL("INSERT INTO schedules(id,name) VALUES(1,'Mi horario')");
        db.execSQL("CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT,course TEXT NOT NULL,day INTEGER NOT NULL,start_min INTEGER NOT NULL,end_min INTEGER NOT NULL,room TEXT NOT NULL DEFAULT '',teacher TEXT NOT NULL DEFAULT '',notes TEXT NOT NULL DEFAULT '',color INTEGER NOT NULL,reminder INTEGER NOT NULL DEFAULT 10,enabled INTEGER NOT NULL DEFAULT 1,schedule_id INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE INDEX IF NOT EXISTS schedule_day_start ON sessions(day,start_min)");
        db.execSQL("CREATE INDEX IF NOT EXISTS schedule_group_idx ON sessions(schedule_id,day,start_min)");
        db.execSQL("CREATE TABLE IF NOT EXISTS schedule_courses (id INTEGER PRIMARY KEY AUTOINCREMENT,schedule_id INTEGER NOT NULL,name TEXT NOT NULL,identity TEXT NOT NULL,UNIQUE(schedule_id,identity))");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int old,int current){
        if(old<2){
            db.execSQL("CREATE TABLE IF NOT EXISTS schedules (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE COLLATE NOCASE)");
            db.execSQL("INSERT OR IGNORE INTO schedules(id,name) VALUES(1,'Mi horario')");
            db.execSQL("ALTER TABLE sessions ADD COLUMN schedule_id INTEGER NOT NULL DEFAULT 1");
            db.execSQL("CREATE INDEX IF NOT EXISTS schedule_group_idx ON sessions(schedule_id,day,start_min)");
            db.execSQL("CREATE TABLE IF NOT EXISTS schedule_courses (id INTEGER PRIMARY KEY AUTOINCREMENT,schedule_id INTEGER NOT NULL,name TEXT NOT NULL,identity TEXT NOT NULL,UNIQUE(schedule_id,identity))");
            try(Cursor c=db.rawQuery("SELECT DISTINCT course FROM sessions",null)){
                while(c.moveToNext()){
                    String name=c.getString(0);String key=ScheduleCourseColors.identity(name);
                    if(!key.isEmpty()){ContentValues values=new ContentValues();values.put("schedule_id",1);values.put("name",name);values.put("identity",key);db.insertWithOnConflict("schedule_courses",null,values,SQLiteDatabase.CONFLICT_IGNORE);}
                }
            }
        }
    }
    private ScheduleEntry read(Cursor c){ScheduleEntry s=new ScheduleEntry();s.id=c.getLong(0);s.course=c.getString(1);s.day=c.getInt(2);s.start=c.getInt(3);s.end=c.getInt(4);s.room=c.getString(5);s.teacher=c.getString(6);s.notes=c.getString(7);s.color=c.getInt(8);s.reminder=c.getInt(9);s.enabled=c.getInt(10)!=0;s.scheduleId=c.getLong(11);return s;}
    private static final String SESSIONS="SELECT id,course,day,start_min,end_min,room,teacher,notes,color,reminder,enabled,schedule_id FROM sessions";
    public synchronized List<ScheduleEntry> all(){return list(null,null);}
    public synchronized List<ScheduleEntry> forSchedule(long id){return list("schedule_id=?",new String[]{Long.toString(id)});}
    private List<ScheduleEntry> list(String where,String[] args){ArrayList<ScheduleEntry> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery(SESSIONS+(where==null?"":" WHERE "+where)+" ORDER BY day,start_min,course",args)){while(c.moveToNext())out.add(read(c));}return out;}
    public synchronized ScheduleEntry find(long id){try(Cursor c=getReadableDatabase().rawQuery(SESSIONS+" WHERE id=?",new String[]{Long.toString(id)})){return c.moveToFirst()?read(c):null;}}
    public synchronized List<Timetable> schedules(){ArrayList<Timetable> result=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name FROM schedules ORDER BY id",null)){while(c.moveToNext())result.add(new Timetable(c.getLong(0),c.getString(1)));}return result;}
    public synchronized Timetable schedule(long id){for(Timetable item:schedules())if(item.id==id)return item;return null;}
    public synchronized boolean ownsCategory(String name){if(name==null)return false;for(Timetable t:schedules())if(t.name.equalsIgnoreCase(name))return true;return false;}
    public synchronized void ensureCategories(){
        for(Timetable t:schedules()){
            boolean found=false;
            for(CategoryRegistry.Entry item:CategoryRegistry.all(context))if(item.name.equalsIgnoreCase(t.name)){found=true;break;}
            if(!found)CategoryRegistry.save(context,null,t.name,CategoryRegistry.COLORS[(int)(t.id%CategoryRegistry.COLORS.length)],"class_schedule");
        }
    }
    public synchronized long activeId(){long id=context.getSharedPreferences("schedule_settings",0).getLong("active_schedule",1);List<Timetable> all=schedules();for(Timetable entry:all)if(entry.id==id)return id;return all.isEmpty()?1:all.get(0).id;}
    public synchronized void setActive(long id){if(schedule(id)==null)throw new IllegalArgumentException("Horario inexistente");context.getSharedPreferences("schedule_settings",0).edit().putLong("active_schedule",id).apply();}
    private static String cleanName(String name){if(name==null)return "";String s=name.trim().replaceAll("\\s+"," ");return s.length()>28||s.isEmpty()||s.matches("(?s).*\\p{Cntrl}.*")?"":s;}
    public synchronized long create(String title){
        String name=cleanName(title);if(name.isEmpty()||"General".equalsIgnoreCase(name)||schedules().size()>=MAX_SCHEDULES||nameTaken(name,0))return -1;
        if(!CategoryRegistry.save(context,null,name,CategoryRegistry.COLORS[(schedules().size()+1)%CategoryRegistry.COLORS.length],"class_schedule"))return -1;
        ContentValues cv=new ContentValues();cv.put("name",name);
        long id=getWritableDatabase().insert("schedules",null,cv);
        if(id<1){CategoryRegistry.delete(context,name);return -1;}
        setActive(id);return id;
    }
    private boolean nameTaken(String name,long except){for(Timetable t:schedules())if(t.id!=except&&t.name.equalsIgnoreCase(name))return true;for(CategoryRegistry.Entry e:CategoryRegistry.all(context))if(e.name.equalsIgnoreCase(name)&&schedule(except)==null)return true;return false;}
    public synchronized boolean rename(long id,String title){
        Timetable old=schedule(id);String name=cleanName(title);
        if(old==null||name.isEmpty()||"General".equalsIgnoreCase(name)||nameTaken(name,id))return false;
        if(old.name.equalsIgnoreCase(name))return true;
        if(!CategoryRegistry.renameScheduleCategory(context,old.name,name))return false;
        ContentValues cv=new ContentValues();cv.put("name",name);
        if(getWritableDatabase().update("schedules",cv,"id=?",new String[]{Long.toString(id)})==1)return true;
        CategoryRegistry.renameScheduleCategory(context,name,old.name);return false;
    }
    public synchronized boolean deleteSchedule(long id){
        Timetable old=schedule(id);if(old==null||schedules().size()<=1)return false;
        long previousActive=activeId();
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            db.delete("sessions","schedule_id=?",new String[]{Long.toString(id)});
            db.delete("schedule_courses","schedule_id=?",new String[]{Long.toString(id)});
            if(db.delete("schedules","id=?",new String[]{Long.toString(id)})!=1)return false;
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        CategoryRegistry.deleteScheduleCategory(context,old.name);
        if(previousActive==id)setActive(schedules().get(0).id);
        return true;
    }
    public synchronized List<Course> courses(long scheduleId){ArrayList<Course> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT id,schedule_id,name FROM schedule_courses WHERE schedule_id=? ORDER BY name COLLATE NOCASE",new String[]{Long.toString(scheduleId)})){while(c.moveToNext())out.add(new Course(c.getLong(0),c.getLong(1),c.getString(2)));}return out;}
    private void syncCourses(SQLiteDatabase db,long scheduleId){
        LinkedHashMap<String,String> desired=new LinkedHashMap<>();
        try(Cursor c=db.rawQuery("SELECT course FROM sessions WHERE schedule_id=? ORDER BY id",new String[]{Long.toString(scheduleId)})){
            while(c.moveToNext()){String name=c.getString(0),key=ScheduleCourseColors.identity(name);if(!key.isEmpty())desired.putIfAbsent(key,name);}
        }
        for(Map.Entry<String,String> e:desired.entrySet()){
            ContentValues v=new ContentValues();v.put("schedule_id",scheduleId);v.put("identity",e.getKey());v.put("name",e.getValue());db.insertWithOnConflict("schedule_courses",null,v,SQLiteDatabase.CONFLICT_IGNORE);
        }
        // Unused course labels are removed; no task information is deleted.
        try(Cursor c=db.rawQuery("SELECT id,identity FROM schedule_courses WHERE schedule_id=?",new String[]{Long.toString(scheduleId)})){
            while(c.moveToNext())if(!desired.containsKey(c.getString(1)))db.delete("schedule_courses","id=?",new String[]{Long.toString(c.getLong(0))});
        }
    }
    private static boolean allowedReminder(int n){return n==0||n==5||n==10||n==15||n==30||n==60;}
    private ContentValues values(ScheduleEntry s){ContentValues v=new ContentValues();v.put("course",s.course.trim());v.put("day",s.day);v.put("start_min",s.start);v.put("end_min",s.end);v.put("room",s.room);v.put("teacher",s.teacher);v.put("notes",s.notes);v.put("color",s.color);v.put("reminder",s.reminder);v.put("enabled",s.enabled?1:0);v.put("schedule_id",s.scheduleId);return v;}
    public synchronized boolean save(ScheduleEntry s){
        if(!ScheduleEntry.valid(s)||!allowedReminder(s.reminder)||schedule(s.scheduleId)==null)return false;
        SQLiteDatabase db=getWritableDatabase();long previousId=s.id;long priorSchedule=s.scheduleId;
        if(previousId>0){ScheduleEntry prior=find(previousId);if(prior==null||prior.scheduleId!=s.scheduleId)return false;}
        db.beginTransaction();boolean success=false;try{
            if(previousId==0){s.id=db.insert("sessions",null,values(s));success=s.id>0;}
            else success=db.update("sessions",values(s),"id=?",new String[]{Long.toString(previousId)})==1;
            if(success){syncCourses(db,priorSchedule);db.setTransactionSuccessful();}
        }finally{db.endTransaction();}return success;
    }
    public synchronized int recolorSameCourse(String title,int color){return recolorSameCourse(title,color,activeId());}
    public synchronized int recolorSameCourse(String title,int color,long scheduleId){int modified=0;SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
        for(ScheduleEntry s:forSchedule(scheduleId))if(ScheduleCourseColors.same(title,s.course)&&s.color!=color){ContentValues cv=new ContentValues();cv.put("color",color);modified+=db.update("sessions",cv,"id=?",new String[]{Long.toString(s.id)});}
        db.setTransactionSuccessful();
    }finally{db.endTransaction();}return modified;}
    public synchronized void delete(long id){ScheduleEntry old=find(id);if(old==null)return;SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{db.delete("sessions","id=?",new String[]{Long.toString(id)});syncCourses(db,old.scheduleId);db.setTransactionSuccessful();}finally{db.endTransaction();}}
    public synchronized int importReviewed(List<ScheduleEntry> items){
        if(items==null||items.isEmpty())return 0;
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();int inserted=0;try{
            HashMap<Long,List<ScheduleEntry>> groups=new HashMap<>();
            for(ScheduleEntry s:items)if(s!=null&&schedule(s.scheduleId)!=null)groups.computeIfAbsent(s.scheduleId,k->new ArrayList<>()).add(s);
            for(Map.Entry<Long,List<ScheduleEntry>> group:groups.entrySet()){
                List<ScheduleEntry> existing=forSchedule(group.getKey());ScheduleCourseColors.align(group.getValue(),existing);
                for(ScheduleEntry s:group.getValue()){
                    if(!ScheduleEntry.valid(s)||!allowedReminder(s.reminder))continue;
                    boolean duplicate=false;for(ScheduleEntry old:existing)if(old.day==s.day&&old.start==s.start&&old.end==s.end&&ScheduleCourseColors.same(old.course,s.course)){duplicate=true;break;}
                    if(duplicate)continue;
                    if(db.insert("sessions",null,values(s))>0){inserted++;existing.add(s.copy());}
                }syncCourses(db,group.getKey());
            }db.setTransactionSuccessful();
        }finally{db.endTransaction();}return inserted;
    }
}
