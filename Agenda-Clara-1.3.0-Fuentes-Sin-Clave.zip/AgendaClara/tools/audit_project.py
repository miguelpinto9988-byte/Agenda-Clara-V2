#!/usr/bin/env python3
"""Static delivery audit. This does not test phone accounts or system permissions."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile
from xml.etree import ElementTree as ET


def audit(root, apk):
    ns = "{http://schemas.android.com/apk/res/android}"
    manifest = ET.parse(root / "app/src/main/AndroidManifest.xml").getroot()
    app = manifest.find("application")
    checks = []

    def add(name, passed):
        checks.append({"name": name, "passed": bool(passed)})

    permissions = {x.get(ns + "name") for x in manifest.findall("uses-permission")}
    for name in ["POST_NOTIFICATIONS", "SCHEDULE_EXACT_ALARM", "READ_CALENDAR", "WRITE_CALENDAR", "RECEIVE_BOOT_COMPLETED"]:
        add("Permission " + name, "android.permission." + name in permissions)
    add("Internet for direct linked-device connection", "android.permission.INTERNET" in permissions)
    add("Cleartext network disabled", app.get(ns+"usesCleartextTraffic")=="false")
    add("Visible special-use service permission", "android.permission.FOREGROUND_SERVICE_SPECIAL_USE" in permissions)
    add("Private data not backed up", app.get(ns + "allowBackup") == "false")
    sdk = manifest.find("uses-sdk")
    add("Minimum Android 8, target Android 15", sdk.get(ns + "minSdkVersion") == "26" and sdk.get(ns + "targetSdkVersion") == "35")
    main = next((a for a in app.findall("activity") if a.get(ns + "name") == ".MainActivity"), None)
    add("Exported launch/share activity", main is not None and main.get(ns + "exported") == "true")
    filters = main.findall("intent-filter") if main is not None else []
    add("Launcher intent", any(any(c.get(ns + "name") == "android.intent.category.LAUNCHER" for c in f.findall("category")) for f in filters))
    add("Share text input", any(any(c.get(ns + "name") == "android.intent.action.SEND" for c in f.findall("action")) and any(c.get(ns + "mimeType") == "text/plain" for c in f.findall("data")) for f in filters))
    services = {s.get(ns + "name"): s for s in app.findall("service")}
    listener = services.get(".WhatsAppListener")
    add("Notification listener protected", listener is not None and listener.get(ns + "permission") == "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE" and listener.get(ns + "exported") == "false")
    linked=services.get(".WhatsAppSessionService")
    add("Linked session service private and declared", linked is not None and linked.get(ns+"exported")=="false" and linked.get(ns+"foregroundServiceType")=="specialUse")
    widget_service = services.get(".TaskWidgetService")
    add("Collection service protected", widget_service is not None and widget_service.get(ns + "permission") == "android.permission.BIND_REMOTEVIEWS")
    receivers = {r.get(ns + "name"): r for r in app.findall("receiver")}
    for name, info in [(".TaskWidget", "task_widget_info"), (".PhotoWidget", "photo_widget_info")]:
        r = receivers.get(name)
        add(name + " registered", r is not None and any(m.get(ns + "resource") == "@xml/" + info for m in r.findall("meta-data")))
        xml = ET.parse(root / ("app/src/main/res/xml/" + info + ".xml")).getroot()
        add(name + " resizable", xml.get(ns + "resizeMode") == "horizontal|vertical")
    for kind in ["activity", "service", "receiver"]:
        for node in app.findall(kind):
            name = node.get(ns + "name", "")
            add("Source " + name, (root / ("app/src/main/java/pe/agendaclara/app/" + name.lstrip(".") + ".java")).is_file())
    for xml in sorted((root / "app/src/main/res").rglob("*.xml")):
        ET.parse(xml)
        add("Well formed " + str(xml.relative_to(root)), True)
    src=root / "app/src/main/java/pe/agendaclara/app"
    listener=(src/"WhatsAppListener.java").read_text()
    flow=(src/"ReviewFlow.java").read_text()
    main=(src/"MainActivity.java").read_text()
    reminders=(src/"Reminders.java").read_text()
    widget=ET.parse(root/"app/src/main/res/layout/widget_photo.xml").getroot()
    add("Photo has one image and no overlay controls", len(list(widget))==1 and list(widget)[0].tag=="ImageView")
    add("No automatic task creation in incoming path", all(x not in listener+flow for x in ["new Task(",".save(","canAutoCreate","getBoolean(\"auto\""]))
    add("Separate review actions", all(x in reminders for x in ["\"Agregar\"","\"No agregar\"","PendingIntent.getActivity","PendingIntent.getBroadcast"]))
    add("Private reject receiver", receivers.get(".ProposalReceiver").get(ns+"exported")=="false")
    add("Photo tap activity private", next(a for a in app.findall("activity") if a.get(ns+"name")==".PhotoTapActivity").get(ns+"exported")=="false")
    add("Tap opens configuration only after timing gate", "DoubleTapGate.completes" in (src/"PhotoTapActivity.java").read_text())
    add("Save accepts proposals atomically", "acceptProposal(t,inboxId)" in main and "beginTransaction()" in (src/"Store.java").read_text())
    add("Selected chat filter before message extraction", listener.index("!chat.selected") < listener.index("getParcelableArray"))
    add("Past notifications discovery only", "inspect(n,false)" in listener and "!incoming" in listener)
    add("Date shortcuts", all(x in main for x in ['button("Hoy"','button("Mañana"','button("Otra fecha"']))
    add("Native 12 hour clock", "getMinute(),false" in main)
    native=(root/"whatsapp-native/main.go").read_text()
    service=(src/"WhatsAppSessionService.java").read_text()
    add("Group catalog queried independently of incoming text", "GetJoinedGroups(ctx)" in native and "GetSubGroups(ctx, g.JID)" in native)
    add("No contact-send API in transport", "SendMessage(" not in native and "SendPeerMessage(ctx, message)" in native and "return t.client.BuildHistorySyncRequest(a, count), nil" in native)
    add("Native consent filter before history extraction", native.index("!t.allowed(id)")<native.index("ParseWebMessage(jid"))
    add("Native inline account history not persisted", "len(n.GetInitialHistBootstrapInlinePayload()) > 0" in native and "continue" in native)
    add("Reading can be paused and revoked", '"pause".equals(action)' in service and "revokeReading" in main)
    add("Historical review has no Task-save path", all(x not in service for x in ["new Task(",".save(","acceptProposal"]))
    add("Full dependency source and notices delivered", (root/"whatsapp-native/vendor/modules.txt").is_file() and (root/"LICENSE").is_file())
    add("Bounded local historical context", "Math.min(4000,limit)" in (src/"Store.java").read_text() and "days*86400000L" in (src/"Store.java").read_text())
    with zipfile.ZipFile(apk) as z:
        add("APK ZIP integrity", z.testzip() is None)
        for name in ["AndroidManifest.xml", "classes.dex", "resources.arsc"]:
            add("APK " + name, name in z.namelist() and z.getinfo(name).file_size > 0)
        for abi in ["arm64-v8a","x86_64"]:
            name="lib/"+abi+"/libagendawa.so";add("Native transport "+abi,name in z.namelist() and z.getinfo(name).file_size>1000000)
        add("In-app dependency notices", "assets/licenses.txt" in z.namelist())
        add("DEX magic", z.read("classes.dex").startswith(b"dex\n"))
    return {
        "scope": "Static source and APK structure; no device/account integration validation",
        "apk": apk.name,
        "apk_size_bytes": apk.stat().st_size,
        "sha256": hashlib.sha256(apk.read_bytes()).hexdigest(),
        "passed": sum(x["passed"] for x in checks),
        "failed": sum(not x["passed"] for x in checks),
        "checks": checks,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("project", type=Path)
    p.add_argument("apk", type=Path)
    p.add_argument("--output", type=Path)
    a = p.parse_args()
    report = audit(a.project.resolve(), a.apk.resolve())
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if a.output:
        a.output.write_text(text + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "checks"}, ensure_ascii=False))
    raise SystemExit(1 if report["failed"] else 0)


if __name__ == "__main__":
    main()
