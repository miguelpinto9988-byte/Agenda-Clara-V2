# Agenda Clara · Fase 24.4 · 40 iconos de cursos

40 archivos PNG RGBA 256×256, vista frontal y transparencia real. Se generaron mediante composiciones vectoriales individuales, no recortadas de una lámina. Se conservaron cuatro iconos de materias previamente creados individualmente y aprobados. Los otros 36 son escenas nuevas, cada una con su propio archivo SVG de origen incluido.

La ilustración PNG de cada curso es un símbolo 3D estilizado (gradientes y relieves suaves), **no** una imagen 3D fotorrealista. Antes de integrarlos en Android corresponde una evaluación visual en tamaños pequeños.

El paquete no incluye iconos de actividades o botones rápidos; esos corresponden a otros apartados. La APK no se modifica ni se compila en esta fase.
