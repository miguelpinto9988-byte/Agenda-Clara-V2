package pe.agendaclara.app;

public final class HistoryPageOptions {
    private HistoryPageOptions() {}
    public static int[] values(){return new int[]{10,20,30,40,50};}
    public static boolean valid(int count){return count>=10&&count<=50&&count%10==0;}
    public static int saved(int count){return valid(count)?count:50;}
}
