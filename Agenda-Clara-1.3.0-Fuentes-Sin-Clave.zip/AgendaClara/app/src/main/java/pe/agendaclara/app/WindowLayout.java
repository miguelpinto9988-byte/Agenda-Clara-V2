package pe.agendaclara.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Insets;
import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.ScrollView;

/** Shared limits for bars, cutouts, keyboards and floating editors. */
final class WindowLayout {
    private WindowLayout() {}
    static int dp(Activity a,int n){return Math.round(n*a.getResources().getDisplayMetrics().density);}
    static void apply(Activity a,View root){
        Window w=a.getWindow();
        if(Build.VERSION.SDK_INT>=30)w.setDecorFitsSystemWindows(false);
        else w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        root.setOnApplyWindowInsetsListener((v,i)->{
            int l,t,r,b;
            if(Build.VERSION.SDK_INT>=30){Insets s=i.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());l=s.left;t=s.top;r=s.right;b=s.bottom;}
            else{
                l=i.getSystemWindowInsetLeft();t=i.getSystemWindowInsetTop();r=i.getSystemWindowInsetRight();b=i.getSystemWindowInsetBottom();
                if(Build.VERSION.SDK_INT>=28&&i.getDisplayCutout()!=null){l=Math.max(l,i.getDisplayCutout().getSafeInsetLeft());t=Math.max(t,i.getDisplayCutout().getSafeInsetTop());r=Math.max(r,i.getDisplayCutout().getSafeInsetRight());b=Math.max(b,i.getDisplayCutout().getSafeInsetBottom());}
            }
            if(v.getPaddingLeft()!=l||v.getPaddingTop()!=t||v.getPaddingRight()!=r||v.getPaddingBottom()!=b)v.setPadding(l,t,r,b);
            return Build.VERSION.SDK_INT>=30?WindowInsets.CONSUMED:i.consumeSystemWindowInsets();
        });root.requestApplyInsets();
    }
    static Rect available(Activity a,View v){
        Rect visible=new Rect();v.getWindowVisibleDisplayFrame(visible);Rect bounds;
        if(Build.VERSION.SDK_INT>=30){android.view.WindowMetrics m=a.getWindowManager().getCurrentWindowMetrics();bounds=new Rect(m.getBounds());Insets s=m.getWindowInsets().getInsetsIgnoringVisibility(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());bounds.inset(s.left,s.top,s.right,s.bottom);}
        else bounds=new Rect(0,0,a.getResources().getDisplayMetrics().widthPixels,a.getResources().getDisplayMetrics().heightPixels);
        if(visible.width()>0&&visible.height()>0)bounds.intersect(visible);return bounds;
    }
    static void boundDialog(Activity a,AlertDialog d){
        Window w=d.getWindow();if(w==null)return;
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);w.setDimAmount(.32f);
        View decor=w.getDecorView();final int[] last={-1};
        Runnable fit=()->{
            if(a.isFinishing()||a.isDestroyed())return;
            Rect safe=available(a,decor);int width=Math.min(dp(a,600),Math.max(dp(a,180),safe.width()-dp(a,32))),max=Math.max(dp(a,120),safe.height()-dp(a,24));
            WindowManager.LayoutParams p=w.getAttributes();int height=p.height;
            if(last[0]!=max)height=WindowManager.LayoutParams.WRAP_CONTENT;
            if(decor.getMeasuredHeight()>max)height=max;
            if(p.width!=width||p.height!=height)w.setLayout(width,height);last[0]=max;
        };decor.getViewTreeObserver().addOnGlobalLayoutListener(()->fit.run());fit.run();
    }
    static final class DialogScroll extends ScrollView{
        final Activity a;DialogScroll(Activity a){super(a);this.a=a;setClipToPadding(false);}
        @Override protected void onMeasure(int w,int h){int max=Math.max(dp(a,96),available(a,a.getWindow().getDecorView()).height()-dp(a,180));if(MeasureSpec.getMode(h)!=MeasureSpec.UNSPECIFIED)max=Math.min(max,MeasureSpec.getSize(h));super.onMeasure(w,MeasureSpec.makeMeasureSpec(max,MeasureSpec.AT_MOST));}
    }
}
