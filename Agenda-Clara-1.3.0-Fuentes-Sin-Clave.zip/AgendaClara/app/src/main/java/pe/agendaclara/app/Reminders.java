package pe.agendaclara.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import java.util.*;

public final class Reminders {
    public static final String CHANNEL="task_deadlines",IMPORT_CHANNEL="message_proposals";
    public static void channels(Context c){
        NotificationManager nm=c.getSystemService(NotificationManager.class);
        NotificationChannel due=new NotificationChannel(CHANNEL,"Fechas y recordatorios",NotificationManager.IMPORTANCE_HIGH);
        due.setDescription("Avisos anticipados y repetidos de tus tareas");due.enableVibration(true);
        nm.createNotificationChannel(due);
        nm.createNotificationChannel(new NotificationChannel(IMPORT_CHANNEL,"Mensajes con posibles tareas",NotificationManager.IMPORTANCE_DEFAULT));
    }
    static PendingIntent alarmIntent(Context c,long id,int flags){
        Intent i=new Intent(c,ReminderReceiver.class).setAction("pe.agendaclara.REMIND").setData(Uri.parse("agenda://reminder/"+id)).putExtra("id",id);
        return PendingIntent.getBroadcast(c,0,i,flags|PendingIntent.FLAG_IMMUTABLE);
    }
    public static boolean exact(Context c){return Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager.class).canScheduleExactAlarms();}
    public static void cancel(Context c,long id){
        AlarmManager a=c.getSystemService(AlarmManager.class);PendingIntent p=alarmIntent(c,id,PendingIntent.FLAG_NO_CREATE);
        if(p!=null){a.cancel(p);p.cancel();}
        c.getSystemService(NotificationManager.class).cancel((int)id);
    }
    public static void schedule(Context c,Task t){
        PendingIntent p=alarmIntent(c,t.id,PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager a=c.getSystemService(AlarmManager.class);a.cancel(p);
        long at=TaskLogic.nextAlarm(t,System.currentTimeMillis());
        if(at<=0)return;
        try{
            if(exact(c))a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);
            else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);
        }catch(SecurityException e){a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);}
    }
    public static void rebuild(Context c){for(Task t:Store.get(c).all())schedule(c,t);}
    public static boolean canNotify(Context c){
        return (Build.VERSION.SDK_INT<33||c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)&&c.getSystemService(NotificationManager.class).areNotificationsEnabled();
    }
    public static void showTask(Context c,Task t){
        channels(c);if(!canNotify(c)||t.done)return;
        Intent open=new Intent(c,MainActivity.class).setAction("open").setData(Uri.parse("agenda://task/"+t.id)).putExtra("task_id",t.id);
        PendingIntent click=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent complete=new Intent(c,ReminderReceiver.class).setAction("complete").setData(Uri.parse("agenda://complete/"+t.id)).putExtra("id",t.id);
        PendingIntent done=PendingIntent.getBroadcast(c,0,complete,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent snooze=new Intent(c,ReminderReceiver.class).setAction("snooze").setData(Uri.parse("agenda://snooze/"+t.id)).putExtra("id",t.id);
        PendingIntent later=PendingIntent.getBroadcast(c,0,snooze,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder n=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notify).setContentTitle(t.title)
            .setContentText(TaskLogic.when(t.due)+" · "+TaskLogic.remaining(t.due,System.currentTimeMillis()))
            .setStyle(new Notification.BigTextStyle().bigText(TaskLogic.when(t.due)+"\n"+TaskLogic.remaining(t.due,System.currentTimeMillis())+"\n"+t.notes))
            .setContentIntent(click).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PRIVATE).addAction(new Notification.Action.Builder(null,"Completar",done).build())
            .addAction(new Notification.Action.Builder(null,"En 15 min",later).build());
        c.getSystemService(NotificationManager.class).notify((int)t.id,n.build());
    }
    public static void showProposal(Context c,Store.Inbox p){
        channels(c);if(!canNotify(c))return;
        Intent edit=new Intent(c,MainActivity.class).setAction("review_proposal").setData(Uri.parse("agenda://proposal/"+p.id)).putExtra("proposal_id",p.id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent add=PendingIntent.getActivity(c,0,edit,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent reject=new Intent(c,ProposalReceiver.class).setAction("reject").setData(Uri.parse("agenda://proposal/reject/"+p.id)).putExtra("proposal_id",p.id);
        PendingIntent no=PendingIntent.getBroadcast(c,0,reject,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(c,IMPORT_CHANNEL).setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Posible actividad · "+p.source).setContentText(p.title)
            .setStyle(new Notification.BigTextStyle().bigText(p.original+"\nConfirma fecha y hora antes de guardar."))
            .setContentIntent(add).setAutoCancel(false).setVisibility(Notification.VISIBILITY_PRIVATE)
            .addAction(new Notification.Action.Builder(null,"Agregar",add).build())
            .addAction(new Notification.Action.Builder(null,"No agregar",no).build()).build();
        c.getSystemService(NotificationManager.class).notify("proposal",(int)p.id,n);
    }
    public static void cancelProposal(Context c,long id){c.getSystemService(NotificationManager.class).cancel("proposal",(int)id);}
}
