package pe.agendaclara.app;

import java.util.regex.Pattern;

/** Conservative, local Spanish rules. Scores are rule levels, not probabilities. */
public final class ActivityClassifier {
    public static final class Result {
        public boolean candidate,closed,uncertain;public int score;public String reason="";
    }
    private static Pattern p(String s){return Pattern.compile(s);}
    private static final String VERBS="(?:entregar|entreguen|entrega|presentar|presenten|presenta|enviar|envien|envia|resolver|resuelvan|resuelve|realizar|realicen|realiza|elaborar|elaboren|elabora|completar|completen|completa|leer|lean|lee|estudiar|estudien|preparar|preparen|prepara|traer|traigan|pagar|paguen|paga|comprar|compren|compra|hacer|hagan|llenar|llenen|subir|suban|adjuntar|adjunten|asistir|registrarse|inscribirse|revisar|revisen|terminar|terminen|redactar|redacten|desarrollar|desarrollen|mandar|manden|manda|responder|respondan|contestar|contesten|llevar|lleven|lleva)";
    private static final Pattern CLOSED=p("\\b(?:no hay|no tenemos|no (?:tengo|tenemos|tienen|tienes|tiene) que|no se debe|no es (?:una )?tarea|no (?:entregar|presentar|enviar|hacer)|no se entrega|cancelad[oa]s?|se cancela|se cancelo|qued[ao] sin efecto|se suspende|suspendid[oa]|ya (?:lo |la |las |los |he |hemos |esta |estan |fue |se )?(?:entregue|entregado|entregada|entregaron|termine|terminado|terminada|terminamos|hecho|hecha|enviado|enviada|envie|hicimos|resuelto|resuelta|completado|completada|presente|presentado|pagado)|tarea terminada|actividad finalizada|entrega realizada|tarea realizada|trabajo terminado|informe entregado)\\b");
    private static final Pattern UNCERTAIN=p("\\b(?:quiza|quizas|tal vez|podria|podrias|posiblemente|si puedes|a lo mejor|creo que|no se si|alguien sabe|saben si|que opinan|me pregunto|seria bueno)\\b");
    private static final Pattern OBLIGATION=p("\\b(?:deben|debe|deberan|debemos|tienen que|tiene que|tienes que|tengo que|tenemos que|hay que|se debe|les toca|les pido|necesitamos|es obligatorio|por favor|recuerden|recuerda|no olviden|no olvides|recordatorio)\\b[^.!?]{0,70}\\b"+VERBS+"\\b\\s+\\S+");
    private static final Pattern DIRECTIVE=p("^(?:(?:atencion|aviso|importante|recordatorio|para (?:hoy|manana|el [a-z0-9 /-]+))\\s*[:,]?\\s*)?(?:por favor\\s+)?"+VERBS+"\\b\\s+(?!manana\\b|hoy\\b|el lunes\\b|el martes\\b|el miercoles\\b|el jueves\\b|el viernes\\b|el sabado\\b|el domingo\\b)[a-z0-9¿].{2,}");
    private static final Pattern NOMINAL=p("^(?:(?:atencion|aviso|importante|recordatorio)\\s*[:,]?\\s*)?(?:(?:el|la|proximo|proxima|tenemos|habra)\\s+|se (?:realizara|programa)\\s+)?(?:examen|reunion|cita|taller|evento|charla|seminario|clase|practica|sustentacion|exposicion|evaluacion|entrega|actividad|trabajo|tarea)\\b");
    private static final Pattern ASSIGNED=p("^(?:(?:el|la)\\s+)?(?:tarea|trabajo|actividad|ejercicios?)\\b[^.!?]{0,80}(?:consiste en|es|:)\\s*"+VERBS+"\\b\\s+\\S+");
    private static final Pattern ANNOUNCED=p("\\b(?:habra|tenemos|se realizara|se convoca|convocamos|se programa)\\s+(?:(?:un|una|la|el)\\s+)?(?:reunion|taller|examen|evento|charla|clase|actividad|evaluacion)\\b|\\b(?:vamos a reunirnos|nos reuniremos)\\b");
    private static final Pattern DEADLINE=p("\\b(?:fecha limite|ultimo dia para|fecha de entrega|plazo para|vence el|vence manana|vence hoy|entrega obligatoria)\\b");
    private static final Pattern ASSIGNMENT=p("\\b(?:tarea|trabajo|informe|proyecto|actividad|ejercicio|ejercicios|formulario|pago|documento|entrega)\\b");
    private static final Pattern CHATTER=p("\\b(?:me gusta|me encanta|no me gusta|odio|que dificil|que aburrid[oa]|estoy cansad[oa]|en mi trabajo|sali del trabajo|voy al trabajo|estoy en el trabajo|fui al trabajo|a ver si|por fin|gracias por)\\b");
    private static final Pattern PAST=p("\\b(?:fue|era|tuvimos|hubo|estuvo|termino|me parecio)\\b");
    public static boolean isClosed(String text){return CLOSED.matcher(MessageParser.normalize(text)).find();}
    public static Result classify(String text,boolean dateKnown){
        Result r=new Result();String s=MessageParser.normalize(text).replaceFirst("^\\s*(?:[-*•]|\\d+[.)])\\s*","").trim();
        if(s.length()<7)return r;
        if(CLOSED.matcher(s).find()){r.closed=true;r.reason="Cancelación o actividad realizada; no se propone como pendiente.";return r;}
        if(s.indexOf('?')>=0||s.indexOf('¿')>=0||UNCERTAIN.matcher(s).find()){
            r.uncertain=true;r.reason="Pregunta o mensaje incierto; sin propuesta automática.";return r;
        }
        if(CHATTER.matcher(s).find())return r;
        if(DIRECTIVE.matcher(s).find()||OBLIGATION.matcher(s).find()||ASSIGNED.matcher(s).find()){
            r.candidate=true;r.score=3;r.reason="Instrucción concreta: revisa a quién corresponde.";return r;
        }
        if(dateKnown&&(NOMINAL.matcher(s).find()||ANNOUNCED.matcher(s).find())){
            if(PAST.matcher(s).find())return r;
            r.candidate=true;r.score=2;r.reason="Actividad anunciada con una referencia de fecha.";return r;
        }
        if(dateKnown&&DEADLINE.matcher(s).find()&&ASSIGNMENT.matcher(s).find()){
            r.candidate=true;r.score=3;r.reason="Plazo de una actividad concreta; confirma el vencimiento.";
        }
        return r;
    }
}
