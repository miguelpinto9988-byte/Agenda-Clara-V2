# Compilar Agenda Clara 1.3.0 en GitHub Actions

Este archivo fuente NO es una APK instalable.

1. Extrae el ZIP y abre la carpeta `AgendaClara`.
2. Coloca el contenido de la carpeta (incluyendo `.github`, `gradle`, `gradlew`, `app` y `signing`) en la **raíz** de un repositorio privado de GitHub. No subas el ZIP sin extraerlo.
3. En GitHub abre **Actions** → **Agenda Clara 1.3 - APK firmada** → **Run workflow**.
4. Solo cuando el flujo termine en verde, abre el trabajo y descarga **Agenda-Clara-1.3.0-APK** desde **Artifacts**.
5. Extrae el artefacto: contiene `app-debug.apk`, firmado con la clave de desarrollo del proyecto.
6. Instala sobre la versión anterior (sin desinstalar); si falla por firma, compara certificados antes de hacer cambios que podrían borrar tus datos.

El flujo compila y revisa ZIP/APK y firma, pero no sustituye pruebas funcionales en dispositivo. Si falla, consulta el registro del paso correspondiente.

**Nota de seguridad**: el ZIP contiene un keystore de desarrollo. No lo publiques en un repositorio accesible a terceros; idealmente sustituirlo por secretos de firma de GitHub y rotar credenciales si corresponde.
