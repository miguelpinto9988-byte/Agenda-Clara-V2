package pe.agendaclara.app;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public final class TextHash {
    public static String of(String text){
        try{byte[] b=MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));char[] hex="0123456789abcdef".toCharArray(),out=new char[b.length*2];for(int j=0;j<b.length;j++){int v=b[j]&255;out[j*2]=hex[v>>>4];out[j*2+1]=hex[v&15];}return new String(out);}
        catch(Exception e){throw new IllegalStateException(e);}
    }
}
