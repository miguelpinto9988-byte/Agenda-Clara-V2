package pe.agendaclara.app;

import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.*;

/** Two real screens inside the original Calendario tab. No duplicate calendar state. */
public final class CalendarStudyHub {
    private static final int BLUE=0xff3464f4, INK=0xff182746, MUTED=0xff60738f;
    private CalendarStudyHub(){}
    public static void render(MainActivity a){
        LinearLayout tabs=a.row();tabs.setPadding(a.dp(3),a.dp(3),a.dp(3),a.dp(3));
        tabs.setBackground(a.rounded(0xffe8efff,18));
        String[] labels={"Calendario","Plan de estudio"};
        for(int i=0;i<2;i++){
            final int current=i;
            Button b=a.button(labels[i],()->{if(a.calendarHubTab!=current){a.calendarHubTab=current;a.contentScroll.scrollTo(0,0);a.render();}});
            b.setTextSize(UiPreferences.scaled(a,13));
            b.setAllCaps(false);
            b.setTextColor(a.calendarHubTab==i?0xffffffff:INK);
            b.setBackground(a.rounded(a.calendarHubTab==i?BLUE:0xffe8efff,15));
            b.setContentDescription(labels[i]+(a.calendarHubTab==i?", sección actual":", abrir sección"));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,a.dp(50),1);
            if(i==0)lp.rightMargin=a.dp(3);else lp.leftMargin=a.dp(3);
            tabs.addView(b,lp);
        }
        a.body.addView(tabs);a.gap(a.body,18);
        if(a.calendarHubTab==0)calendar(a);else study(a);
    }
    private static void calendar(MainActivity a){
        List<Task> all=Store.get(a).all();
        CalendarVisuals.month(a,a.body,all);
        CalendarVisuals.selectedDate(a,a.body,all);
        a.taskList=a.column();a.body.addView(a.taskList);a.fillTasks(all,a.selectedDay);
        StickyNotesUi.calendar(a,a.body,a.selectedDay);
    }
    private static void study(MainActivity a){
        ScheduleDatabase db=ScheduleDatabase.get(a);
        db.ensureCategories();
        List<ScheduleDatabase.Timetable> schedules=db.schedules();
        LinearLayout panel=a.card(a.body);
        LinearLayout header=a.row();
        header.addView(a.text("Horarios",19,INK,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView count=a.text(schedules.size()+" de 10",12,BLUE,true);
        count.setPadding(a.dp(9),a.dp(6),a.dp(9),a.dp(6));
        count.setBackground(a.rounded(0xffe8efff,12));header.addView(count);
        panel.addView(header);a.gap(panel,6);
        panel.addView(a.text("Cada horario organiza sus propios cursos y crea una categoría académica.",12,MUTED,false));
        a.gap(panel,13);
        for(ScheduleDatabase.Timetable t:schedules){
            int classes=db.forSchedule(t.id).size();int courses=db.courses(t.id).size();
            Button open=a.button((t.id==db.activeId()?"✓  ":"▣  ")+t.name+" · "+courses+" cursos · "+classes+" clases  ›",()->{
                db.setActive(t.id);
                a.startActivity(new Intent(a,ScheduleActivity.class).putExtra("schedule_id",t.id));
            });
            open.setContentDescription("Abrir horario "+t.name+", "+courses+" cursos");
            panel.addView(open);a.gap(panel,5);
        }
        Button newSchedule=a.primaryButton("＋  Nuevo horario",()->a.startActivity(new Intent(a,ScheduleActivity.class).putExtra("open_new_schedule",true)));
        newSchedule.setEnabled(schedules.size()<ScheduleDatabase.MAX_SCHEDULES);
        panel.addView(newSchedule);a.gap(panel,8);
        panel.addView(a.button("Importar horario desde foto",()->a.startActivity(new Intent(a,ScheduleActivity.class).putExtra("new_schedule_photo",true))));
        if(schedules.size()>=ScheduleDatabase.MAX_SCHEDULES){a.gap(panel,6);panel.addView(a.text("Has alcanzado el límite de 10 horarios.",12,MUTED,true));}
        a.gap(a.body,10);
        LinearLayout exams=a.card(a.body);
        exams.addView(a.text("Exámenes y sílabos",19,INK,true));a.gap(exams,7);
        exams.addView(a.text("Aquí se incorporará la importación PDF, DOC y DOCX, la detección de exámenes y sus recordatorios en la siguiente entrega.",13,MUTED,false));
        a.gap(exams,12);
        exams.addView(a.button("Agregar actividad manual",()->a.openEditor(-1,null,null)));
        a.gap(exams,6);
        exams.addView(a.text("Importación inteligente de sílabos: disponible en la Entrega B.",12,MUTED,true));
    }
}
