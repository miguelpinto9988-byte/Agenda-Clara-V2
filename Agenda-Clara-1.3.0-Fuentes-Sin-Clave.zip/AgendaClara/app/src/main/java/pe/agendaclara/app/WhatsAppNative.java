package pe.agendaclara.app;

import org.json.*;
import java.nio.charset.StandardCharsets;

/** UTF-8 JNI boundary. Library is loaded only after the user starts linking. */
public final class WhatsAppNative {
    private static boolean loaded;
    private static synchronized void load(){if(!loaded){System.loadLibrary("agendawa");loaded=true;}}
    private static native byte[] command(byte[] data);
    private static native byte[] poll();
    public static JSONObject call(JSONObject data)throws Exception{
        load();byte[] out=command(data.toString().getBytes(StandardCharsets.UTF_8));
        if(out==null)throw new IllegalStateException("La conexión no respondió.");
        JSONObject result=new JSONObject(new String(out,StandardCharsets.UTF_8));
        if(!result.optBoolean("ok"))throw new IllegalStateException(result.optString("error","No se completó la operación."));return result;
    }
    public static JSONArray events()throws Exception{load();byte[] out=poll();return out==null?new JSONArray():new JSONArray(new String(out,StandardCharsets.UTF_8));}
}
