package pe.agendaclara.app;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import java.util.*;

public final class CalendarBridge {
    public static final class CalendarInfo {
        public long id;public String name,account;public boolean google,writable;
        @Override public String toString(){return name+"\n"+account+(google?" · Google":"");}
    }
    public static boolean allowed(Context c){
        return c.checkSelfPermission(Manifest.permission.READ_CALENDAR)==PackageManager.PERMISSION_GRANTED&&c.checkSelfPermission(Manifest.permission.WRITE_CALENDAR)==PackageManager.PERMISSION_GRANTED;
    }
    public static List<CalendarInfo> calendars(Context c){
        List<CalendarInfo> out=new ArrayList<>();if(!allowed(c))return out;
        String[] cols={"_id","calendar_displayName","account_name","account_type","calendar_access_level"};
        try(Cursor cur=c.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,cols,"calendar_access_level>=?",new String[]{"200"},"account_name ASC")){
            if(cur!=null)while(cur.moveToNext()){CalendarInfo k=new CalendarInfo();k.id=cur.getLong(0);k.name=cur.getString(1);k.account=cur.getString(2);k.google="com.google".equals(cur.getString(3));k.writable=cur.getInt(4)>=500;out.add(k);}
        }
        return out;
    }
    /** Writes only the event linked to this task, with stable event ID. */
    public static synchronized String upsert(Context c,Task t){
        Task current=Store.get(c).find(t.id);if(current==null)return "La tarea ya no existe.";t=current;
        if(!t.calendarEnabled||t.done||t.due<=0)return "";
        if(!allowed(c))return "Falta el permiso de calendario.";
        long cal=t.calendarId>0?t.calendarId:Prefs.calendar(c);
        if(cal<0)return "Selecciona un calendario en Conexiones.";
        try{
            ContentValues v=new ContentValues();v.put(CalendarContract.Events.TITLE,t.title);
            v.put(CalendarContract.Events.DESCRIPTION,t.notes+"\n\nAgenda Clara · tarea "+t.id);
            v.put(CalendarContract.Events.DTSTART,t.due);v.put(CalendarContract.Events.DTEND,t.due+t.duration*60000L);
            v.put(CalendarContract.Events.EVENT_TIMEZONE,TimeZone.getDefault().getID());
            v.put(CalendarContract.Events.CALENDAR_ID,cal);v.put(CalendarContract.Events.HAS_ALARM,0);
            if(t.eventId>0){
                int n=c.getContentResolver().update(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,t.eventId),v,null,null);
                if(n==0)return "El evento vinculado ya no está disponible. Revisa Google Calendar.";
            }else{
                Uri uri=c.getContentResolver().insert(CalendarContract.Events.CONTENT_URI,v);
                if(uri==null)return "El calendario no devolvió un evento.";
                t.eventId=ContentUris.parseId(uri);t.calendarId=cal;Store.get(c).linkEvent(t.id,t.eventId,cal);
            }
            return "";
        }catch(Exception e){return "No se pudo escribir en el calendario. La tarea quedó guardada en Agenda Clara.";}
    }
    public static String sendAll(Context c){
        int count=0,errors=0;for(Task t:Store.get(c).all())if(t.calendarEnabled&&!t.done&&t.due>0){if(upsert(c,t).isEmpty())count++;else errors++;}
        return count+" tarea(s) enviadas al calendario del teléfono."+(errors>0?" "+errors+" sin sincronizar.":"");
    }
    public static final class Event {
        public long id,start,end,calendarId;public String title,notes,calendarName="";public boolean allDay;
        @Override public String toString(){return title+"\n"+(allDay?java.time.Instant.ofEpochMilli(start).atZone(java.time.ZoneOffset.UTC).toLocalDate()+" · Día completo":TaskLogic.when(start))+" · "+calendarName;}
    }
    public static List<Event> events(Context c,long cal){
        List<Event> out=new ArrayList<>();if(!allowed(c))return out;
        long now=System.currentTimeMillis();
        Uri.Builder b=CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(b,now-7*86400000L);ContentUris.appendId(b,now+366*86400000L);
        try(Cursor cur=c.getContentResolver().query(b.build(),new String[]{"event_id","title","begin","end","description","allDay"},"calendar_id=?",new String[]{""+cal},"begin ASC")){
            if(cur!=null)while(cur.moveToNext()&&out.size()<200){Event e=new Event();e.id=cur.getLong(0);e.title=cur.getString(1)==null?"Evento sin título":cur.getString(1);e.start=cur.getLong(2);e.end=cur.getLong(3);e.notes=cur.getString(4)==null?"":cur.getString(4);e.calendarId=cal;e.allDay=cur.getInt(5)!=0;out.add(e);}
        }return out;
    }
    public static List<Event> selectedEvents(Context c){
        List<Event> out=new ArrayList<>();java.util.Set<String> selected=Prefs.calendars(c);
        for(CalendarInfo k:calendars(c))if(selected.contains(""+k.id))for(Event e:events(c,k.id)){e.calendarName=k.name;out.add(e);}
        java.util.Collections.sort(out,(a,b)->Long.compare(a.start,b.start));return out;
    }
}
