# Verificación de Agenda Clara 1.2.1

APK SHA-256: `3e618e0cb4a0dfaf2b9017b80b6363af5f9eee307f780e5131433185da1cd748`. VersionCode 4, esquema de datos v3, firma v2/v3 y certificado original.

Pasaron 136 comprobaciones JVM de fechas, avisos, prioridad, doble toque y clasificación; cuatro pruebas Go con detector de carreras, incluida la construcción del protocolo para 10/20/30/40/50 mensajes y el control de consentimiento; y 75 comprobaciones estáticas. Los binarios ARM64/x86_64 están alineados a 16 KB.

La revisión Android de esta actualización está pendiente. Las evidencias `*-v12*` corresponden a la versión anterior y no prueban la interfaz nueva. El APK y el APK de instrumentación están compilados; esta copia es un punto de recuperación previo a completar esa revisión.

No se ha comprobado el parpadeo en tu teléfono ni medido FPS o batería. No se ha vinculado una cuenta personal de WhatsApp o Google. La solicitud conserva la cantidad elegida, pero WhatsApp puede entregar menos historial; sigue vigente el límite local y el periodo seleccionado. Cada tarea requiere confirmación y el detector por reglas puede equivocarse.
