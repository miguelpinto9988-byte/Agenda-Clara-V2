package pe.agendaclara.app;

import java.util.Locale;

/** Cautious photo title suggestion; never creates a schedule without user confirmation. */
public final class ScheduleNameDetector {
    private ScheduleNameDetector(){}
    public static String suggest(String text){
        if(text==null)return "";
        String[] lines=text.split("\\R");
        for(int i=0;i<Math.min(lines.length,12);i++){
            String line=lines[i].trim().replaceAll("\\s+"," ");
            if(line.length()<5||line.length()>80)continue;
            String lower=line.toLowerCase(Locale.ROOT);
            if(lower.startsWith("horario:" )||lower.startsWith("horario académico:")||lower.startsWith("horario de clases:")){
                String value=line.substring(line.indexOf(':')+1).trim();
                if(valid(value))return value;
            }
            if(lower.startsWith("periodo:")||lower.startsWith("período:")||lower.startsWith("semestre:")){
                String value=line.substring(line.indexOf(':')+1).trim();
                if(valid(value))return value;
            }
        }
        return "";
    }
    private static boolean valid(String s){return s.length()>=3&&s.length()<=28&&!s.matches(".*\\d{1,2}:\\d{2}.*")&&!s.matches("(?i)(?:lunes|martes|miércoles|miercoles|jueves|viernes|sábado|sabado|domingo).*");}
}
