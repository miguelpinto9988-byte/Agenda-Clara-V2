package pe.agendaclara.app;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;
import java.util.regex.*;

/** User-chosen WhatsApp text exports; explicit day/month convention, original timestamps. */
public final class HistoryTextParser {
    private static final Pattern LINE=Pattern.compile("^\\[?(\\d{1,2})[/.-](\\d{1,2})[/.-](\\d{2}|\\d{4}),?\\s+(\\d{1,2}):([0-5]\\d)(?::([0-5]\\d))?\\s*(a\\.?\\s*m\\.?|p\\.?\\s*m\\.?)?\\]?\\s*(?:-\\s*)?(.*)$",Pattern.CASE_INSENSITIVE);
    public static List<ConversationAnalyzer.Message> parse(InputStream stream,ZoneId zone)throws IOException{
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int read;
        while((read=stream.read(buffer))!=-1){if(bytes.size()+read>8*1024*1024)throw new IOException("El archivo supera 8 MB. Exporta sin archivos multimedia.");bytes.write(buffer,0,read);}
        String content=new String(bytes.toByteArray(),StandardCharsets.UTF_8);ArrayDeque<ConversationAnalyzer.Message> result=new ArrayDeque<>();ConversationAnalyzer.Message current=null;
        int lines=0;
        try(BufferedReader reader=new BufferedReader(new StringReader(content))){String raw;while((raw=reader.readLine())!=null){
            if(++lines>100000)throw new IOException("El archivo contiene demasiadas líneas.");
            String line=raw.replace("\u200e","").replace("\u200f","").replace("\ufeff","").replace('\u202f',' ').replace('\u00a0',' ');
            Matcher m=LINE.matcher(line);
            if(m.matches()){
                current=null;String rest=m.group(8);int colon=rest.indexOf(": ");if(colon<1)continue;
                try{
                    int year=Integer.parseInt(m.group(3));if(year<100)year+=2000;int hour=Integer.parseInt(m.group(4)),minute=Integer.parseInt(m.group(5)),second=m.group(6)==null?0:Integer.parseInt(m.group(6));
                    String meridiem=m.group(7)==null?"":m.group(7).toLowerCase(Locale.ROOT);
                    if(!meridiem.isEmpty()){if(hour<1||hour>12)continue;hour=(hour%12)+(meridiem.startsWith("p")?12:0);}
                    LocalDateTime time=LocalDateTime.of(year,Integer.parseInt(m.group(2)),Integer.parseInt(m.group(1)),hour,minute,second);
                    if(zone.getRules().getValidOffsets(time).size()!=1)continue;
                    current=new ConversationAnalyzer.Message();current.time=time.atZone(zone).toInstant().toEpochMilli();current.sender=rest.substring(0,colon);current.body=rest.substring(colon+2);result.addLast(current);while(result.size()>4000)result.removeFirst();
                }catch(DateTimeException|NumberFormatException ignored){}
            }else if(current!=null&&current.body.length()<12000){current.body+="\n"+line.substring(0,Math.min(line.length(),12000-current.body.length()));}
        }}
        for(ConversationAnalyzer.Message m:result)m.id="export:"+TextHash.of(m.time+"\n"+m.sender+"\n"+m.body);
        return new ArrayList<>(result);
    }
}
