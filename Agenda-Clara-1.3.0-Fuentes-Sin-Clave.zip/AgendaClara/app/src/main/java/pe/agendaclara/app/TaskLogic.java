package pe.agendaclara.app;

import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public final class TaskLogic {
    public static String status(Task t,long now) {
        if(t.done) return "Completada";
        if(t.due<=0) return t.urgent?"Urgente":"Sin fecha";
        long left=t.due-now;
        if(left<0) return "Vencida";
        if(t.urgent || left<=2L*86400000) return "Urgente";
        if(left<=7L*86400000) return "Pendiente";
        return "Próxima";
    }
    public static String when(long millis) {
        if(millis<=0) return "Sin fecha";
        return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEE d MMM · h:mm a", new Locale("es","PE")));
    }
    public static String remaining(long due,long now) {
        if(due<=0) return "Fecha por definir";
        long min=Math.abs(due-now)/60000;
        String s=min>=1440?(min/1440)+" d "+((min%1440)/60)+" h":min>=60?(min/60)+" h "+(min%60)+" min":min+" min";
        return due<now?"Venció hace "+s:"Faltan "+s;
    }
    public static SortedSet<Integer> offsets(String csv) {
        SortedSet<Integer> out=new TreeSet<>(Collections.reverseOrder());
        if(csv!=null) for(String s:csv.split(",")) try {
            int n=Integer.parseInt(s.trim()); if(n>=0&&n<=5256000)out.add(n);
        }catch(NumberFormatException ignored){}
        return out;
    }
    public static String offsetName(int n) {
        if(n==0)return "Al vencer";
        if(n%10080==0)return (n/10080)+(n==10080?" semana antes":" semanas antes");
        if(n%1440==0)return (n/1440)+(n==1440?" día antes":" días antes");
        if(n%60==0)return (n/60)+(n==60?" hora antes":" horas antes");
        return n+" min antes";
    }
    public static long nextAlarm(Task t,long after) {
        if(t.done||t.due<=0)return -1;
        long best=Long.MAX_VALUE;
        SortedSet<Integer> offsets=offsets(t.offsets);
        for(int m:offsets) {
            long at=t.due-m*60000L;
            if(at>after&&at<best)best=at;
        }
        if(t.repeatMinutes>0&&!offsets.isEmpty()) {
            long start=t.due-offsets.first()*60000L,step=t.repeatMinutes*60000L;
            long at=start>after?start:start+((after-start)/step+1)*step;
            if(at>after&&at<=t.due&&at<best)best=at;
        }
        return best==Long.MAX_VALUE?-1:best;
    }
}
