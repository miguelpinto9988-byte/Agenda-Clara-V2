package pe.agendaclara.app;

import android.content.Context;
import android.net.Uri;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Authenticated, independent class-schedule backup; no WhatsApp data included. */
public final class ScheduleBackup {
    private static final int MAX_FILE=1024*1024,MAX_CLASSES=1500;
    private ScheduleBackup(){}
    public static byte[] exportBytes(Context context)throws Exception{
        JSONArray rows=new JSONArray();List<ScheduleEntry> items=ScheduleDatabase.get(context).all();
        if(items.size()>MAX_CLASSES)throw new IOException("Máximo 1500 clases por copia.");
        for(ScheduleEntry e:items){rows.put(new JSONObject().put("scheduleId",e.scheduleId).put("course",e.course).put("day",e.day).put("start",e.start).put("end",e.end)
            .put("room",e.room).put("teacher",e.teacher).put("notes",e.notes).put("color",e.color).put("reminder",e.reminder).put("enabled",e.enabled));}
        android.content.SharedPreferences prefs=context.getSharedPreferences("schedule_settings",0);
        JSONArray plans=new JSONArray();
        for(ScheduleDatabase.Timetable timetable:ScheduleDatabase.get(context).schedules())
            plans.put(new JSONObject().put("id",timetable.id).put("name",timetable.name));
        JSONObject root=new JSONObject().put("format","agenda-clara-class-schedule").put("schema",2)
            .put("schedules",plans).put("sessions",rows)
            .put("semesterStart",prefs.getString("semester_start","")).put("semesterEnd",prefs.getString("semester_end",""));
        byte[] data=root.toString().getBytes(StandardCharsets.UTF_8);
        if(data.length>MAX_FILE)throw new IOException("La copia supera 1 MB.");
        return data;
    }
    public static int importBytes(Context context,byte[] bytes)throws Exception{
        if(bytes==null||bytes.length>MAX_FILE)throw new IOException("Archivo de horario demasiado grande.");
        JSONObject root=new JSONObject(new String(bytes,StandardCharsets.UTF_8));
        int schema=root.optInt("schema");
        if(!"agenda-clara-class-schedule".equals(root.optString("format"))||(schema!=1&&schema!=2))throw new IOException("Copia de horario incompatible.");
        LinkedHashMap<Long,String> names=new LinkedHashMap<>();
        if(schema==2){
            JSONArray plans=root.getJSONArray("schedules");
            if(plans.length()>ScheduleDatabase.MAX_SCHEDULES)throw new IOException("La copia contiene más de 10 horarios.");
            HashSet<String> unique=new HashSet<>();
            for(int i=0;i<plans.length();i++){
                JSONObject plan=plans.getJSONObject(i);long id=plan.getLong("id");String name=plan.getString("name").trim();
                if(id<1||name.length()<3||name.length()>28||!unique.add(name.toLowerCase(java.util.Locale.ROOT))||names.put(id,name)!=null)
                    throw new IOException("Nombre o identificador de horario inválido.");
            }
        }else names.put(1L,"Mi horario");
        JSONArray rows=root.getJSONArray("sessions");if(rows.length()>MAX_CLASSES)throw new IOException("Demasiadas clases.");
        ArrayList<ScheduleEntry> list=new ArrayList<>();
        for(int i=0;i<rows.length();i++){
            JSONObject item=rows.getJSONObject(i);ScheduleEntry e=new ScheduleEntry();
            e.scheduleId=schema==2?item.getLong("scheduleId"):1;
            if(!names.containsKey(e.scheduleId))throw new IOException("La clase pertenece a un horario desconocido.");
            e.course=item.getString("course");e.day=item.getInt("day");e.start=item.getInt("start");e.end=item.getInt("end");
            e.room=item.optString("room","");e.teacher=item.optString("teacher","");e.notes=item.optString("notes","");
            e.color=item.optInt("color",ScheduleEntry.COLORS[0]);e.reminder=item.optInt("reminder",10);e.enabled=item.optBoolean("enabled",true);
            if(!ScheduleEntry.valid(e)||!(e.reminder==0||e.reminder==5||e.reminder==10||e.reminder==15||e.reminder==30||e.reminder==60))throw new IOException("Datos inválidos en la clase "+(i+1));
            list.add(e);
        }
        String from=root.optString("semesterStart",""),until=root.optString("semesterEnd","");
        // Validate everything before writing, so malformed archives never change user data.
        java.time.LocalDate a=from.isEmpty()?null:java.time.LocalDate.parse(from),b=until.isEmpty()?null:java.time.LocalDate.parse(until);
        if(a!=null&&b!=null&&a.isAfter(b))throw new IOException("Periodo académico inválido.");
        ScheduleDatabase db=ScheduleDatabase.get(context);
        HashMap<Long,Long> idMap=new HashMap<>();
        if(schema==1){idMap.put(1L,db.activeId());}else{
            // Check collisions and capacity before creating any categories or schedules.
            int required=0;
            for(Map.Entry<Long,String> item:names.entrySet()){
                long match=0;
                for(ScheduleDatabase.Timetable candidate:db.schedules())
                    if(candidate.name.equalsIgnoreCase(item.getValue()))match=candidate.id;
                if(match==0){
                    required++;
                    for(CategoryRegistry.Entry category:CategoryRegistry.all(context))
                        if(category.name.equalsIgnoreCase(item.getValue()))
                            throw new IOException("La categoría ya existe y no pertenece a un horario: "+item.getValue());
                }
                idMap.put(item.getKey(),match);
            }
            if(db.schedules().size()+required>ScheduleDatabase.MAX_SCHEDULES)throw new IOException("La copia superaría el límite de 10 horarios.");
            for(Map.Entry<Long,String> item:names.entrySet())if(idMap.get(item.getKey())==0){
                long id=db.create(item.getValue());
                if(id<1)throw new IOException("No se pudo crear el horario "+item.getValue());
                idMap.put(item.getKey(),id);
            }
        }
        for(ScheduleEntry entry:list)entry.scheduleId=idMap.get(entry.scheduleId);
        int added=db.importReviewed(list);
        context.getSharedPreferences("schedule_settings",0).edit().putString("semester_start",from).putString("semester_end",until).apply();
        return added;
    }
    public static int exportEncrypted(Context context,Uri uri,char[] password)throws Exception{
        byte[] plain=null,sealed=null;try{
            plain=exportBytes(context);sealed=SecureArchive.encrypt(plain,password);
            try(OutputStream out=context.getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("No se pudo escribir la copia.");out.write(sealed);}
            return ScheduleDatabase.get(context).all().size();
        }finally{if(plain!=null)Arrays.fill(plain,(byte)0);if(sealed!=null)Arrays.fill(sealed,(byte)0);if(password!=null)Arrays.fill(password,'\0');}
    }
    public static int importEncrypted(Context context,Uri uri,char[] password)throws Exception{
        byte[] sealed=null,plain=null;try{
            try(InputStream input=context.getContentResolver().openInputStream(uri)){
                if(input==null)throw new IOException("No se pudo leer el archivo.");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;
                while((n=input.read(b))!=-1){if(out.size()+n>MAX_FILE+256)throw new IOException("Archivo demasiado grande.");out.write(b,0,n);}sealed=out.toByteArray();
            }
            plain=SecureArchive.decrypt(sealed,password);return importBytes(context,plain);
        }finally{if(sealed!=null)Arrays.fill(sealed,(byte)0);if(plain!=null)Arrays.fill(plain,(byte)0);if(password!=null)Arrays.fill(password,'\0');}
    }
}
