> **ACTUALIZACIÓN 1.3.0:** Consulta [ACTUALIZACION-1.3.md](ACTUALIZACION-1.3.md) para el diseño azul/violeta, la retirada automática de tareas completadas después de una hora y la compilación de una APK nueva. Las indicaciones de instalación de 1.2.1 más abajo corresponden al respaldo anterior.

# Agenda Clara 1.2.1

App Android de tareas, calendario, avisos y widgets. Esta actualización incorpora un transporte de dispositivo vinculado para consultar grupos y comunidades, revisión de historial autorizado y un filtro local más selectivo. El APK requiere Android 8 o posterior y un dispositivo de **64 bits ARM o x86**.

**Alcance de verificación:** compilación y pruebas locales terminadas; revisión Android de esta actualización pendiente. No se ha verificado el efecto en tu teléfono ni la vinculación con tus cuentas. Consulta `verification/ALCANCE-v121.md`.

## Cambios de esta versión

La pantalla conserva su estructura y agrupa las actualizaciones. Las señales sin cambios visibles no reconstruyen el contenido. Las actualizaciones de fondo esperan durante escritura, selección de texto, desplazamiento o diálogos; se conserva la posición de la tarjeta visible. Los formularios tienen márgenes, bordes y límites de tamaño según el teclado y la ventana. La vista previa de fotos agrupa ajustes rápidos por fotograma y deja su memoria a la gestión de Android.

En cada grupo autorizado toca **Mensajes anteriores** y escoge **10, 20, 30, 40 o 50**; después pulsa **Solicitar**. Se solicita esa cantidad anterior al mensaje de referencia más antiguo. **Volver** mantiene la selección anterior. Se comprueba otra vez el permiso de lectura. WhatsApp puede entregar menos historial y siguen aplicándose el periodo y el máximo local de 4.000 mensajes.

## Instalar conservando tus tareas

Abre `Agenda-Clara-1.2.1.apk` e instala la actualización encima de la app anterior. Se mantiene el identificador `pe.agendaclara.app`, el certificado original y se aumenta `versionCode` a 4. Se mantiene el esquema de datos v3 de la versión anterior. Evita desinstalar si quieres conservarlas. Si Android informa de una firma diferente, conserva la instalación y sus datos hasta identificar la versión que tienes.

En Conexiones → Avisos y widgets activa notificaciones y, si quieres avisos a la hora elegida, Alarmas y recordatorios. Android puede restringir permisos especiales de aplicaciones instaladas desde archivos; utiliza las opciones que ofrezca la información de la aplicación en tu teléfono.

## Conectar los grupos y comunidades de WhatsApp

La vía de notificaciones de la versión anterior no da el catálogo ni el historial. Esta versión incluye una conexión de dispositivo adicional con **whatsmeow, cliente no oficial**. No es la API oficial de Meta. WhatsApp advierte de posibles restricciones o suspensión de cuentas que se vinculen mediante aplicaciones no oficiales. La app muestra este aviso antes de continuar. Puedes conservar la opción por notificaciones o compartir y pegar mensajes si prefieres no vincularla. La importación de historial `.txt` se ofrece para los grupos ya autorizados en el catálogo vinculado.

1. Abre **Conexiones → WhatsApp → Vincular WhatsApp** y lee el aviso de acceso.
2. Introduce tu número con código de país. No se solicita tu contraseña ni un código SMS.
3. La app obtiene un código de vinculación. En el WhatsApp oficial abre **Dispositivos vinculados → Vincular un dispositivo → Vincular con el número de teléfono**, si esa opción está disponible, e introduce el código. Regresa a Agenda Clara. Si caduca, solicita otro.
4. Una conexión autenticada consulta los grupos a los que perteneces y los subgrupos de comunidad mediante consultas de catálogo, **sin depender de que llegue un mensaje**. Pulsa Actualizar grupos para repetir la consulta. Busca por nombre de grupo o comunidad; el filtro Solo comunidades muestra comunidades y sus subgrupos.
5. Toca una comunidad para ver sus grupos. Después toca un grupo y pulsa **Permitir lectura**. Esta autorización es para **leer e interpretar el chat**, incluidos los mensajes disponibles del periodo elegido y los nuevos. La tarjeta cambia a verde. Los subgrupos que solo aparecen como metadatos, sin pertenencia confirmada, no se pueden autorizar; únete desde WhatsApp y actualiza.
6. La selección inicia la revisión del historial que WhatsApp haya entregado. El resultado aparece en **Revisar**. No se crean tareas al vincular, seleccionar ni interpretar.
7. Una propuesta de mensaje nuevo puede notificarte con **Agregar / No agregar**. Agregar abre el editor; **solo Guardar crea una tarea**. Volver conserva la propuesta. No agregar la descarta.

La sesión puede aparecer en la lista de dispositivos como Agenda Clara o como un cliente Chrome/Linux, según lo que muestre WhatsApp. Solo se incluye vinculación por código; no hay lector QR en esta entrega.

### El alcance del permiso de lectura

La vinculación concede acceso amplio al dispositivo adicional. El protocolo puede entregar lotes de mensajes de la cuenta. La aplicación filtra las conversaciones seleccionadas antes de extraer su texto para el analizador o guardarlo en su tabla de mensajes. La biblioteca maneja las claves y metadatos necesarios para la sesión; el enlace no es un permiso de WhatsApp limitado exclusivamente a esos grupos.

Las claves de sesión se guardan en almacenamiento privado del teléfono, excluido de las copias de seguridad de la app. No se envían chats a un modelo de IA ni a un servidor propio. La conexión sí utiliza Internet para comunicarse con WhatsApp. No se incluye una función para enviar mensajes a contactos, responder, escribir en grupos, gestionar miembros ni marcar conversaciones como leídas.

La conexión activa usa un servicio visible con una notificación **Pausar**. También puedes pausar desde la app. Android puede cerrar la conexión o retrasarla; al abrir la app se intenta reanudar una sesión cuya lectura siga autorizada. No se inicia esta conexión al reiniciar el teléfono.

Toca de nuevo un grupo seleccionado para **Revocar lectura**: se desmarca y se quitan sus textos y propuestas de esta conexión. Las tareas ya guardadas se conservan. **Desvincular y borrar mensajes locales** intenta cerrar el dispositivo en WhatsApp y quitar los datos locales de esa sesión. Requiere red; si falla, revoca el dispositivo desde el WhatsApp oficial y vuelve a la app.

### Historial disponible y mensajes antiguos

El historial se interpreta respecto de la **fecha original del mensaje**: “mañana” en un mensaje del 10 de octubre se propone para el 11 de octubre, aunque lo revises después. Una fecha ya pasada se marca como **estado sin confirmar**; el analizador no sabe si la tarea sigue pendiente, si se terminó fuera del chat o si te corresponde.

Puedes elegir últimos 30 días, 90 días o un año. Se conserva y analiza un máximo de **4.000 mensajes de texto recientes por grupo** dentro del periodo. Al vincular se solicita historial de hasta un año con un límite de tamaño de 64 MB; WhatsApp puede entregar solo una parte, omitir chats o impedir consultar más. No equivale a recuperar todo el historial del teléfono.

- **Revisar historial disponible** procesa los lotes sincronizados para ese grupo. Una caché evita descargar y procesar otra vez el mismo lote durante la sesión y autorización vigentes.
- **Mensajes anteriores → elegir cantidad → Solicitar** pide otra página al dispositivo principal a partir del mensaje más antiguo conocido. Requiere un mensaje de referencia y que WhatsApp acepte la solicitud. Su recepción es asíncrona y también respeta el periodo elegido.
- La revisión del historial deja las propuestas en la bandeja, sin emitir una notificación por cada mensaje antiguo.

Si faltan mensajes antiguos, usa **Importar historial .txt** en la tarjeta de un grupo autorizado. Exporta ese chat sin archivos multimedia desde el WhatsApp oficial y selecciona su `.txt`. Se admiten formatos habituales de Android e iOS, continuaciones multilínea y horas de 12 o 24 horas. Se interpreta **día/mes/año** con la zona horaria actual del teléfono; revisa archivos procedentes de otras regiones. Límite de archivo: 8 MB y 100.000 líneas; se conservan hasta 4.000 mensajes. La app no puede verificar a qué grupo pertenece el archivo: elige el correcto. Importar el mismo archivo mantiene identificadores estables; combinar importación y sincronización puede producir propuestas repetidas porque el exportado no incluye los identificadores originales de WhatsApp.

### Qué interpreta el detector

El detector funciona localmente con reglas en español y contexto acotado. Una palabra como “trabajo” o “tarea” por sí sola no activa una propuesta: se buscan instrucciones concretas o anuncios de actividades con fecha. Se filtran preguntas, expresiones inciertas, conversación casual y expresiones explícitas de cancelación o finalización.

Se consideran respuestas citadas para actualizar una fecha y para retirar una propuesta cancelada. Que otro integrante diga que entregó algo no se toma como que tú lo entregaste. Se analizan hasta 120 mensajes recientes para novedades y hasta 4.000 para la revisión histórica. Las decisiones se muestran con su motivo y texto original.

**No es comprensión completa del lenguaje.** Puede omitir tareas, interpretar mal ironías, referencias, destinatarios o cambios de estado, y generar falsos positivos. No analiza contenido de imágenes, audios ni documentos; solo texto y pies de foto. Los archivos de exportación tampoco conservan todos los enlaces de respuesta. Revisa cada propuesta antes de guardarla.

### Opción por notificaciones

Se mantiene la alternativa de Android para mensajes nuevos, con sus propios chats marcados. Solo descubre nombres que aparezcan en notificaciones y no recupera historial. La vinculación nueva desactiva esta captura anterior para evitar tener las dos rutas activas. Mientras la lectura vinculada está activa, el servicio de notificaciones no interpreta mensajes. No hace falta conceder acceso a todas tus notificaciones para usar la nueva vinculación.

## Diseño, fechas y rendimiento

La agenda muestra progreso real, pendientes y urgentes; la barra inferior usa iconos y texto. Los grupos seleccionados tienen fondo verde y marca. Las listas muestran elementos por páginas para no crear todas las tarjetas a la vez; la búsqueda de tareas reutiliza los datos cargados. Los análisis de historial, la conexión y la importación se ejecutan fuera de la interfaz. Los patrones frecuentes del detector se compilan una vez y los mensajes se guardan con índices por grupo y fecha.

El editor mantiene **Hoy / Mañana / Otra fecha**, calendario mensual, reloj nativo de **12 horas**, Fin del día y múltiples anticipaciones, incluidas tres días y una semana. Más opciones contiene notas, repetición, duración y urgencia manual. La prioridad cambia: urgente hasta 48 horas, pendiente hasta 7 días y próxima después; las vencidas y completadas se distinguen. Completar detiene los recordatorios. Android puede retrasar avisos sin alarmas exactas.

## Google Calendar

Configura tu cuenta Google y la sincronización de Calendario en Android. En **Conexiones → Calendar**, concede los permisos y toca los calendarios reales que quieras consultar. Elige un destino editable para las tareas que marques como vinculadas. Guardar y reenviar una tarea vinculada actualiza su evento existente. Revisar eventos envía los elegidos a propuestas para tu confirmación.

Se usa `CalendarContract` y la sincronización del sistema. No se pide una contraseña ni se implementa OAuth propio. No hay sincronización bidireccional completa: editar un evento ajeno no actualiza automáticamente una tarea importada y borrar una tarea conserva su evento. La subida a Google depende de tu sincronizador, cuenta y red.

## Widgets y foto

El widget de tareas conserva sus casillas y su botón para crear una actividad. El widget de foto muestra la imagen sin botón superpuesto. **Dos toques seguidos** sobre la misma foto abren cambio de imagen, mostrar completa o rellenar, zoom y encuadre. Un toque aislado no abre el editor. La ventana de reconocimiento es de 900 ms por widget o la del sistema si es mayor; la entrega de toques depende del lanzador.

Para el tamaño exterior, mantén pulsado el widget en el inicio y arrastra sus bordes según el lanzador. La foto se copia al almacenamiento privado mediante el selector de Android, sin permiso general de galería. Se conservan los ajustes anteriores al actualizar.

## Proyecto, compilación y licencias

La app instalable es Android nativa en Java; el transporte vinculado usa Go y JNI. El plugin Code Tytor: Python se consultó para una referencia de análisis de conversaciones; sus resultados no se usan como prueba de funcionamiento. Las herramientas de compilación y auditoría del proyecto están escritas en Python.

El proyecto incluye los binarios nativos ARM64 y x86_64, fuentes propias, fuentes utilizadas de las dependencias en `whatsapp-native/vendor/`, pruebas, Gradle Wrapper y una clave de desarrollo compatible con la entrega anterior. No contiene cuentas, mensajes reales ni fotografías personales.

La integración usa libsignal bajo GPLv3. La aplicación se entrega con su fuente bajo **GPLv3** y las dependencias conservan sus licencias y avisos. Consulta `LICENSE`, `THIRD_PARTY_NOTICES.md` y Conexiones → Avisos y widgets → Licencias y código fuente. Se incluye la clave de desarrollo para que puedas construir actualizaciones; es una clave distribuida con el proyecto, no una credencial privada de publicación.

Abre el proyecto en Android Studio con JDK 17 y SDK 35. Gradle usa los binarios nativos incluidos. Para la compilación por herramientas:

```sh
python3 tools/build_apk.py --android-jar /ruta/android.jar --build-tools /ruta/build-tools --ecj /ruta/ecj.jar
python3 tools/test_core.py --ecj /ruta/ecj.jar
python3 tools/audit_project.py . dist/Agenda-Clara-1.2.1.apk
```

Para recompilar el transporte se usaron Go 1.27.3 y NDK r28c. Las versiones están fijadas en `whatsapp-native/go.mod`, `go.sum` y `vendor/modules.txt`:

```sh
python3 tools/build_whatsapp.py --go /ruta/go/bin/go --ndk /ruta/android-ndk-r28c
cd whatsapp-native
go test -buildvcs=false -race -json ./...
```

Las pruebas Android están en `tests/android/`; `tools/build_instrumentation.py` genera un APK separado. Utilizan solo datos sintéticos y un calendario local del emulador. `verification/` contiene los informes de esta versión y sus límites.

## Fuentes de plataforma

- [WhatsApp: aplicaciones no oficiales y restricciones](https://faq.whatsapp.com/1217634902127718/).
- [WhatsApp: historial en dispositivos vinculados](https://faq.whatsapp.com/653480766448040).
- [WhatsApp: exportar un chat](https://faq.whatsapp.com/1180414079177245).
- [whatsmeow: documentación del cliente](https://pkg.go.dev/go.mau.fi/whatsmeow), consultas `GetJoinedGroups`, `GetSubGroups`, vinculación `PairPhone` y solicitudes `BuildHistorySyncRequest`.
- [Android: tipos de servicio visible](https://developer.android.com/develop/background-work/services/fgs/service-types).
- [Android: Calendar Provider](https://developer.android.com/identity/providers/calendar-provider).
- [Android: widgets](https://developer.android.com/develop/ui/views/appwidgets/overview).
