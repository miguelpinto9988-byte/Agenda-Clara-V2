#!/usr/bin/env python3
"""Regression guards for the Android delivery A source stage (not emulation)."""
from pathlib import Path
import hashlib
from apply_delivery_a import EXPECTED, BASE, GRADLE, STAGE, NEW

assert all((BASE/name).is_file() and (BASE/name).read_bytes()==(STAGE/name).read_bytes()
           for name in (*EXPECTED,*NEW))
source=lambda name:(BASE/name).read_text(encoding='utf-8')
assert 'versionCode 59' in GRADLE.read_text() and "versionName '3.13.3'" in GRADLE.read_text()
assert "applicationId 'pe.agendaclara.app'" in GRADLE.read_text()
main=source('MainActivity.java')
assert 'CalendarStudyHub.render(this)' in main
assert 'topPlus.setVisibility(page==1?View.GONE:View.VISIBLE)' in main
assert 'calendar_study_tab' in main
hub=source('CalendarStudyHub.java')
assert all(x in hub for x in ('Calendario','Plan de estudio','CalendarVisuals.month','StickyNotesUi.calendar','MAX_SCHEDULES'))
assert 'Importación inteligente de sílabos: disponible en la Entrega B.' in hub
schedule=source('ScheduleDatabase.java')
assert 'super(c,"class_schedule.db",null,2)' in schedule
assert 'ALTER TABLE sessions ADD COLUMN schedule_id INTEGER NOT NULL DEFAULT 1' in schedule
assert 'DROP TABLE sessions' not in schedule and 'DELETE FROM sessions' not in schedule
assert 'MAX_SCHEDULES=10' in schedule
assert 'UNIQUE(schedule_id,identity)' in schedule
assert 'ScheduleCourseColors.same(old.course,s.course)' in schedule
assert 'if(old.day==s.day&&old.start==s.start&&old.end==s.end' in schedule
activity=source('ScheduleActivity.java')
assert all(x in activity for x in ('promptScheduleName','ScheduleDatabase','pendingNewPhotoSchedule','ScheduleNameDetector.suggest','deleteCurrent','renameCurrent'))
assert 'forSchedule(ScheduleDatabase.get(this).activeId())' in activity
backup=source('ScheduleBackup.java')
assert '"schema",2' in backup and 'schema!=1&&schema!=2' in backup
assert '"schedules",plans' in backup and 'scheduleId' in backup
registry=source('CategoryRegistry.java')
assert 'renameScheduleCategory' in registry and 'deleteScheduleCategory' in registry
assert 'ScheduleDatabase.get(c).ownsCategory' in registry
print('PASS Entrega A: navegación, categorías protegidas, hasta 10 horarios y respaldo v1/v2')
print('PASS: curso aislado por schedule_id y fecha de sílabos diferida a Entrega B')
