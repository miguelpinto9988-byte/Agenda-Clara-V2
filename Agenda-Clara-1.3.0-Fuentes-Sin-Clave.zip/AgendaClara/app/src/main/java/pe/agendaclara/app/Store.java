package pe.agendaclara.app;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.util.*;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

public final class Store extends SQLiteOpenHelper {
    private static Store instance;
    private final Context context;
    public static synchronized Store get(Context c){if(instance==null)instance=new Store(c.getApplicationContext());return instance;}
    private Store(Context c){super(c,"agenda_clara.db",null,4);context=c;setWriteAheadLoggingEnabled(true);}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,notes TEXT NOT NULL,source TEXT NOT NULL,due INTEGER NOT NULL,created INTEGER NOT NULL,done INTEGER NOT NULL,urgent INTEGER NOT NULL,offsets TEXT NOT NULL,repeat_minutes INTEGER NOT NULL,duration INTEGER NOT NULL,event_id INTEGER NOT NULL,calendar_id INTEGER NOT NULL,calendar_enabled INTEGER NOT NULL,origin_key TEXT UNIQUE,completed_at INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX tasks_due ON tasks(done,due)");db.execSQL("CREATE INDEX tasks_completed_at ON tasks(done,completed_at)");
        db.execSQL("CREATE TABLE inbox(id INTEGER PRIMARY KEY AUTOINCREMENT,origin_key TEXT UNIQUE NOT NULL,title TEXT NOT NULL,original TEXT NOT NULL,source TEXT NOT NULL,due INTEGER NOT NULL,date_known INTEGER NOT NULL,time_known INTEGER NOT NULL,reason TEXT NOT NULL,created INTEGER NOT NULL,state INTEGER NOT NULL DEFAULT 0)");
        createChats(db);
        createLinked(db);
    }
    private void createChats(SQLiteDatabase db){db.execSQL("CREATE TABLE IF NOT EXISTS chats(chat_key TEXT PRIMARY KEY,package_name TEXT NOT NULL,title TEXT NOT NULL,is_group INTEGER NOT NULL DEFAULT 0,selected INTEGER NOT NULL DEFAULT 0,selected_since INTEGER NOT NULL DEFAULT 0,last_seen INTEGER NOT NULL)");}
    private void createLinked(SQLiteDatabase db){
        for(String column:new String[]{"jid TEXT NOT NULL DEFAULT ''","parent_jid TEXT NOT NULL DEFAULT ''","community INTEGER NOT NULL DEFAULT 0","joined INTEGER NOT NULL DEFAULT 1","scan_state TEXT NOT NULL DEFAULT ''","scanned INTEGER NOT NULL DEFAULT 0"})db.execSQL("ALTER TABLE chats ADD COLUMN "+column);
        for(String column:new String[]{"chat_key TEXT NOT NULL DEFAULT ''","message_id TEXT NOT NULL DEFAULT ''","historical INTEGER NOT NULL DEFAULT 0"})db.execSQL("ALTER TABLE inbox ADD COLUMN "+column);
        db.execSQL("CREATE TABLE messages(chat_key TEXT NOT NULL,message_id TEXT NOT NULL,body TEXT NOT NULL,quoted TEXT NOT NULL,reply_id TEXT NOT NULL,sender TEXT NOT NULL,stamp INTEGER NOT NULL,from_me INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(chat_key,message_id))");
        db.execSQL("CREATE INDEX messages_time ON messages(chat_key,stamp)");
        db.execSQL("CREATE INDEX inbox_chat ON inbox(chat_key,state)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int old,int next){
        if(old<2)createChats(db);
        if(old<3)createLinked(db);
        if(old<4){
            db.execSQL("ALTER TABLE tasks ADD COLUMN completed_at INTEGER NOT NULL DEFAULT 0");
            // No completion timestamp existed in v1.2.1: give prior done tasks a full hour.
            db.execSQL("UPDATE tasks SET completed_at=? WHERE done=1 AND completed_at=0",new Object[]{System.currentTimeMillis()});
            db.execSQL("CREATE INDEX IF NOT EXISTS tasks_completed_at ON tasks(done,completed_at)");
        }
    }
    public static final class Chat {
        public String key,pkg,title,jid="",parent="",scanState="";public boolean group,selected,community,joined=true;public long selectedSince,lastSeen,scanned;
    }
    public static String chatKey(String pkg,String shortcut,String title){return hash(pkg+"\n"+(shortcut==null||shortcut.isEmpty()?"title:"+title.trim().toLowerCase(Locale.ROOT):"shortcut:"+shortcut));}
    public synchronized boolean observeChat(String key,String pkg,String title,boolean group,long now){
        Chat old=getChat(key);ContentValues v=new ContentValues();v.put("package_name",pkg);v.put("title",title);v.put("is_group",group?1:0);v.put("last_seen",now);
        if(old==null){v.put("chat_key",key);getWritableDatabase().insertOrThrow("chats",null,v);return true;}
        getWritableDatabase().update("chats",v,"chat_key=?",new String[]{key});return !old.title.equals(title)||old.group!=group;
    }
    private Chat chat(Cursor c){Chat k=new Chat();k.key=c.getString(0);k.pkg=c.getString(1);k.title=c.getString(2);k.group=c.getInt(3)!=0;k.selected=c.getInt(4)!=0;k.selectedSince=c.getLong(5);k.lastSeen=c.getLong(6);k.jid=c.getString(7);k.parent=c.getString(8);k.community=c.getInt(9)!=0;k.joined=c.getInt(10)!=0;k.scanState=c.getString(11);k.scanned=c.getLong(12);return k;}
    public synchronized Chat getChat(String key){try(Cursor c=getReadableDatabase().query("chats",null,"chat_key=?",new String[]{key},null,null,null)){return c.moveToFirst()?chat(c):null;}}
    public synchronized List<Chat> chats(){List<Chat> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("chats",null,null,null,null,null,"selected DESC,title COLLATE NOCASE")){while(c.moveToNext())out.add(chat(c));}return out;}
    public synchronized void selectChat(String key,boolean selected){ContentValues v=new ContentValues();v.put("selected",selected?1:0);v.put("selected_since",selected?System.currentTimeMillis():0);getWritableDatabase().update("chats",v,"chat_key=?",new String[]{key});}
    public synchronized long save(Task t){
        if(t.created<=0)t.created=System.currentTimeMillis();
        ContentValues v=new ContentValues();
        v.put("title",t.title);v.put("notes",t.notes);v.put("source",t.source);v.put("due",t.due);v.put("created",t.created>0?t.created:System.currentTimeMillis());
        // Once completed, edits do not restart the deletion timer.
        long oldCompletedAt=0;
        if(t.id>0)try(Cursor previous=getReadableDatabase().query("tasks",new String[]{"completed_at"},"id=? AND done=1",new String[]{""+t.id},null,null,null)){
            if(previous.moveToFirst())oldCompletedAt=previous.getLong(0);
        }
        t.completedAt=t.done?(oldCompletedAt>0?oldCompletedAt:(t.completedAt>0?t.completedAt:System.currentTimeMillis())):0;
        v.put("completed_at",t.completedAt);
        v.put("done",t.done?1:0);v.put("urgent",t.urgent?1:0);v.put("offsets",t.offsets);v.put("repeat_minutes",t.repeatMinutes);v.put("duration",t.duration);
        v.put("event_id",t.eventId);v.put("calendar_id",t.calendarId);v.put("calendar_enabled",t.calendarEnabled?1:0);
        if(t.originKey.isEmpty())v.putNull("origin_key");else v.put("origin_key",t.originKey);
        if(t.id>0)getWritableDatabase().update("tasks",v,"id=?",new String[]{""+t.id});
        else t.id=getWritableDatabase().insertOrThrow("tasks",null,v);
        CompletedTaskCleanup.schedule(context);
        return t.id;
    }
    private Task task(Cursor c){
        Task t=new Task();
        t.id=c.getLong(c.getColumnIndexOrThrow("id"));t.title=c.getString(c.getColumnIndexOrThrow("title"));t.notes=c.getString(c.getColumnIndexOrThrow("notes"));t.source=c.getString(c.getColumnIndexOrThrow("source"));
        t.due=c.getLong(c.getColumnIndexOrThrow("due"));t.created=c.getLong(c.getColumnIndexOrThrow("created"));t.done=c.getInt(c.getColumnIndexOrThrow("done"))!=0;t.completedAt=c.getLong(c.getColumnIndexOrThrow("completed_at"));t.urgent=c.getInt(c.getColumnIndexOrThrow("urgent"))!=0;
        t.offsets=c.getString(c.getColumnIndexOrThrow("offsets"));t.repeatMinutes=c.getInt(c.getColumnIndexOrThrow("repeat_minutes"));t.duration=c.getInt(c.getColumnIndexOrThrow("duration"));
        t.eventId=c.getLong(c.getColumnIndexOrThrow("event_id"));t.calendarId=c.getLong(c.getColumnIndexOrThrow("calendar_id"));t.calendarEnabled=c.getInt(c.getColumnIndexOrThrow("calendar_enabled"))!=0;
        t.originKey=c.isNull(c.getColumnIndexOrThrow("origin_key"))?"":c.getString(c.getColumnIndexOrThrow("origin_key"));return t;
    }
    public synchronized Task find(long id){
        try(Cursor c=getReadableDatabase().query("tasks",null,"id=?",new String[]{""+id},null,null,null)){return c.moveToFirst()?task(c):null;}
    }
    public synchronized Task findOrigin(String key){
        try(Cursor c=getReadableDatabase().query("tasks",null,"origin_key=?",new String[]{key},null,null,null)){return c.moveToFirst()?task(c):null;}
    }
    public synchronized List<Task> all(){
        purgeExpiredCompleted(System.currentTimeMillis());
        List<Task> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("tasks",null,null,null,null,null,"done ASC, CASE WHEN due=0 THEN 1 ELSE 0 END ASC, due ASC, created DESC")){
            while(c.moveToNext())out.add(task(c));
        }return out;
    }
    public synchronized void delete(long id){getWritableDatabase().delete("tasks","id=?",new String[]{""+id});CompletedTaskCleanup.schedule(context);}
    /** Delete only completed tasks with a recorded finish time that is at least one hour old. */
    public synchronized int purgeExpiredCompleted(long now){
        return getWritableDatabase().delete("tasks","done=1 AND completed_at>0 AND completed_at<=?",new String[]{""+(now-TaskExpiryPolicy.RETENTION_MILLIS)});
    }
    public synchronized long nextCompletedExpiry(){
        try(Cursor c=getReadableDatabase().rawQuery("SELECT MIN(completed_at) FROM tasks WHERE done=1 AND completed_at>0",null)){
            return c.moveToFirst()&&!c.isNull(0)?c.getLong(0)+TaskExpiryPolicy.RETENTION_MILLIS:0;
        }
    }
    public synchronized void linkEvent(long id,long event,long calendar){
        ContentValues v=new ContentValues();v.put("event_id",event);v.put("calendar_id",calendar);
        getWritableDatabase().update("tasks",v,"id=?",new String[]{""+id});
    }
    public static final class Inbox {
        public long id,due,created;public String key,title,original,source,reason,chatKey,messageId;public boolean dateKnown,timeKnown,historical;
    }
    public synchronized boolean offer(MessageParser.Proposal p,String source,long received){
        String key=hash(source+"\n"+p.original+"\n"+(received/86400000L));
        return offerProposal(p,source,received,key)>0;
    }
    public synchronized long offerProposal(MessageParser.Proposal p,String source,long received,String key){
        ContentValues v=new ContentValues();v.put("origin_key",key);v.put("title",p.title);v.put("original",p.original);v.put("source",source);v.put("due",p.due);
        v.put("date_known",p.dateKnown?1:0);v.put("time_known",p.timeKnown?1:0);v.put("reason",p.reason);v.put("created",received);
        return getWritableDatabase().insertWithOnConflict("inbox",null,v,SQLiteDatabase.CONFLICT_IGNORE);
    }
    public synchronized Inbox pending(long id){try(Cursor c=getReadableDatabase().query("inbox",null,"id=? AND state=0",new String[]{""+id},null,null,null)){return c.moveToFirst()?inboxRow(c):null;}}
    /** The sole transition from proposal to task: explicit Save, in one transaction. */
    public synchronized boolean acceptProposal(Task t,long inboxId){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            try(Cursor c=db.query("inbox",new String[]{"id"},"id=? AND state=0",new String[]{""+inboxId},null,null,null)){if(!c.moveToFirst())return false;}
            save(t);dismiss(inboxId);db.setTransactionSuccessful();return true;
        }finally{db.endTransaction();}
    }
    public synchronized List<Inbox> inbox(){
        List<Inbox> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("inbox",null,"state=0",null,null,null,"created DESC","200")){
            while(c.moveToNext()){
                out.add(inboxRow(c));
            }
        }return out;
    }
    private Inbox inboxRow(Cursor c){
        Inbox p=new Inbox();p.id=c.getLong(c.getColumnIndexOrThrow("id"));p.due=c.getLong(c.getColumnIndexOrThrow("due"));p.created=c.getLong(c.getColumnIndexOrThrow("created"));
        p.key=c.getString(c.getColumnIndexOrThrow("origin_key"));p.title=c.getString(c.getColumnIndexOrThrow("title"));p.original=c.getString(c.getColumnIndexOrThrow("original"));p.source=c.getString(c.getColumnIndexOrThrow("source"));p.reason=c.getString(c.getColumnIndexOrThrow("reason"));
        p.chatKey=c.getString(c.getColumnIndexOrThrow("chat_key"));p.messageId=c.getString(c.getColumnIndexOrThrow("message_id"));p.historical=c.getInt(c.getColumnIndexOrThrow("historical"))!=0;
        p.dateKnown=c.getInt(c.getColumnIndexOrThrow("date_known"))!=0;p.timeKnown=c.getInt(c.getColumnIndexOrThrow("time_known"))!=0;return p;
    }
    public synchronized void dismiss(long id){ContentValues v=new ContentValues();v.put("state",1);getWritableDatabase().update("inbox",v,"id=?",new String[]{""+id});}
    public synchronized void clearInbox(){getWritableDatabase().delete("inbox",null,null);}
    public static String linkedKey(String jid){return hash("linked:"+jid);}
    public synchronized void linkedGroup(String jid,String title,String parent,boolean community,boolean joined,long now){
        String key=linkedKey(jid);observeChat(key,"linked",title,true,now);
        ContentValues v=new ContentValues();v.put("jid",jid);v.put("parent_jid",parent);v.put("community",community?1:0);v.put("joined",joined?1:0);
        getWritableDatabase().update("chats",v,"chat_key=?",new String[]{key});
    }
    public synchronized void scanState(String key,String state){ContentValues v=new ContentValues();v.put("scan_state",state);v.put("scanned",System.currentTimeMillis());getWritableDatabase().update("chats",v,"chat_key=?",new String[]{key});}
    public synchronized boolean recordMessage(String key,ConversationAnalyzer.Message m){
        Chat chat=getChat(key);if(chat==null||!chat.selected||chat.jid.isEmpty()||!Prefs.get(context).getBoolean("wa_reading",false))return false;
        ContentValues v=new ContentValues();v.put("chat_key",key);v.put("message_id",m.id);v.put("body",m.body.length()>12000?m.body.substring(0,12000):m.body);v.put("quoted",m.quoted.length()>4000?m.quoted.substring(0,4000):m.quoted);v.put("reply_id",m.reply);v.put("sender",m.sender);v.put("stamp",m.time);v.put("from_me",m.fromMe?1:0);
        SQLiteDatabase db=getWritableDatabase();db.beginTransactionNonExclusive();try{
            db.insertWithOnConflict("messages",null,v,SQLiteDatabase.CONFLICT_REPLACE);
            db.delete("messages","chat_key=? AND stamp<?",new String[]{key,""+(System.currentTimeMillis()-Prefs.get(context).getInt("wa_history_days",90)*86400000L)});
            db.execSQL("DELETE FROM messages WHERE chat_key=? AND message_id IN (SELECT message_id FROM messages WHERE chat_key=? ORDER BY stamp DESC,message_id DESC LIMIT -1 OFFSET 4000)",new Object[]{key,key});
            db.setTransactionSuccessful();return true;
        }finally{db.endTransaction();}
    }
    public synchronized List<ConversationAnalyzer.Message> messages(String key,int limit){
        List<ConversationAnalyzer.Message> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("messages",null,"chat_key=?",new String[]{key},null,null,"stamp DESC,message_id DESC",""+Math.max(1,Math.min(4000,limit)))){while(c.moveToNext()){
            ConversationAnalyzer.Message m=new ConversationAnalyzer.Message();m.id=c.getString(c.getColumnIndexOrThrow("message_id"));m.body=c.getString(c.getColumnIndexOrThrow("body"));m.quoted=c.getString(c.getColumnIndexOrThrow("quoted"));m.reply=c.getString(c.getColumnIndexOrThrow("reply_id"));m.sender=c.getString(c.getColumnIndexOrThrow("sender"));m.time=c.getLong(c.getColumnIndexOrThrow("stamp"));m.fromMe=c.getInt(c.getColumnIndexOrThrow("from_me"))!=0;out.add(m);
        }}Collections.reverse(out);return out;
    }
    public synchronized ConversationAnalyzer.Message message(String key,String id){
        try(Cursor c=getReadableDatabase().query("messages",null,"chat_key=? AND message_id=?",new String[]{key,id},null,null,null)){
            if(!c.moveToFirst())return null;ConversationAnalyzer.Message m=new ConversationAnalyzer.Message();m.id=c.getString(c.getColumnIndexOrThrow("message_id"));m.body=c.getString(c.getColumnIndexOrThrow("body"));m.quoted=c.getString(c.getColumnIndexOrThrow("quoted"));m.reply=c.getString(c.getColumnIndexOrThrow("reply_id"));m.sender=c.getString(c.getColumnIndexOrThrow("sender"));m.time=c.getLong(c.getColumnIndexOrThrow("stamp"));m.fromMe=c.getInt(c.getColumnIndexOrThrow("from_me"))!=0;return m;
        }
    }
    public synchronized int messageCount(String key){try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM messages WHERE chat_key=?",new String[]{key})){return c.moveToFirst()?c.getInt(0):0;}}
    public synchronized void trimMessages(String key,int days){
        getWritableDatabase().delete("messages","chat_key=? AND stamp<?",new String[]{key,""+(System.currentTimeMillis()-days*86400000L)});
        getWritableDatabase().execSQL("DELETE FROM messages WHERE chat_key=? AND message_id NOT IN (SELECT message_id FROM messages WHERE chat_key=? ORDER BY stamp DESC LIMIT 4000)",new Object[]{key,key});
    }
    public synchronized long offerLinked(ConversationAnalyzer.Finding f,Chat chat,boolean historical){
        String key=hash(chat.key+"\n"+f.key);long id=offerProposal(f.proposal,"WhatsApp · "+chat.title,f.message.time,key);
        ContentValues v=new ContentValues();v.put("chat_key",chat.key);v.put("message_id",f.message.id);v.put("historical",historical?1:0);v.put("reason",f.proposal.reason);v.put("original",f.proposal.original);v.put("due",f.proposal.due);v.put("date_known",f.proposal.dateKnown?1:0);v.put("time_known",f.proposal.timeKnown?1:0);v.put("title",f.proposal.title);
        getWritableDatabase().update("inbox",v,"origin_key=? AND state=0",new String[]{key});return id;
    }
    public synchronized List<Long> withdrawMissing(String key,Set<String> messageIds,Set<String> origins){
        List<Long> ids=new ArrayList<>();try(Cursor c=getReadableDatabase().query("inbox",new String[]{"id","origin_key","message_id"},"chat_key=? AND state=0",new String[]{key},null,null,null)){while(c.moveToNext())if(messageIds.contains(c.getString(2))&&!origins.contains(c.getString(1)))ids.add(c.getLong(0));}
        ContentValues v=new ContentValues();v.put("state",2);for(long id:ids)getWritableDatabase().update("inbox",v,"id=?",new String[]{""+id});return ids;
    }
    public synchronized List<Long> revokeReading(String key){
        List<Long> ids=new ArrayList<>();SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
            selectChat(key,false);db.delete("messages","chat_key=?",new String[]{key});
            try(Cursor c=db.query("inbox",new String[]{"id"},"chat_key=?",new String[]{key},null,null,null)){while(c.moveToNext())ids.add(c.getLong(0));}
            db.delete("inbox","chat_key=?",new String[]{key});scanState(key,"");db.setTransactionSuccessful();
        }finally{db.endTransaction();}return ids;
    }
    public synchronized void clearLinked(){
        for(Chat c:chats())if(!c.jid.isEmpty())revokeReading(c.key);
        getWritableDatabase().delete("chats","package_name=?",new String[]{"linked"});
    }
    public static String hash(String s){return TextHash.of(s);}
}
