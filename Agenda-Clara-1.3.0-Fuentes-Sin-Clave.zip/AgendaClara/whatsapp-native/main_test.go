package main

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"

	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/proto/waCommon"
	"go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/proto/waHistorySync"
	"go.mau.fi/whatsmeow/proto/waWeb"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"google.golang.org/protobuf/proto"
)

func TestConsentBeforeHistoryExtraction(t *testing.T) {
	c, err := sqlstore.New(context.Background(), "sqlite3", "file:"+filepath.Join(t.TempDir(), "test.db")+"?_foreign_keys=on", nil)
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	device, err := c.GetFirstDevice(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	tr := &transport{client: whatsmeow.NewClient(device, nil), selected: map[string]bool{"123@g.us": true}, enabled: true, days: 90, anchors: map[string]*types.MessageInfo{}, queue: make(chan object, 10), stop: make(chan struct{})}
	stamp := uint64(time.Now().Add(-time.Hour).Unix())
	conv := func(id, text string) *waHistorySync.Conversation {
		return &waHistorySync.Conversation{ID: proto.String(id), Messages: []*waHistorySync.HistorySyncMsg{{Message: &waWeb.WebMessageInfo{Key: &waCommon.MessageKey{RemoteJID: proto.String(id), Participant: proto.String("999@s.whatsapp.net"), ID: proto.String("test-one"), FromMe: proto.Bool(false)}, MessageTimestamp: &stamp, Message: &waE2E.Message{Conversation: proto.String(text)}}}}}
	}
	h := &waHistorySync.HistorySync{Conversations: []*waHistorySync.Conversation{conv("456@g.us", "private unselected text"), conv("123@g.us", "Entregar informe mañana a las 3 pm")}}
	if got := tr.processHistory(h, "", nil); got != 1 {
		t.Fatalf("expected one selected message, got %d", got)
	}
	select {
	case e := <-tr.queue:
		if e["jid"] != "123@g.us" || e["historical"] != true {
			t.Fatal("unexpected history event")
		}
	default:
		t.Fatal("selected message missing")
	}
	if len(tr.queue) != 0 {
		t.Fatal("unselected content reached app queue")
	}
	if _, exists := tr.anchors["456@g.us"]; exists {
		t.Fatal("unselected message anchor retained")
	}
	tr.mu.Lock()
	tr.selected = map[string]bool{}
	tr.mu.Unlock()
	if got := tr.processHistory(h, "", nil); got != 0 || len(tr.queue) != 0 {
		t.Fatal("revoked group produced content")
	}
	tr.mu.Lock()
	tr.selected = map[string]bool{"123@g.us": true}
	tr.enabled = false
	tr.mu.Unlock()
	if got := tr.processHistory(h, "", nil); got != 0 {
		t.Fatal("paused reading produced content")
	}
}

func TestNoHistoryWithoutConsent(t *testing.T) {
	tr := &transport{selected: map[string]bool{}, enabled: true}
	if tr.allowed("123@g.us") {
		t.Fatal("consent must be explicit")
	}
	if err := tr.more("123@g.us",50); err == nil {
		t.Fatal("older-history request accepted without consent")
	}
}

func TestInlineHistoryNotPersisted(t *testing.T) {
	tr := &transport{dir: t.TempDir(), notifications: []*waE2E.HistorySyncNotification{{InitialHistBootstrapInlinePayload: []byte("unselected inline message body")}, {DirectPath: proto.String("encrypted-history-pointer")}}}
	tr.saveNotifications()
	b, err := os.ReadFile(filepath.Join(tr.dir, "history-pointers.json"))
	if err != nil {
		t.Fatal(err)
	}
	var pointers [][]byte
	if err = json.Unmarshal(b, &pointers); err != nil {
		t.Fatal(err)
	}
	if len(pointers) != 1 {
		t.Fatal("inline history persisted before per-chat selection")
	}
	var n waE2E.HistorySyncNotification
	if err = proto.Unmarshal(pointers[0], &n); err != nil || n.GetDirectPath() != "encrypted-history-pointer" {
		t.Fatal("pointer serialization failed")
	}
}

func TestHistoryPageSizeInActualProtocol(t *testing.T) {
    jid:=types.NewJID("123","g.us")
    tr:=&transport{client:&whatsmeow.Client{},selected:map[string]bool{jid.String():true},enabled:true,anchors:map[string]*types.MessageInfo{jid.String():{MessageSource:types.MessageSource{Chat:jid},ID:"oldest-anchor",Timestamp:time.Unix(1700000000,0)}}}
    for _,count:=range []int{10,20,30,40,50,0}{msg,err:=tr.moreRequest(jid.String(),count);if err!=nil{t.Fatal(err)};r:=msg.GetProtocolMessage().GetPeerDataOperationRequestMessage().GetHistorySyncOnDemandRequest();want:=count;if want==0{want=50};if int(r.GetOnDemandMsgCount())!=want||r.GetChatJID()!=jid.String()||r.GetOldestMsgID()!="oldest-anchor"{t.Fatalf("wrong request %d: %v",count,r)}}
    for _,count:=range []int{-10,1,9,11,25,49,51,1000}{if _,err:=tr.moreRequest(jid.String(),count);err==nil{t.Fatalf("invalid count %d",count)}}
    tr.enabled=false;for _,count:=range []int{10,20,30,40,50}{if _,err:=tr.moreRequest(jid.String(),count);err==nil{t.Fatal("paused request")}}
}
