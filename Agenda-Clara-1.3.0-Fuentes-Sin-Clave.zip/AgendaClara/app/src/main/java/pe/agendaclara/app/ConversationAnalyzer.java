package pe.agendaclara.app;

import java.time.ZoneId;
import java.util.*;
import java.util.regex.Pattern;

/** Bounded conversation context, quoted replies and source-time date interpretation. */
public final class ConversationAnalyzer {
    public static final class Message {
        public String id="",body="",quoted="",reply="",sender="";public long time;public boolean fromMe;
    }
    public static final class Finding {
        public Message message;public MessageParser.Proposal proposal;public String key;
    }
    private static final Pattern UPDATE=Pattern.compile("\\b(?:para|hasta|fecha|entrega|plazo|sera|queda|es el|a las)\\b");
    private static final Pattern CANCEL=Pattern.compile("\\b(?:cancelad[oa]|se cancela|se cancelo|suspendid[oa]|se suspende|sin efecto)\\b");
    public static List<Finding> analyze(List<Message> messages,ZoneId zone,long now){
        List<Message> ordered=new ArrayList<>(messages);Collections.sort(ordered,(a,b)->Long.compare(a.time,b.time));
        if(ordered.size()>4000)ordered=new ArrayList<>(ordered.subList(ordered.size()-4000,ordered.size()));
        Map<String,Message> replies=new HashMap<>();for(Message m:ordered)if(!m.reply.isEmpty()&&ActivityClassifier.isClosed(m.body))replies.put(m.reply,m);
        Map<String,Message> updates=new HashMap<>();
        for(Message m:ordered)if(!m.reply.isEmpty()&&!m.quoted.isEmpty()&&!ActivityClassifier.isClosed(m.body)&&UPDATE.matcher(MessageParser.normalize(m.body)).find()){
            MessageParser.Proposal a=MessageParser.parseOne(m.quoted,m.time,zone,false),d=MessageParser.parseOne(m.body,m.time,zone,true);
            if(a.action&&d.dateKnown&&!d.ambiguous)updates.put(m.reply,m);
        }
        List<Finding> out=new ArrayList<>();
        for(Message m:ordered){
            if(updates.containsKey(m.id))continue;
            Message closure=replies.get(m.id);
            // Only an explicit cancellation, the user's own completion or the original
            // author's completion can suppress the linked suggestion. Other members' work
            // is not assumed to complete the user's assignment.
            if(closure!=null&&closure.time>=m.time&&(CANCEL.matcher(MessageParser.normalize(closure.body)).find()||closure.fromMe||closure.sender.equals(m.sender)))continue;
            boolean updated=false;
            List<MessageParser.Proposal> proposals=MessageParser.parse(m.body,m.time,zone,false);
            if(proposals.isEmpty()&&!m.quoted.isEmpty()&&!ActivityClassifier.isClosed(m.body)&&UPDATE.matcher(MessageParser.normalize(m.body)).find()){
                MessageParser.Proposal activity=MessageParser.parseOne(m.quoted,m.time,zone,false);
                MessageParser.Proposal schedule=MessageParser.parseOne(m.body,m.time,zone,true);
                if(activity.action&&schedule.dateKnown&&!schedule.ambiguous&&updates.get(m.reply)==m){
                    updated=true;
                    activity.original=m.body+"\n\nRespuesta a: "+m.quoted;activity.due=schedule.due;activity.dateKnown=schedule.dateKnown;activity.timeKnown=schedule.timeKnown;activity.ambiguous=true;
                    activity.reason="Respuesta vinculada a una actividad. Confirma que la nueva fecha sustituye a la anterior.";proposals.add(activity);
                }
            }
            int index=0;
            for(MessageParser.Proposal p:proposals){
                Finding f=new Finding();f.message=m;f.proposal=p;f.key=(updated?m.reply:m.id)+":"+(index++);
                if(closure!=null){p.reason="Otro miembro informó una entrega. Confirma si esta actividad sigue pendiente para ti. "+p.reason;p.ambiguous=true;}
                if(p.dateKnown&&p.due>0&&p.due<now){p.ambiguous=true;p.reason="Fecha pasada; estado sin confirmar. "+p.reason;}
                out.add(f);
            }
        }
        return out;
    }
}
