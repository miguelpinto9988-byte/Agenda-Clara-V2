package pe.agendaclara.app;

/** Pure retention rules; timestamps use System.currentTimeMillis() in milliseconds. */
public final class TaskExpiryPolicy {
    public static final long RETENTION_MILLIS = 60L * 60L * 1000L;
    private TaskExpiryPolicy(){}
    public static long expiresAt(Task t){
        return t.done && t.completedAt > 0 ? t.completedAt + RETENTION_MILLIS : 0;
    }
    public static boolean expired(Task t,long now){
        long at=expiresAt(t);
        return at>0 && now>=at;
    }
}
