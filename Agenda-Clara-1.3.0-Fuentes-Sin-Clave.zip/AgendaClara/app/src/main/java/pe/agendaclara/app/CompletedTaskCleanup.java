package pe.agendaclara.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Schedules removal one hour after each completion using persisted SQLite timestamps. */
public final class CompletedTaskCleanup {
    private static final String ACTION="pe.agendaclara.CLEAN_COMPLETED";
    private static PendingIntent alarm(Context context,int flags){
        Intent intent=new Intent(context,CompletedTaskReceiver.class).setAction(ACTION);
        return PendingIntent.getBroadcast(context,91370,intent,flags|PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context context){
        AlarmManager manager=context.getSystemService(AlarmManager.class);
        PendingIntent pending=alarm(context,PendingIntent.FLAG_UPDATE_CURRENT);
        manager.cancel(pending);
        long expires=Store.get(context).nextCompletedExpiry();
        if(expires<=0)return;
        // setExactAndAllowWhileIdle requires special access on API 31+.
        long at=Math.max(System.currentTimeMillis()+1000L,expires);
        try{
            if(Build.VERSION.SDK_INT>=31&&!manager.canScheduleExactAlarms())manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending);
            else manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending);
        }catch(SecurityException ex){manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending);}
    }
    public static void run(Context context){
        int removed=Store.get(context).purgeExpiredCompleted(System.currentTimeMillis());
        schedule(context);
        if(removed>0){
            TaskWidget.refresh(context);
            context.sendBroadcast(new Intent(ReviewFlow.DATA_CHANGED).setPackage(context.getPackageName()));
        }
    }
}
