package pe.agendaclara.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Local category catalog. Only General is seeded; prior task categories are migrated. */
public final class CategoryRegistry {
    private static final String KEY="user_categories_v2";
    public static final int[] COLORS={0xff4359e9,0xff7660e7,0xff0d9488,0xfff59e0b,0xffef6574,0xff168dbb,0xff8b5cf6,0xff64748b};
    public static final String[] COLOR_NAMES={"Azul","Violeta","Verde","Ámbar","Coral","Turquesa","Lila","Gris"};
    private CategoryRegistry(){}
    public static final class Entry {
        public final String name;
        public final int color;
        public final String icon;
        Entry(String name,int color){this(name,color,"other");}
        Entry(String name,int color,String icon){this.name=name;this.color=color;this.icon=safeIcon(name,icon);}
        private static String safeIcon(String category,String symbol){
            if(symbol==null||symbol.trim().isEmpty()||"folder".equalsIgnoreCase(symbol.trim()))
                return "Notas".equalsIgnoreCase(category)?"sticky_note":"other";
            return symbol.trim();
        }
    }
    private static String normalize(String raw) {
        if(raw==null)return "";
        String name=raw.trim().replaceAll("\\s+"," ");
        return name.length()>28||name.matches("(?s).*\\p{Cntrl}.*")?"":name;
    }
    private static boolean has(List<Entry> list,String name) {
        for(Entry e:list)if(e.name.equalsIgnoreCase(name))return true;
        return false;
    }
    private static void store(Context context,List<Entry> list){
        JSONArray array=new JSONArray();
        for(Entry e:list){
            JSONObject object=new JSONObject();
            try{object.put("name",e.name);object.put("color",e.color);object.put("icon",e.icon);array.put(object);}
            catch(org.json.JSONException ignored){}
        }
        Prefs.get(context).edit().putString(KEY,array.toString()).apply();
    }
    public static synchronized List<Entry> all(Context context){
        SharedPreferences prefs=Prefs.get(context);
        ArrayList<Entry> items=new ArrayList<>();
        items.add(new Entry("General",COLORS[0]));
        if(prefs.contains(KEY)){
            try{
                JSONArray array=new JSONArray(prefs.getString(KEY,"[]"));
                for(int i=0;i<array.length()&&items.size()<80;i++){
                    JSONObject record=array.optJSONObject(i);
                    if(record==null)continue;
                    String name=normalize(record.optString("name",""));
                    if(!name.isEmpty()&&!has(items,name))items.add(new Entry(name,record.optInt("color",COLORS[items.size()%COLORS.length]),record.optString("icon","other")));
                }
            }catch(org.json.JSONException ignored){}
            return items;
        }
        // A one-time migration retains categories already assigned to existing tasks.
        for(Task task:Store.get(context).all()){
            String category=normalize(task.category);
            if(!category.isEmpty()&&!has(items,category)&&items.size()<80)
                items.add(new Entry(category,COLORS[items.size()%COLORS.length]));
        }
        store(context,items);
        return items;
    }
    public static synchronized String[] names(Context c){
        List<Entry> items=all(c);String[] names=new String[items.size()];
        for(int i=0;i<items.size();i++)names[i]=items.get(i).name;
        return names;
    }
    public static synchronized int color(Context c,String name){
        for(Entry e:all(c))if(e.name.equalsIgnoreCase(name))return e.color;
        return COLORS[0];
    }
    public static synchronized String icon(Context c,String name){
        for(Entry e:all(c))if(e.name.equalsIgnoreCase(name))return e.icon;
        return "other";
    }
    public static synchronized boolean save(Context c,String previous,String desired,int color){
        return save(c,previous,desired,color,icon(c,previous));
    }
    public static synchronized boolean save(Context c,String previous,String desired,int color,String icon){
        return saveInternal(c,previous,desired,color,icon,false);
    }
    public static synchronized boolean renameScheduleCategory(Context c,String previous,String desired){
        return saveInternal(c,previous,desired,color(c,previous),icon(c,previous),true);
    }
    private static boolean saveInternal(Context c,String previous,String desired,int color,String icon,boolean managed){
        if(!managed && previous!=null && ScheduleDatabase.get(c).ownsCategory(previous))return false;
        String name=normalize(desired);
        if(name.isEmpty())return false;
        List<Entry> entries=all(c);
        String old=normalize(previous);
        int oldIndex=-1;
        for(int i=0;i<entries.size();i++)if(entries.get(i).name.equalsIgnoreCase(old))oldIndex=i;
        if(oldIndex==0)return false; // General cannot be changed.
        if(oldIndex<0&&entries.size()>=80)return false;
        for(int i=0;i<entries.size();i++)if(i!=oldIndex&&entries.get(i).name.equalsIgnoreCase(name))return false;
        if(oldIndex>0){
            Store.get(c).reassignCategory(entries.get(oldIndex).name,name);
            StickyNotesStore.get(c).reassignCategory(entries.get(oldIndex).name,name);
            entries.set(oldIndex,new Entry(name,color,icon));
        }else entries.add(new Entry(name,color,icon));
        store(c,entries);StickyNotesWidget.refresh(c);return true;
    }
    public static synchronized boolean delete(Context c,String name){
        return deleteInternal(c,name,false);
    }
    public static synchronized boolean deleteScheduleCategory(Context c,String name){
        return deleteInternal(c,name,true);
    }
    private static boolean deleteInternal(Context c,String name,boolean managed){
        if(!managed && ScheduleDatabase.get(c).ownsCategory(name))return false;
        List<Entry> entries=all(c);
        for(int i=1;i<entries.size();i++)if(entries.get(i).name.equalsIgnoreCase(name)){
            Store.get(c).reassignCategory(entries.get(i).name,"General");
            StickyNotesStore.get(c).reassignCategory(entries.get(i).name,"General");
            entries.remove(i);store(c,entries);StickyNotesWidget.refresh(c);return true;
        }
        return false;
    }
}
