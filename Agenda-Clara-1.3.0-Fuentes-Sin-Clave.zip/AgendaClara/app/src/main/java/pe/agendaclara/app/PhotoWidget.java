package pe.agendaclara.app;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.graphics.*;
import android.os.Bundle;
import android.widget.*;
import java.io.*;

public final class PhotoWidget extends AppWidgetProvider {
    public static String filename(int id){return "widget_photo_"+id+".jpg";}
    public static void refresh(Context c){for(int id:AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c,PhotoWidget.class)))update(c,id);}
    public static void update(Context c,int id){
        AppWidgetManager m=AppWidgetManager.getInstance(c);
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_photo);
        File file=new File(c.getFilesDir(),filename(id));
        if(file.isFile()){
            Bitmap src=BitmapFactory.decodeFile(file.toString());
            if(src!=null){
                Bundle o=m.getAppWidgetOptions(id);int w=Math.max(100,Math.min(650,o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,220)*2));
                int h=Math.max(100,Math.min(650,o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,220)*2));
                android.content.SharedPreferences p=Prefs.get(c);
                float zoom=p.getFloat("zoom_"+id,1f),x=p.getFloat("x_"+id,.5f),y=p.getFloat("y_"+id,.5f);
                Bitmap out=crop(src,w,h,zoom,x,y,p.getBoolean("contain_"+id,false));
                v.setImageViewBitmap(R.id.photo_image,out);
                src.recycle();
            }
        }
        Intent config=new Intent(c,PhotoTapActivity.class).setData(android.net.Uri.parse("agenda://photo/tap/"+id)).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_NO_ANIMATION);
        PendingIntent click=PendingIntent.getActivity(c,30000+id,config,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.photo_image,click);
        m.updateAppWidget(id,v);
    }
    public static Bitmap crop(Bitmap src,int width,int height,float zoom,float x,float y){
        return crop(src,width,height,zoom,x,y,false);
    }
    public static Bitmap crop(Bitmap src,int width,int height,float zoom,float x,float y,boolean contain){
        Bitmap out=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Canvas cv=new Canvas(out);cv.drawColor(0xffedf1eb);
        float scale=(contain?Math.min((float)width/src.getWidth(),(float)height/src.getHeight()):Math.max((float)width/src.getWidth(),(float)height/src.getHeight()))*Math.max(1f,Math.min(3f,zoom));
        float w=src.getWidth()*scale,h=src.getHeight()*scale;
        float left=-(w-width)*Math.max(0,Math.min(1,x)),top=-(h-height)*Math.max(0,Math.min(1,y));
        cv.drawBitmap(src,null,new RectF(left,top,left+w,top+h),new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));return out;
    }
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,id);}
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle b){update(c,id);}
    @Override public void onDeleted(Context c,int[] ids){for(int id:ids){new File(c.getFilesDir(),filename(id)).delete();Prefs.get(c).edit().remove("zoom_"+id).remove("x_"+id).remove("y_"+id).remove("contain_"+id).remove("photo_tap_"+id).apply();}}
}
