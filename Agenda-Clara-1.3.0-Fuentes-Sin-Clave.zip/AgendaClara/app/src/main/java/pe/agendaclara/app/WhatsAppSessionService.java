package pe.agendaclara.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import org.json.*;
import java.io.File;
import java.util.*;
import java.util.concurrent.*;

/** Visible, user-started linked-device connection; no boot start and no message-sending surface. */
public final class WhatsAppSessionService extends Service {
    static final String CHANNEL="linked_whatsapp";
    static final int ID=91032;
    private final ScheduledExecutorService worker=Executors.newSingleThreadScheduledExecutor();
    private volatile boolean initialized=false,stopping=false;
    public static volatile boolean running=false;
    public static void start(Context c,String action,String value){
        start(c,action,value,HistoryPageOptions.saved(Prefs.get(c).getInt("wa_history_count",50)));
    }
    public static void start(Context c,String action,String value,int count){
        if("more".equals(action)&&!HistoryPageOptions.valid(count))throw new IllegalArgumentException("Elige 10, 20, 30, 40 o 50 mensajes.");
        Intent i=new Intent(c,WhatsAppSessionService.class).setAction(action).putExtra("count",count);if(value!=null)i.putExtra("value",value);
        c.startForegroundService(i);
    }
    @Override public void onCreate(){
        super.onCreate();running=true;
        NotificationManager nm=getSystemService(NotificationManager.class);
        NotificationChannel channel=new NotificationChannel(CHANNEL,"Lectura autorizada de WhatsApp",NotificationManager.IMPORTANCE_LOW);channel.setDescription("Conexión activa y control para pausarla.");nm.createNotificationChannel(channel);
        Intent open=new Intent(this,MainActivity.class).setAction("connections").putExtra("tab",0);
        PendingIntent content=PendingIntent.getActivity(this,310,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop=PendingIntent.getService(this,311,new Intent(this,WhatsAppSessionService.class).setAction("pause"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_notify).setContentTitle("Agenda Clara · WhatsApp").setContentText("Conexión para los grupos que autorices. Puedes pausarla.").setOngoing(true).setContentIntent(content).addAction(new Notification.Action.Builder(null,"Pausar",stop).build()).build();
        if(Build.VERSION.SDK_INT>=34)startForeground(ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(ID,n);
        worker.scheduleWithFixedDelay(()->{
            if(!initialized||stopping)return;
            try{JSONArray events=WhatsAppNative.events();for(int j=0;j<events.length();j++)handle(events.getJSONObject(j));}catch(Exception e){error("No se pudo leer la respuesta de la conexión.");}
        },300,500,TimeUnit.MILLISECONDS);
    }
    private JSONObject request(String op)throws JSONException{return new JSONObject().put("op",op);}
    private void init()throws Exception{
        if(initialized)return;
        File dir=new File(getNoBackupFilesDir(),"whatsapp");
        JSONObject r=WhatsAppNative.call(request("init").put("path",dir.getAbsolutePath()));initialized=true;
        Prefs.get(this).edit().putBoolean("wa_linked",r.optBoolean("linked")).apply();consents();
    }
    private void consents()throws Exception{
        JSONArray ids=new JSONArray();for(Store.Chat chat:Store.get(this).chats())if(chat.selected&&!chat.jid.isEmpty()&&chat.joined)ids.put(chat.jid);
        WhatsAppNative.call(request("consent").put("selected",ids).put("enabled",Prefs.get(this).getBoolean("wa_reading",false)).put("days",Prefs.get(this).getInt("wa_history_days",90)));
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        final String action=intent.getAction()==null?"resume":intent.getAction(),value=intent.getStringExtra("value");
        final int count=intent.getIntExtra("count",50);
        if(!Prefs.get(this).getBoolean("wa_link_consent_v1",false)){stopSelf();return START_NOT_STICKY;}
        worker.execute(()->{
            try{
                init();
                if("pause".equals(action)){
                    Prefs.get(this).edit().putBoolean("wa_reading",false).putBoolean("wa_connected",false).putString("wa_status","Lectura pausada").apply();consents();WhatsAppNative.call(request("stop"));stopping=true;stopSelf();ReviewFlow.changed(this);return;
                }
                if("logout".equals(action)){
                    WhatsAppNative.call(request("logout"));for(Store.Inbox box:Store.get(this).inbox())if(!box.chatKey.isEmpty())Reminders.cancelProposal(this,box.id);Store.get(this).clearLinked();
                    Prefs.get(this).edit().putBoolean("wa_linked",false).putBoolean("wa_reading",false).putBoolean("wa_connected",false).remove("wa_pair_code").putString("wa_status","Sesión desvinculada").apply();initialized=false;stopping=true;stopSelf();ReviewFlow.changed(this);return;
                }
                if("pair".equals(action)||"resume".equals(action)){
                    Prefs.get(this).edit().putBoolean("wa_reading",true).putString("wa_status","Conectando con WhatsApp…").apply();consents();WhatsAppNative.call(request("connect").put("phone",value==null?"":value));
                }else if("groups".equals(action))WhatsAppNative.call(request("groups"));
                else if("consent".equals(action))consents();
                else if("history".equals(action)){consents();WhatsAppNative.call(request("history").put("jid",value));}
                else if("more".equals(action)){if(!HistoryPageOptions.valid(count))throw new IllegalArgumentException("Elige de 10 a 50 mensajes, en pasos de 10.");consents();WhatsAppNative.call(request("more").put("jid",value).put("count",count));}
                ReviewFlow.changed(this);
            }catch(UnsatisfiedLinkError e){error("La conexión de WhatsApp requiere un teléfono ARM de 64 bits o x86 de 64 bits.");stopping=true;stopSelf();}
            catch(Exception e){error(e.getMessage()==null?"No se completó la conexión.":e.getMessage());}
        });
        return START_NOT_STICKY;
    }
    private void error(String message){if(!message.equals(Prefs.get(this).getString("wa_status",""))){Prefs.get(this).edit().putString("wa_status",message).apply();ReviewFlow.changed(this);}}
    private void handle(JSONObject e)throws Exception{
        Store db=Store.get(this);String type=e.optString("type");
        if("connected".equals(type)){
            Prefs.get(this).edit().putBoolean("wa_linked",true).putBoolean("wa_connected",true).remove("wa_pair_code").putString("wa_status","Conectado · cargando tus grupos").apply();consents();for(Store.Chat chat:db.chats())if(chat.selected&&!chat.jid.isEmpty())WhatsAppNative.call(request("history").put("jid",chat.jid));
        }else if("disconnected".equals(type)){
            Prefs.get(this).edit().putBoolean("wa_connected",false).putString("wa_status","Sin conexión · vuelve a abrir o reanudar").apply();
        }else if("pair_code".equals(type)){
            Prefs.get(this).edit().putString("wa_pair_code",e.optString("code")).putLong("wa_pair_expires",e.optLong("expires")).putString("wa_status","Introduce este código en WhatsApp → Dispositivos vinculados").apply();
        }else if("groups".equals(type)){
            JSONArray groups=e.getJSONArray("groups");long now=System.currentTimeMillis();
            for(int j=0;j<groups.length();j++){JSONObject g=groups.getJSONObject(j);db.linkedGroup(g.getString("jid"),g.optString("name","Grupo"),g.optString("parent"),g.optBoolean("community"),g.optBoolean("joined"),now);}
            Prefs.get(this).edit().putLong("wa_catalog_updated",now).putString("wa_status",groups.length()+" grupos disponibles · elige cuáles leer").apply();
        }else if("message".equals(type)){
            String key=Store.linkedKey(e.getString("jid"));Store.Chat chat=db.getChat(key);
            if(chat==null||!chat.selected||!Prefs.get(this).getBoolean("wa_reading",false))return;
            ConversationAnalyzer.Message m=new ConversationAnalyzer.Message();m.id=e.getString("id");m.body=e.getString("text");m.time=e.getLong("timestamp");m.sender=e.optString("sender");m.reply=e.optString("reply_id");m.quoted=e.optString("quoted");m.fromMe=e.optBoolean("from_me");
            if(m.time<=0||m.time>System.currentTimeMillis()+60000L)return;
            db.recordMessage(key,m);
            if(!e.optBoolean("historical"))ReviewFlow.analyzeLinked(this,key,false,m.id);
            return;
        }else if("history_start".equals(type)){
            String jid=e.optString("jid");for(Store.Chat chat:db.chats())if(chat.selected&&!chat.jid.isEmpty()&&(jid.isEmpty()||jid.equals(chat.jid)))db.scanState(chat.key,"Revisando mensajes disponibles…");
        }else if("history_done".equals(type)){
            String jid=e.optString("jid");for(Store.Chat chat:db.chats())if(chat.selected&&!chat.jid.isEmpty()&&(jid.isEmpty()||jid.equals(chat.jid))){
                int count=ReviewFlow.analyzeLinked(this,chat.key,true,"");int messages=db.messageCount(chat.key);
                db.scanState(chat.key,messages+" mensajes guardados · "+count+" propuestas nuevas"+(e.optInt("failed_chunks")>0?" · historial parcial":"")+(messages==0?". WhatsApp aún no entregó historial de este grupo.":""));
            }
        }else if("logged_out".equals(type)){
            try{WhatsAppNative.call(request("forget"));}catch(Exception ignored){}initialized=false;
            Prefs.get(this).edit().putBoolean("wa_linked",false).putBoolean("wa_connected",false).putBoolean("wa_reading",false).putString("wa_status",e.optString("message")).apply();for(Store.Inbox box:db.inbox())if(!box.chatKey.isEmpty())Reminders.cancelProposal(this,box.id);db.clearLinked();stopping=true;stopSelf();
        }else if("error".equals(type))error(e.optString("message","No se completó la conexión."));
        ReviewFlow.changed(this);
    }
    @Override public void onDestroy(){
        running=false;Prefs.get(this).edit().putBoolean("wa_connected",false).apply();
        if(initialized&&!stopping)try{worker.execute(()->{try{WhatsAppNative.call(request("stop"));}catch(Exception ignored){}});}catch(RejectedExecutionException ignored){}
        stopping=true;worker.shutdown();
        stopForeground(true);super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
