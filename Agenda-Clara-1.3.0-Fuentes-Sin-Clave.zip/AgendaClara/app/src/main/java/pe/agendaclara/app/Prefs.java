package pe.agendaclara.app;

import android.content.*;

public final class Prefs {
    public static SharedPreferences get(Context c){return c.getSharedPreferences("settings",Context.MODE_PRIVATE);}
    public static long calendar(Context c){return get(c).getLong("calendar",-1);}
    public static java.util.Set<String> calendars(Context c){
        java.util.Set<String> ids=new java.util.HashSet<>(get(c).getStringSet("selected_calendars",java.util.Collections.emptySet()));
        if(!get(c).contains("selected_calendars")&&calendar(c)>0)ids.add(""+calendar(c));return ids;
    }
    public static void selectCalendar(Context c,long id,boolean selected){java.util.Set<String> ids=calendars(c);if(selected)ids.add(""+id);else ids.remove(""+id);get(c).edit().putStringSet("selected_calendars",ids).apply();}
}
