#!/usr/bin/env python3
"""Build native instrumentation separately from the production app."""
import argparse, subprocess, zipfile, shutil, os
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--android-jar',type=Path,required=True);p.add_argument('--build-tools',type=Path,required=True);p.add_argument('--ecj',type=Path,required=True)
a=p.parse_args();root=Path(__file__).resolve().parents[1];out=root/'test-build';out.mkdir(exist_ok=True)
for n in ['classes','dex']:(out/n).mkdir(exist_ok=True)
sdk=a.build_tools.resolve();jar=a.android_jar.resolve()
def run(args):subprocess.run([str(x) for x in args],check=True)
run([sdk/'aapt2','link','-I',jar,'--manifest',root/'tests/android/AndroidManifest.xml','--min-sdk-version','26','--target-sdk-version','35','-o',out/'base.apk'])
run(['java','-jar',a.ecj.resolve(),'-1.8','-nowarn','-encoding','UTF-8','-bootclasspath',str(jar)+os.pathsep+str(sdk/'core-lambda-stubs.jar'),'-classpath',root/'build/classes','-d',out/'classes',*sorted((root/'tests/android').glob('*.java'))])
with zipfile.ZipFile(out/'classes.jar','w',zipfile.ZIP_DEFLATED) as z:
 for f in (out/'classes').rglob('*.class'):z.write(f,f.relative_to(out/'classes'))
run(['java','-cp',sdk/'lib/d8.jar','com.android.tools.r8.D8','--min-api','26','--lib',jar,'--output',out/'dex',out/'classes.jar'])
shutil.copy2(out/'base.apk',out/'unsigned.apk')
with zipfile.ZipFile(out/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
 for f in (out/'dex').glob('*.dex'):z.write(f,f.name)
run([sdk/'zipalign','-f','4',out/'unsigned.apk',out/'aligned.apk'])
run(['java','-jar',sdk/'lib/apksigner.jar','sign','--ks',root/'signing/development.jks','--ks-key-alias','agendaclara','--ks-pass','pass:android','--key-pass','pass:android','--out',out/'Agenda-Clara-Instrumentation.apk',out/'aligned.apk'])
print(out/'Agenda-Clara-Instrumentation.apk')
