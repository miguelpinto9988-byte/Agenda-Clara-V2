package pe.agendaclara.app;

import android.content.*;
import android.widget.*;
import java.util.*;

public final class TaskWidgetService extends RemoteViewsService {
    @Override public RemoteViewsFactory onGetViewFactory(Intent i){return new Factory(getApplicationContext());}
    static final class Factory implements RemoteViewsFactory {
        final Context c;List<Task> all=new ArrayList<>();
        Factory(Context c){this.c=c;}
        public void onCreate(){all=Store.get(c).all();}
        public void onDataSetChanged(){all=Store.get(c).all();}
        public void onDestroy(){all.clear();}
        public int getCount(){return all.size();}
        public RemoteViews getViewAt(int p){return p>=0&&p<all.size()?TaskWidget.row(c,all.get(p)):null;}
        public RemoteViews getLoadingView(){return null;}
        public int getViewTypeCount(){return 1;}
        public long getItemId(int p){return all.get(p).id;}
        public boolean hasStableIds(){return true;}
    }
}
