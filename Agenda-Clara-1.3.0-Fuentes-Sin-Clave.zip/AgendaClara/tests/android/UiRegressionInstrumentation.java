package pe.agendaclara.tests;

import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.graphics.Rect;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.lang.reflect.Field;
import java.util.*;
import org.json.*;
import pe.agendaclara.app.*;

/** UI regression on synthetic data. No personal WhatsApp or Google account. */
public final class UiRegressionInstrumentation extends Instrumentation {
    volatile Activity current;Context c;Store db;JSONArray checks=new JSONArray();
    interface Condition{boolean ok()throws Exception;}
    @Override public void onCreate(Bundle args){super.onCreate(args);start();}
    Object field(String name)throws Exception{Field f=current.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(current);}
    void await(Condition c,long ms)throws Exception{long end=SystemClock.elapsedRealtime()+ms;while(SystemClock.elapsedRealtime()<end){if(c.ok())return;SystemClock.sleep(70);}throw new AssertionError("Timeout "+ms);}
    void check(boolean ok,String name)throws Exception{checks.put(new JSONObject().put("name",name).put("passed",ok));Bundle b=new Bundle();b.putString("check",name);sendStatus(ok?0:-1,b);if(!ok)throw new AssertionError(name);}
    View view(String tag)throws Exception{View[] v={null};runOnMainSync(()->v[0]=current.getWindow().getDecorView().findViewWithTag(tag));return v[0];}
    AlertDialog dialog(String name)throws Exception{return (AlertDialog)field(name);}
    int renders()throws Exception{return (Integer)field("renderCount");}
    boolean visibleEditor()throws Exception{AlertDialog d=dialog("editor");return d!=null&&d.isShowing();}
    boolean safe(AlertDialog d)throws Exception{
        boolean[] result={false};runOnMainSync(()->{
            View v=d.getWindow().getDecorView();Rect available=new Rect();v.getWindowVisibleDisplayFrame(available);int[] point=new int[2];v.getLocationOnScreen(point);Button save=d.getButton(-1);Rect b=new Rect();
            int width=current.getWindowManager().getCurrentWindowMetrics().getBounds().width();
            result[0]=v.getWidth()>0&&point[0]>=8&&point[0]+v.getWidth()<=width-8&&point[1]>=available.top&&point[1]+v.getHeight()<=available.bottom+2&&save!=null&&save.getGlobalVisibleRect(b)&&b.height()>=save.getHeight()-2;
        });return result[0];
    }
    boolean ime()throws Exception{boolean[] on={false};runOnMainSync(()->{try{WindowInsets i=dialog("editor").getWindow().getDecorView().getRootWindowInsets();on[0]=i!=null&&i.isVisible(WindowInsets.Type.ime());}catch(Exception ignored){}});return on[0];}
    @Override public void onStart(){
        boolean passed=false;JSONObject report=new JSONObject();
        try{
            c=getTargetContext();db=Store.get(c);Application app=(Application)c.getApplicationContext();
            app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks(){public void onActivityResumed(Activity a){if(a instanceof MainActivity)current=a;}public void onActivityCreated(Activity a,Bundle b){}public void onActivityStarted(Activity a){}public void onActivityPaused(Activity a){}public void onActivityStopped(Activity a){}public void onActivityDestroyed(Activity a){}public void onActivitySaveInstanceState(Activity a,Bundle b){}});
            runChecks();passed=true;
        }catch(Throwable e){try{report.put("error",e.toString());}catch(Exception ignored){}}
        try{if(db!=null)db.clearLinked();report.put("passed",passed).put("checks",checks).put("scope","Synthetic Android API 35 emulator; no personal account authentication or physical-phone flicker measurement");}catch(Exception ignored){}
        Bundle out=new Bundle();out.putString("report",report.toString());finish(passed?Activity.RESULT_OK:Activity.RESULT_CANCELED,out);
    }
    void runChecks()throws Exception{
        Prefs.get(c).edit().putBoolean("wa_link_consent_v1",false).putBoolean("wa_reading",false).putBoolean("wa_linked",false).putString("wa_status","QA reposo").commit();
        String jid="908070605@g.us",key=Store.linkedKey(jid);db.linkedGroup(jid,"QA Comunidad con nombre largo para comprobar los límites de las ventanas","",false,true,System.currentTimeMillis());db.selectChat(key,true);
        Intent intent=new Intent(c,MainActivity.class).setAction("connections").putExtra("tab",0).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivitySync(intent);
        await(()->current!=null&&field("root")!=null&&view("history_more:"+key)!=null,40000);SystemClock.sleep(1200);
        Object root=field("root"),nav=field("nav"),scroll=field("contentScroll");View card=view("chat:"+key);int baseline=renders();
        for(int n=0;n<40;n++)ReviewFlow.changed(c);SystemClock.sleep(1300);
        check(renders()==baseline&&view("chat:"+key)==card,"Unchanged broadcasts keep the same group card");
        check(field("root")==root&&field("nav")==nav&&field("contentScroll")==scroll,"Screen shell and scroll remain attached");
        for(int n=0;n<20;n++){Prefs.get(c).edit().putString("wa_status","QA cambio "+n).commit();ReviewFlow.changed(c);SystemClock.sleep(30);}SystemClock.sleep(1400);
        check(renders()>baseline&&renders()-baseline<=4,"Changed broadcasts are coalesced");check(field("root")==root,"Changed data preserves the screen shell");
        EditText search=(EditText)view("group_search");runOnMainSync(()->{search.requestFocus();search.setText("QA Comunidad");search.setSelection(3);});SystemClock.sleep(200);int before=renders();
        Prefs.get(c).edit().putString("wa_status","QA mientras escribes").commit();ReviewFlow.changed(c);SystemClock.sleep(1000);
        check(view("group_search")==search&&search.getSelectionStart()==3&&search.hasFocus(),"Background changes preserve search and cursor");check(renders()==before,"Typing defers replacement of page content");
        runOnMainSync(()->{search.clearFocus();((View)root).requestFocus();});await(()->renders()>before,15000);check("QA Comunidad".contentEquals(((EditText)view("group_search")).getText()),"Deferred update retains the query");
        int same=renders();runOnMainSync(()->((LinearLayout)nav).getChildAt(3).performClick());SystemClock.sleep(150);check(renders()==same,"Active navigation tab does not redraw");
        int taskCount=db.all().size();
        for(int n=0;n<5;n++){
            final int index=n;EditText active=(EditText)view("group_search");View more=view("history_more:"+key);runOnMainSync(()->{active.requestFocus();active.setSelection(3);more.performClick();});AlertDialog d=dialog("consentDialog");
            await(()->d.isShowing()&&d.getListView()!=null,10000);check(d.getListView().getAdapter().getCount()==5&&((n+1)*10+" mensajes anteriores").equals(d.getListView().getAdapter().getItem(n).toString()),"Offers history quantity "+((n+1)*10));await(()->safe(d),15000);
            runOnMainSync(()->{d.getListView().performItemClick(d.getListView().getChildAt(index),index,index);d.getButton(-1).performClick();});
            await(()->Prefs.get(c).getInt("wa_history_count",0)==(index+1)*10&&((TextView)view("history_more:"+key)).getText().toString().endsWith(""+((index+1)*10)),15000);
            check(Prefs.get(c).getInt("wa_history_count",0)==(n+1)*10,"Persists selected history quantity "+((n+1)*10));check(((EditText)view("group_search")).getSelectionStart()==3,"History confirmation keeps the search cursor "+((n+1)*10));
        }
        View more=view("history_more:"+key);runOnMainSync(()->more.performClick());AlertDialog d=dialog("consentDialog");runOnMainSync(()->{d.getListView().performItemClick(d.getListView().getChildAt(0),0,0);d.getButton(-2).performClick();});check(Prefs.get(c).getInt("wa_history_count",0)==50,"Cancel keeps the previous page size");
        runOnMainSync(()->more.performClick());AlertDialog revoke=dialog("consentDialog");db.selectChat(key,false);runOnMainSync(()->{revoke.getListView().performItemClick(revoke.getListView().getChildAt(0),0,0);revoke.getButton(-1).performClick();});check(Prefs.get(c).getInt("wa_history_count",0)==50,"Consent is rechecked before requesting history");
        check(db.all().size()==taskCount,"History selection creates no task");
        View add=view("new_task_button");runOnMainSync(()->add.performClick());await(()->visibleEditor(),10000);AlertDialog editor=dialog("editor");await(()->safe(editor),15000);check(safe(editor),"Editor has side margins and visible actions");
        EditText title=(EditText)editor.getWindow().getDecorView().findViewWithTag("task_title");runOnMainSync(()->{title.setText("QA borrador estable");title.requestFocus();title.setSelection(3);});ReviewFlow.changed(c);SystemClock.sleep(1000);
        check(dialog("editor")==editor&&"QA borrador estable".contentEquals(title.getText())&&title.getSelectionStart()==3,"Background changes preserve the open editor and draft");
        runOnMainSync(()->((InputMethodManager)current.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(title,InputMethodManager.SHOW_IMPLICIT));await(()->ime(),25000);await(()->safe(editor),15000);check(safe(editor),"Editor actions stay within the keyboard boundary");
        runOnMainSync(()->((InputMethodManager)current.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(title.getWindowToken(),0));await(()->!ime(),15000);
        Activity previous=current;runOnMainSync(()->current.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE));await(()->current!=previous&&visibleEditor(),35000);AlertDialog rotated=dialog("editor");await(()->safe(rotated),15000);
        check(safe(rotated),"Landscape editor stays within window bounds");check("QA borrador estable".contentEquals(((EditText)rotated.getWindow().getDecorView().findViewWithTag("task_title")).getText()),"Rotation restores the unsaved draft");
        runOnMainSync(()->rotated.getButton(-2).performClick());check(db.all().size()==taskCount,"Editor cancellation creates no task");
    }
}
