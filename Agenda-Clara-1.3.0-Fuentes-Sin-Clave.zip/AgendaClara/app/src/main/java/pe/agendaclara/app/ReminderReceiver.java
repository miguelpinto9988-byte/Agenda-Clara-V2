package pe.agendaclara.app;

import android.content.*;
import android.app.*;

public final class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        long id=i.getLongExtra("id",-1);Task t=Store.get(c).find(id);if(t==null||t.done)return;
        String action=i.getAction();
        if("complete".equals(action)){t.done=true;Store.get(c).save(t);Reminders.cancel(c,id);TaskWidget.refresh(c);return;}
        if("snooze".equals(action)){
            PendingIntent p=Reminders.alarmIntent(c,id,PendingIntent.FLAG_UPDATE_CURRENT);
            AlarmManager a=c.getSystemService(AlarmManager.class);long at=System.currentTimeMillis()+15*60000L;
            try{if(Reminders.exact(c))a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);}
            catch(SecurityException e){a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);}return;
        }
        Reminders.showTask(c,t);Reminders.schedule(c,t);TaskWidget.refresh(c);
    }
}
