package pe.agendaclara.app;

import android.Manifest;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.text.method.PasswordTransformationMethod;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    static final int BG=UiDesign.BG,INK=UiDesign.INK,GREEN=UiDesign.BLUE,MUTED=UiDesign.MUTED,RED=UiDesign.ERROR;
    static final int VIOLET=UiDesign.BLUE2,SUCCESS=UiDesign.SUCCESS,SURFACE=UiDesign.SURFACE,PALE=UiDesign.PALE,STROKE=UiDesign.BORDER;
    private final ExecutorService periodicMaintenance=Executors.newSingleThreadExecutor();
    private char[] secureBackupPassword;
    Map<Long,int[]> taskProgressCache=Collections.emptyMap();
    String reviewQuery="";int reviewFilter=0;Runnable reviewSearchTask;LinearLayout reviewList;TextView reviewCount;
    String pendingHistoryChat="";boolean dashboardAllTasksExpanded=false;int homeSection=0,renderedHomeSection=-1,calendarHubTab=0;ScrollView contentScroll;int renderedPage=-1,chatLimit=40,inboxLimit=25,taskLimit=24,categoryFilter=0;String chatQuery="";int groupFilter=0;boolean communitiesOnly=false;
    LinearLayout root,body,nav,taskList;TextView statusLine,headerTitle,headerDate;int page=0,filter=0,connectionTab=0;String query="",selectedCategory="General";
    LocalDate selectedDay=LocalDate.now(),month=selectedDay.withDayOfMonth(1);
    Handler handler=new Handler(Looper.getMainLooper());AlertDialog editor,consentDialog;Bundle restoreDraft;Runnable captureDraft;
    boolean resumed=false,refreshPending=false,refreshPosted=false,forceRefresh=false,allowFocusedRefresh=false,touching=false,selectingText=false;
    long lastRefresh=0,lastScroll=0;int renderCount=0;String lastDataSignature="";
    final Set<AlertDialog> dialogs=new HashSet<>();final Set<Long> expandedProposals=new HashSet<>();final Set<String> expandedChatCards=new HashSet<>();final Set<String> expandedCalendarAccounts=new HashSet<>();final Set<Long> expandedCalendarIds=new HashSet<>();
    Runnable taskSearch,groupSearch;
    final Runnable tick=new Runnable(){public void run(){
        if(resumed){periodicMaintenance.execute(()->CompletedTaskCleanup.run(getApplicationContext()));if(page<2){forceRefresh=true;requestRefresh();}handler.postDelayed(this,60000);}
    }};
    boolean dataReceiverRegistered=false;
    final Runnable refreshData=()->{refreshPosted=false;refreshVisibleData();};
    final BroadcastReceiver dataReceiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){requestRefresh();}};
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        if(Prefs.get(this).getBoolean("capture",false)&&!Prefs.get(this).contains("discover"))Prefs.get(this).edit().putBoolean("discover",true).apply();
        Prefs.get(this).edit().remove("auto").apply();
        IntentFilter dataFilter=new IntentFilter(ReviewFlow.DATA_CHANGED);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(dataReceiver,dataFilter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(dataReceiver,dataFilter);
        dataReceiverRegistered=true;
        if(handleWidgetToggle(getIntent()))return;
        if(state!=null){homeSection=Math.max(0,Math.min(2,state.getInt("mi_dia_home_section",0)));calendarHubTab=Math.max(0,Math.min(1,state.getInt("calendar_study_tab",0)));dashboardAllTasksExpanded=state.getBoolean("mi_dia_all_tasks",false);pendingHistoryChat=state.getString("history_chat","");page=Math.max(0,Math.min(4,state.getInt("page")));connectionTab=Math.max(0,Math.min(2,state.getInt("connection_tab")));chatQuery=state.getString("chat_query","");communitiesOnly=state.getBoolean("communities_only",false);groupFilter=Math.max(0,Math.min(6,state.getInt("group_filter",0)));expandedChatCards.addAll(state.getStringArrayList("expanded_chat_cards")!=null?state.getStringArrayList("expanded_chat_cards"):new ArrayList<>());expandedCalendarAccounts.addAll(state.getStringArrayList("expanded_calendar_accounts")!=null?state.getStringArrayList("expanded_calendar_accounts"):new ArrayList<>());for(long id:state.getLongArray("expanded_calendar_ids")!=null?state.getLongArray("expanded_calendar_ids"):new long[0])expandedCalendarIds.add(id);filter=state.getInt("filter");reviewFilter=Math.max(0,Math.min(4,state.getInt("review_filter",0)));reviewQuery=state.getString("review_query","");categoryFilter=Math.max(0,Math.min(TaskOrganization.CATEGORIES.length,state.getInt("category_filter")));query=state.getString("query","");selectedCategory=state.getString("selected_category","General");if(selectedCategory==null||selectedCategory.trim().isEmpty())selectedCategory="General";selectedDay=LocalDate.parse(state.getString("day",selectedDay.toString()));month=LocalDate.parse(state.getString("month",month.toString()));restoreDraft=state.getBundle("draft");}
        LinearLayout loading=column();loading.setGravity(Gravity.CENTER);loading.setBackgroundColor(BG);
        ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.ic_app);loading.addView(icon,new LinearLayout.LayoutParams(dp(96),dp(96)));
        TextView name=text("Agenda Clara",28,INK,true);name.setGravity(Gravity.CENTER);loading.addView(name);
        ProgressBar progress=new ProgressBar(this);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(36),dp(36));pp.topMargin=dp(20);loading.addView(progress,pp);setContentView(loading);
        new Thread(()->{Store.get(this).getReadableDatabase();Reminders.channels(this);runOnUiThread(()->{if(isFinishing()||isDestroyed())return;render();if(restoreDraft!=null){Bundle d=restoreDraft;restoreDraft=null;openEditor(d.getLong("task_id",-1),null,d);}else route(getIntent());});},"load-agenda").start();
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);if(!handleWidgetToggle(i))route(i);}
    boolean handleWidgetToggle(Intent i){
        if(!"widget_task".equals(i.getAction())||!i.getBooleanExtra("toggle",false))return false;
        Task t=Store.get(this).find(i.getLongExtra("task_id",-1));if(t!=null){t.done=!t.done;Store.get(this).save(t);if(t.done)Reminders.cancel(this,t.id);else Reminders.schedule(this,t);TaskWidget.refresh(this);}
        finish();return true;
    }
    void route(Intent i){
        if("pe.agendaclara.app.WIDGET_QA".equals(i.getAction())
            && (getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE)!=0){
            startActivity(new Intent(this,WidgetTaskActivity.class)
                .setAction(WidgetTaskActivity.ACTION_CREATE));
            finish();return;
        }
        if(Intent.ACTION_SEND.equals(i.getAction())&&"text/plain".equals(i.getType())){String s=i.getStringExtra(Intent.EXTRA_TEXT);if(s!=null){page=2;render();importText(s,"Mensaje compartido");}return;}
        if("review_proposal".equals(i.getAction())){
            Store.Inbox box=Store.get(this).pending(i.getLongExtra("proposal_id",-1));
            if(box==null){toast("Esta propuesta ya fue atendida.");return;}
            page=2;render();openEditor(-1,box,null);return;
        }
        if("connections".equals(i.getAction())){page=3;connectionTab=Math.max(0,Math.min(2,i.getIntExtra("tab",0)));render();return;}
        if("new_sticky_note".equals(i.getAction())){
            page=0;render();StickyNotesUi.showEditor(this,null);return;
        }
        if("sticky_notes".equals(i.getAction())){
            page=0;homeSection=1;dashboardAllTasksExpanded=true;selectedCategory="Notas";render();return;
        }
        if("sticky_widget_note".equals(i.getAction())){
            StickyNotesStore.Note note=StickyNotesStore.get(this).find(
                i.getLongExtra("sticky_note_id",-1));
            if(note!=null){
                page=0;homeSection=1;dashboardAllTasksExpanded=true;selectedCategory=note.category;render();
                StickyNotesUi.showEditor(this,note);
            }else{page=0;render();toast("La nota ya no está disponible.");}
            return;
        }
        if("new_task".equals(i.getAction())){openEditor(-1,null,null);return;}
        if("inbox".equals(i.getAction())){page=2;render();return;}
        long id=i.getLongExtra("task_id",-1);if(id>0)openEditor(id,null,null);
    }
    @Override protected void onResume(){super.onResume();resumed=true;handler.removeCallbacks(tick);handler.postDelayed(tick,60000);if(root!=null){forceRefresh=true;requestRefresh();}        if(Prefs.get(this).getBoolean("wa_linked",false)&&Prefs.get(this).getBoolean("wa_reading",false)&&!WhatsAppSessionService.running)session("resume",null);
        if(Prefs.get(this).getBoolean("capture",false)&&notificationAccess()){
            try{android.service.notification.NotificationListenerService.requestRebind(
                new ComponentName(this,WhatsAppListener.class));}catch(SecurityException ignored){}
        }
        new Thread(()->{CompletedTaskCleanup.run(this);Reminders.rebuild(this);TaskWidget.refresh(this);StickyNotesWidget.refresh(this);},"resume-reminders").start();}
    @Override protected void onPause(){resumed=false;handler.removeCallbacks(tick);handler.removeCallbacks(refreshData);refreshPosted=false;super.onPause();}
    @Override public void onActionModeStarted(ActionMode mode){super.onActionModeStarted(mode);selectingText=true;}
    @Override public void onActionModeFinished(ActionMode mode){super.onActionModeFinished(mode);selectingText=false;if(refreshPending)requestRefresh();}
    @Override protected void onDestroy(){VoiceQuickTask.closeFor(this);periodicMaintenance.shutdownNow();clearBackupPassword();handler.removeCallbacksAndMessages(null);if(dataReceiverRegistered)unregisterReceiver(dataReceiver);for(AlertDialog d:new ArrayList<>(dialogs))if(d.isShowing())d.dismiss();dialogs.clear();super.onDestroy();}
    @Override protected void onSaveInstanceState(Bundle out){
        super.onSaveInstanceState(out);out.putInt("mi_dia_home_section",homeSection);out.putInt("calendar_study_tab",calendarHubTab);out.putBoolean("mi_dia_all_tasks",dashboardAllTasksExpanded);out.putString("history_chat",pendingHistoryChat);out.putString("chat_query",chatQuery);out.putBoolean("communities_only",communitiesOnly);out.putInt("group_filter",groupFilter);out.putStringArrayList("expanded_chat_cards",new ArrayList<>(expandedChatCards));out.putStringArrayList("expanded_calendar_accounts",new ArrayList<>(expandedCalendarAccounts));long[] expanded=new long[expandedCalendarIds.size()];int cx=0;for(Long id:expandedCalendarIds)expanded[cx++]=id;out.putLongArray("expanded_calendar_ids",expanded);out.putInt("page",page);out.putInt("connection_tab",connectionTab);out.putInt("filter",filter);out.putInt("review_filter",reviewFilter);out.putString("review_query",reviewQuery);out.putInt("category_filter",categoryFilter);out.putString("query",query);out.putString("selected_category",selectedCategory);out.putString("day",selectedDay.toString());out.putString("month",month.toString());if(captureDraft!=null)captureDraft.run();if(restoreDraft!=null)out.putBundle("draft",restoreDraft);
    }
    LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(UiPreferences.scaled(this,size));t.setLineSpacing(dp(2),1.04f);t.setTextColor(UiPreferences.foreground(this,color,MUTED));UiDesign.text(t,bold);return t;}
    GradientDrawable rounded(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    GradientDrawable gradient(int left,int right,int radius){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{left,right});
        g.setCornerRadius(dp(radius));return g;
    }
    Button primaryButton(String label,Runnable action){
        Button button=button(label,action);UiDesign.button(button,true);UiDesign.actionIcon(button,label);
        return button;
    }
    TextView statLabel(String title,String value,int color){
        TextView text=text(value+"\n"+title,12,color,true);text.setGravity(Gravity.CENTER);
        text.setPadding(dp(6),dp(10),dp(6),dp(10));text.setBackground(rounded(color==SUCCESS?0xffe2f6ee:color==RED?0xffffebeb:PALE,13));
        return text;
    }
    GradientDrawable outlined(int color,int radius,int line){GradientDrawable d=rounded(color,radius);d.setStroke(dp(1),line);return d;}
    Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextSize(UiPreferences.scaled(this,14));b.setAllCaps(false);b.setTextColor(GREEN);b.setMinHeight(dp(48));UiDesign.button(b,false);UiDesign.actionIcon(b,label);b.setOnClickListener(v->action.run());return b;}
    EditText input(String hint,String value,int type){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextColor(INK);e.setTextSize(UiPreferences.scaled(this,16));e.setInputType(type);e.setMinHeight(dp(48));e.setHintTextColor(MUTED);e.setPadding(dp(12),dp(10),dp(12),dp(10));UiDesign.input(e);return e;}
    void gap(LinearLayout p,int h){p.addView(new View(this),new LinearLayout.LayoutParams(1,dp(h)));}
    LinearLayout card(LinearLayout parent){
        LinearLayout c=column();c.setPadding(dp(20),dp(20),dp(20),dp(20));UiDesign.card(c);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(20);parent.addView(c,lp);return c;
    }
    void subtitle(LinearLayout p,String label){TextView t=text(label,16,INK,true);t.setPadding(0,dp(14),0,dp(8));p.addView(t);}
    void showLicenses(){
        try(java.io.InputStream in=getAssets().open("licenses.txt")){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);TextView value=text(new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8),12,MUTED,false);value.setTextIsSelectable(true);value.setPadding(dp(18),dp(12),dp(18),dp(12));ScrollView scroll=new ScrollView(this);scroll.addView(value);dialogBuilder().setTitle("Licencias y fuentes").setView(scroll).setPositiveButton("Cerrar",null).show();}catch(java.io.IOException e){toast("Consulta THIRD_PARTY_NOTICES.md en el proyecto.");}
    }
    void toast(String s){if(!isFinishing()&&!isDestroyed())Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    AlertDialog.Builder dialogBuilder(){return new AlertDialog.Builder(this,R.style.DialogTheme){
            @Override public AlertDialog.Builder setView(View view){
                if(view instanceof ScrollView)return super.setView(view);
                if(view.getParent()!=null)return super.setView(view);
                WindowLayout.DialogScroll wrapper=new WindowLayout.DialogScroll(MainActivity.this);
                wrapper.addView(view);return super.setView(wrapper);
            }
            @Override public AlertDialog create(){AlertDialog d=super.create();trackDialog(d);return d;}
        };}
    void trackDialog(AlertDialog d){dialogs.add(d);d.getWindow().getDecorView().addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){WindowLayout.boundDialog(MainActivity.this,d);v.post(()->{UiDesign.polishTree(v);ContentIconSizing.apply(v);});}public void onViewDetachedFromWindow(View v){dialogs.remove(d);if(refreshPending||forceRefresh)requestRefresh();}});}
    boolean modalVisible(){for(AlertDialog d:dialogs)if(d.isShowing())return true;return false;}
    void requestRefresh(){refreshPending=true;if(!resumed||root==null||refreshPosted||isFinishing()||isDestroyed())return;refreshPosted=true;handler.postDelayed(refreshData,Math.max(250,700-(SystemClock.uptimeMillis()-lastRefresh)));}
    void refreshVisibleData(){
        if(!resumed||root==null||isFinishing()||isDestroyed())return;View focus=getCurrentFocus();
        if(modalVisible()||selectingText||(!allowFocusedRefresh&&focus instanceof EditText&&focus.hasFocus()))return;
        if(touching||SystemClock.uptimeMillis()-lastScroll<350){refreshPosted=true;handler.postDelayed(refreshData,400);return;}
        if(forceRefresh||!lastDataSignature.equals(dataSignature()))render();else refreshPending=false;
    }
    String dataSignature(){
        StringBuilder s=new StringBuilder().append(page).append(':').append(connectionTab);
        if(page==2){List<Store.Inbox> all=Store.get(this).inbox();s.append(':').append(all.size());for(int n=0;n<Math.min(inboxLimit,all.size());n++){Store.Inbox p=all.get(n);s.append('|').append(p.id).append(':').append(p.title).append(':').append(p.original).append(':').append(p.reason).append(':').append(p.due);}}
        else if(page==3&&connectionTab==0){Map<String,?> prefs=Prefs.get(this).getAll();for(String k:new String[]{"wa_status","wa_linked","wa_connected","wa_reading","wa_notify","wa_history_days","wa_history_count","wa_pair_code","wa_pair_expires","capture","discover","wa_diag_state","wa_diag_event_count","wa_diag_received_count","wa_diag_proposal_count","wa_diag_last_whatsapp","wa_diag_last_received"})s.append('|').append(k).append('=').append(prefs.get(k));s.append(WhatsAppSessionService.running);for(Store.Chat c:Store.get(this).chats())s.append('|').append(c.key).append(':').append(c.title).append(':').append(c.selected).append(':').append(c.parent).append(':').append(c.joined).append(':').append(c.scanState);}
        else if(page<2){for(Task t:Store.get(this).all())s.append('|').append(t.id).append(':').append(t.title).append(':').append(t.notes).append(':').append(t.due).append(':').append(t.done).append(':').append(t.urgent);}
        return s.toString();
    }
    static final class ScrollAnchor{Object tag;int y;ScrollAnchor(Object tag,int y){this.tag=tag;this.y=y;}}
    ScrollAnchor scrollAnchor(View v){
        if(v==null)return null;Object tag=v.getTag();android.graphics.Rect visible=new android.graphics.Rect();
        if(tag instanceof String&&(((String)tag).startsWith("task:")||((String)tag).startsWith("chat:")||((String)tag).startsWith("proposal:"))&&v.getGlobalVisibleRect(visible)){int[] position=new int[2];v.getLocationInWindow(position);return new ScrollAnchor(tag,position[1]);}
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int n=0;n<g.getChildCount();n++){ScrollAnchor result=scrollAnchor(g.getChildAt(n));if(result!=null)return result;}}return null;
    }
    void render(){
        if(isFinishing()||isDestroyed())return;if(modalVisible()){forceRefresh=true;allowFocusedRefresh=true;refreshPending=true;return;}
        handler.removeCallbacks(refreshData);refreshPosted=false;if(taskSearch!=null)handler.removeCallbacks(taskSearch);if(groupSearch!=null)handler.removeCallbacks(groupSearch);if(reviewSearchTask!=null)handler.removeCallbacks(reviewSearchTask);
        boolean samePage=renderedPage==page&&(page!=0||renderedHomeSection==homeSection)&&contentScroll!=null;final int scrollY=samePage?contentScroll.getScrollY():0;final ScrollAnchor anchor=samePage?scrollAnchor(body):null;renderedPage=page;renderedHomeSection=homeSection;
        View focus=samePage?getCurrentFocus():null;Object tag=focus instanceof EditText?focus.getTag():null;int selection=focus instanceof EditText?((EditText)focus).getSelectionStart():-1;
        if(root==null)createShell();headerTitle.setText(new String[]{"Inicio — Mi día","Calendario","Revisión","Conexiones","Más"}[page]);headerDate.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE d MMMM",new Locale("es","PE"))).toUpperCase(new Locale("es","PE")));
        // The landscape is the home header; original toolbar on other tabs.
        root.getChildAt(0).setVisibility(page==0?View.GONE:View.VISIBLE);
        View topPlus=root.getChildAt(0).findViewWithTag("new_task_button");
        if(topPlus!=null)topPlus.setVisibility(page==1?View.GONE:View.VISIBLE);
        taskProgressCache=page<2?Store.get(this).subtaskProgressAll():Collections.emptyMap();
        body.removeAllViews();
        boolean isHome=page==0&&homeSection==0;
        // More visual space for the designed home; every legacy page retains
        // its existing padding, query UI, scroll and keyboard behavior.
        body.setPadding(isHome?0:dp(22),isHome?0:dp(18),
                isHome?0:dp(22),isHome?dp(18):dp(40));
        contentScroll.setBackgroundColor(isHome?0xffffffff:BG);
        contentScroll.setVerticalScrollBarEnabled(!isHome);
        if(page==0){
            if(homeSection==1){
                // The original toolbar is hidden on all home subsections.
                // Retain an obvious creation affordance in the task tab.
                LinearLayout taskHeading=row();
                taskHeading.addView(text("Mis tareas",22,INK,true),
                        new LinearLayout.LayoutParams(0,-2,1));
                Button newTask=button("＋ Nueva",()->showCreationMenu());
                newTask.setTag("home_create_button");
                newTask.setContentDescription("Crear una tarea o nota");
                taskHeading.addView(newTask);
                body.addView(taskHeading);gap(body,13);
                tasksPage();
            }else if(homeSection==2)MiDiaStudyPage.render(this);
            else MiDiaDashboard.render(this);
        }else if(page==1)calendarPage();
        else if(page==2)messagesPage();
        else if(page==4)MiDiaMorePage.render(this);
        else settingsPage();
        if(!samePage)UiMotion.reveal(body);
        if(tag!=null){View restored=body.findViewWithTag(tag);if(restored instanceof EditText){restored.requestFocus();((EditText)restored).setSelection(Math.max(0,Math.min(selection,((EditText)restored).length())));}}
        int selectedNav=MiDiaNavigation.selectedTab(this);
        for(int n=0;n<nav.getChildCount();n++){
            LinearLayout item=(LinearLayout)nav.getChildAt(n);
            boolean active=selectedNav==n;
            String navLabel=MiDiaNavigation.TAB_LABELS[n];
            item.setBackground(rounded(active?0xffe6f2ff:0xffffffff,15));
            item.setSelected(active);
            item.setContentDescription(navLabel+(active?", pestaña actual":", abrir pestaña"));
            ImageView tabIcon=(ImageView)item.getChildAt(0);
            int tabColor=active?0xff1468d0:MUTED;
            if(!(tabIcon.getTag() instanceof Integer)||((Integer)tabIcon.getTag())!=tabColor){
                tabIcon.setImageTintList(null);
                tabIcon.setImageDrawable(new UiDesign.OutlineIcon(UiDesign.statusIcon(navLabel),tabColor));
                tabIcon.setTag(tabColor);
            }
            TextView navText=(TextView)item.getChildAt(1);
            navText.setTextColor(active?0xff1468d0:MUTED);
            UiDesign.text(navText,active);
        }
        contentScroll.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener(){public boolean onPreDraw(){if(contentScroll.getViewTreeObserver().isAlive())contentScroll.getViewTreeObserver().removeOnPreDrawListener(this);View target=anchor==null?null:body.findViewWithTag(anchor.tag);if(target!=null){int[] position=new int[2];target.getLocationInWindow(position);contentScroll.scrollTo(0,Math.max(0,contentScroll.getScrollY()+position[1]-anchor.y));}else contentScroll.scrollTo(0,scrollY);return true;}});
        UiDesign.polishTree(body);ContentIconSizing.apply(body);
        lastRefresh=SystemClock.uptimeMillis();lastDataSignature=dataSignature();forceRefresh=false;allowFocusedRefresh=false;refreshPending=false;renderCount++;
    }
    void createShell(){
        root=column();root.setTag("app_shell");root.setBackgroundColor(BG);root.setFocusableInTouchMode(true);
        LinearLayout header=row();header.setPadding(dp(20),dp(16),dp(18),dp(18));LinearLayout names=column();headerDate=text("",11,MUTED,true);headerTitle=text("",28,INK,true);names.addView(headerDate);gap(names,4);names.addView(headerTitle);header.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        Button add=button("＋",()->showCreationMenu());add.setTag("new_task_button");add.setTextSize(28);add.setTextColor(0xffffffff);add.setBackground(gradient(GREEN,0xff7465ec,19));add.setElevation(dp(4));add.setContentDescription("Crear una tarea o nota");header.addView(add,new LinearLayout.LayoutParams(dp(108),dp(108)));root.addView(header);
        contentScroll=new ScrollView(this);contentScroll.setFillViewport(true);contentScroll.setClipToPadding(true);contentScroll.setVerticalFadingEdgeEnabled(true);contentScroll.setFadingEdgeLength(dp(18));body=column();body.setPadding(dp(22),dp(18),dp(22),dp(40));contentScroll.addView(body);root.addView(contentScroll,new LinearLayout.LayoutParams(-1,0,1));
        contentScroll.setOnTouchListener((v,e)->{if(e.getActionMasked()==MotionEvent.ACTION_DOWN)touching=true;else if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){touching=false;if(refreshPending)requestRefresh();}return false;});contentScroll.setOnScrollChangeListener((View v,int x,int y,int ox,int oy)->{lastScroll=SystemClock.uptimeMillis();if(refreshPending)requestRefresh();});
        nav=row();nav.setPadding(dp(5),dp(7),dp(5),dp(9));
        nav.setBackgroundColor(0xffffffff);
        String[] labels=MiDiaNavigation.TAB_LABELS;
        for(int n=0;n<labels.length;n++){
            final int index=n;
            LinearLayout item=column();item.setGravity(Gravity.CENTER);
            item.setPadding(dp(1),dp(5),dp(1),dp(5));
            ImageView icon=new ImageView(this);
            icon.setImageDrawable(new UiDesign.OutlineIcon(UiDesign.statusIcon(labels[n]),MUTED));
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            icon.setPadding(dp(1),dp(1),dp(1),dp(1));
            item.addView(icon,new LinearLayout.LayoutParams(dp(24),dp(24)));
            TextView caption=text(labels[n],10,MUTED,false);
            caption.setGravity(Gravity.CENTER);caption.setSingleLine(true);
            item.addView(caption);
            item.setContentDescription(labels[n]+", abrir pestaña");
            item.setFocusable(true);item.setOnClickListener(v->MiDiaNavigation.open(this,index));
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(67),1));
        }
        UiDesign.polishTree(nav);
        View line=new View(this);line.setBackgroundColor(STROKE);root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));root.addView(nav);setContentView(root);WindowLayout.apply(this,root);TopPlusButtonMotion.install(this);root.getViewTreeObserver().addOnGlobalFocusChangeListener((old,next)->{if(refreshPending&&!(next instanceof EditText))requestRefresh();});
    }
    void showCreationMenu(){
        View add=root==null?null:root.findViewWithTag("home_create_button");
        if(add==null||!add.isShown())add=root==null?null:root.findViewWithTag("new_task_button");
        CreationChoices.show(this,add,()->openEditor(-1,null,null),
            ()->StickyNotesUi.showEditor(this,null),()->VoiceQuickTask.show(this));
    }
    void tasksPage(){
        List<Task> all=Store.get(this).all();
        long now=System.currentTimeMillis();
        TaskSummary.Result snapshot=TaskSummary.calculate(all,now,Store.get(this).completedSince(now-7L*86400000L));
        int pending=snapshot.pending,done=snapshot.completedToday,urgent=snapshot.urgent,weekDone=snapshot.completed7days;
        LinearLayout summary=card(body);summary.setBackground(outlined(0xffffffff,21,STROKE));
        LinearLayout heading=row();LinearLayout title=column();title.addView(text(pending==0?"Todo en orden.":"Tu productividad",21,INK,true));
        gap(title,4);title.addView(text(pending+" pendientes · "+weekDone+" completadas esta semana",12,MUTED,false));
        heading.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView percent=text(snapshot.percentage+"%",24,GREEN,true);percent.setContentDescription("Avance estimado: "+snapshot.percentage+" por ciento, completadas en siete días frente a pendientes");
        percent.setGravity(Gravity.CENTER);percent.setBackground(outlined(0xfff1f4ff,40,STROKE));heading.addView(percent,new LinearLayout.LayoutParams(dp(66),dp(66)));
        summary.addView(heading);gap(summary,12);
        ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(Math.max(1,pending+weekDone));progress.setProgress(weekDone);progress.setProgressTintList(ColorStateList.valueOf(VIOLET));progress.setProgressBackgroundTintList(ColorStateList.valueOf(STROKE));summary.addView(progress,new LinearLayout.LayoutParams(-1,dp(5)));gap(summary,12);
        if(!Reminders.canNotify(this)||!Reminders.exact(this)){LinearLayout c=card(body);c.addView(text("Revisa tus avisos",15,INK,true));c.addView(text(!Reminders.canNotify(this)?"Activa las notificaciones en Conexiones para recibir recordatorios.":"Activa «Alarmas y recordatorios» para avisos a la hora elegida. Sin ese permiso, Android puede retrasarlos.",13,MUTED,false));c.addView(button("Ir a Conexiones",()->{page=3;render();}));}
        EditText search=input("Buscar en tus tareas",query,android.text.InputType.TYPE_CLASS_TEXT);search.setContentDescription("Buscar tareas por título, notas o fuente, con o sin tilde");search.setTag("task_search");search.setSingleLine(true);body.addView(search);gap(body,8);
        LinearLayout categoryActions=row();
        TextView categoriesLabel=text("Mis categorías",17,INK,true);
        categoryActions.addView(categoriesLabel,new LinearLayout.LayoutParams(0,-2,1));
        Button manage=button("Gestionar  ›",this::showCategories);
        manage.setContentDescription("Gestionar categorías personalizadas");
        manage.setMinWidth(dp(112));categoryActions.addView(manage);
        body.addView(categoryActions);gap(body,10);
        HorizontalScrollView categoriesScroll=new HorizontalScrollView(this);
        categoriesScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout categoryChips=row();String[] categories=CategoryRegistry.names(this);
        if(!java.util.Arrays.asList(categories).contains(selectedCategory))selectedCategory="General";
        for(String label:categories){
            final String chosen=label;
            Button chip=button(label,()->{selectedCategory=chosen;taskLimit=24;render();});
            boolean active=selectedCategory.equalsIgnoreCase(chosen);
            UiDesign.categoryChip(chip,CategoryRegistry.color(this,label),active);
            ApprovedPng.button(chip,CategoryRegistry.icon(this,label),24);
            chip.setCompoundDrawablePadding(dp(11));
            chip.setSingleLine(true);
            chip.setEllipsize(android.text.TextUtils.TruncateAt.END);
            chip.setMinHeight(dp(54));
            chip.setPadding(dp(14),dp(8),dp(16),dp(8));
            chip.setContentDescription("Categoría "+label+(active?", seleccionada":""));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(54));lp.rightMargin=dp(10);
            categoryChips.addView(chip,lp);
        }
        categoriesScroll.addView(categoryChips);body.addView(categoriesScroll);gap(body,18);
        LinearLayout listHeader=row();TextView upcoming=text("Próximas tareas",17,INK,true);
        listHeader.addView(upcoming);body.addView(listHeader);gap(body,10);
        taskList=column();body.addView(taskList);fillTasks(all,null);
        StickyNotesUi.agenda(this,body,selectedCategory,query);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int before,int count){query=s.toString();taskLimit=24;if(taskSearch!=null)handler.removeCallbacks(taskSearch);taskSearch=()->{if(page==0&&search.isAttachedToWindow())fillTasks(all,null);};handler.postDelayed(taskSearch,220);}public void afterTextChanged(Editable e){}});
        TextView guide=text("La prioridad cambia automáticamente según la fecha límite.",12,MUTED,false);guide.setPadding(0,dp(10),0,0);body.addView(guide);
    }
    void fillTasks(List<Task> all,LocalDate date){
        taskList.removeAllViews();int count=0;long now=System.currentTimeMillis();
        for(Task t:all){
            if(!AgendaFilters.matches(t,0,0,query,date,now))continue;
            if(date==null&&!GeneralCategoryScope.visibleIn(selectedCategory,TaskOrganization.category(t.category)))continue;
            if(count<taskLimit)taskCard(taskList,t);count++;
        }
        if(count>taskLimit)taskList.addView(button("Ver más tareas ("+(count-taskLimit)+")",()->{taskLimit+=24;fillTasks(all,date);}));
        if(count==0 && !(date==null && !StickyNotesStore.get(this).inCategory(selectedCategory).isEmpty())){LinearLayout c=card(taskList);gap(c,14);TextView empty=text(date==null?"No hay tareas en "+selectedCategory:"Este día está libre",20,INK,true);empty.setGravity(Gravity.CENTER);c.addView(empty);TextView msg=text(date==null?"Crea una tarea o elige otra categoría para verla.":"Toca ＋ para planificar una actividad.",14,MUTED,false);msg.setGravity(Gravity.CENTER);c.addView(msg);gap(c,14);}
    }
    void taskCard(LinearLayout parent,Task t){
        LinearLayout card=card(parent);card.setTag("task:"+t.id);
        LinearLayout top=row();
        CheckBox check=new CheckBox(this);check.setChecked(t.done);
        check.setButtonTintList(ColorStateList.valueOf(GREEN));
        check.setContentDescription((t.done?"Marcar pendiente: ":"Marcar completada: ")+t.title);
        top.addView(check,new LinearLayout.LayoutParams(dp(48),dp(52)));
        LinearLayout details=column();
        TextView name=text(t.title,16,t.done?MUTED:INK,true);
        name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        details.addView(name);
        String category=TaskOrganization.category(t.category);
        int categoryColor=CategoryRegistry.color(this,category);
        card.setBackground(UiDesign.tintedBackground(this,categoryColor,20,14));
        check.setButtonTintList(ColorStateList.valueOf(UiDesign.accentInk(categoryColor)));
        TextView when=text("▢ "+TaskLogic.when(t.due)+"   ·   "+category,12,MUTED,false);
        when.setMaxLines(2);
        LinearLayout meta=row();
        meta.addView(ApprovedPng.view(this,CategoryRegistry.icon(this,category),17),
                     new LinearLayout.LayoutParams(dp(19),dp(19)));
        meta.addView(when,new LinearLayout.LayoutParams(0,-2,1));
        details.addView(meta);
        top.addView(details,new LinearLayout.LayoutParams(0,-2,1));
        TextView chevron=text("›",28,UiDesign.accentInk(categoryColor),true);chevron.setGravity(Gravity.CENTER);
        top.addView(chevron,new LinearLayout.LayoutParams(dp(36),dp(48)));
        card.addView(top);
        String status=TaskPriority.label(t,System.currentTimeMillis());
        TextView priority=text(status+" · prioridad automática",11,TaskPriority.color(status),true);
        priority.setPadding(dp(10),dp(8),dp(10),dp(8));
        int badgeColor="Urgente".equals(status)||"Vencida".equals(status)?0xffffe9ed:
           "Alta".equals(status)?0xfffff1e7:"Media".equals(status)?0xffeaf1ff:
           "Baja".equals(status)?0xffe5f8ec:PALE;
        priority.setBackground(rounded(badgeColor,12));
        card.addView(priority);
        int[] progress=taskProgressCache.containsKey(t.id)?taskProgressCache.get(t.id):new int[]{0,0};
        if(progress[0]>0){gap(card,6);card.addView(text("Subtareas: "+progress[1]+" / "+progress[0],12,MUTED,false));}
        if(t.done&&t.completedAt>0){gap(card,6);card.addView(text("Completada · se retira automáticamente tras 1 hora",11,MUTED,false));}
        details.setOnClickListener(v->showTaskDetails(t.id));
        chevron.setOnClickListener(v->showTaskDetails(t.id));
        check.setOnCheckedChangeListener((button,checked)->{
            t.done=checked;Store.get(this).save(t);
            if(checked)Reminders.cancel(this,t.id);else Reminders.schedule(this,t);
            TaskWidget.refresh(this);render();
        });
    }
    void showTaskDetails(long id){
        Task task=Store.get(this).find(id);
        if(task==null){toast("La tarea ya no está disponible.");return;}
        LinearLayout pane=column();pane.setPadding(dp(18),dp(12),dp(18),dp(18));
        pane.setBackground(UiDesign.tintedBackground(this,CategoryRegistry.color(this,task.category),20,11));
        pane.addView(text(task.title,20,INK,true));gap(pane,14);
        LinearLayout categoryRow=row();
        ImageView categoryIcon=ApprovedPng.view(this,CategoryRegistry.icon(this,task.category),22);
        LinearLayout.LayoutParams detailIconSpace=new LinearLayout.LayoutParams(dp(28),dp(28));
        detailIconSpace.rightMargin=dp(10);
        categoryRow.addView(categoryIcon,detailIconSpace);
        categoryRow.addView(text(TaskOrganization.category(task.category),14,UiDesign.accentInk(CategoryRegistry.color(this,task.category)),true));
        pane.addView(categoryRow);gap(pane,16);
        pane.addView(text("Fecha y hora límite",14,MUTED,true));
        pane.addView(text(TaskLogic.when(task.due),16,INK,true));gap(pane,12);
        String priority=TaskPriority.label(task,System.currentTimeMillis());
        pane.addView(text("Prioridad automática · "+priority,14,TaskPriority.color(priority),true));
        gap(pane,14);
        pane.addView(text("Recordatorios",14,INK,true));gap(pane,6);
        java.util.SortedSet<Integer> alerts=TaskLogic.offsets(task.offsets);
        StringBuilder offsetsLabel=new StringBuilder();
        for(int minutes:alerts){if(offsetsLabel.length()>0)offsetsLabel.append(" · ");offsetsLabel.append(TaskLogic.offsetName(minutes));}
        pane.addView(text(offsetsLabel.length()==0?"Sin avisos programados":offsetsLabel.toString(),13,MUTED,false));gap(pane,12);
        pane.addView(text("Repetición del aviso",14,INK,true));gap(pane,5);
        pane.addView(text(task.repeatMinutes==0?"No se repite":"Cada "+TaskLogic.offsetName(task.repeatMinutes).toLowerCase(new Locale("es","PE")),13,MUTED,false));
        if(!task.notes.isEmpty()){gap(pane,12);pane.addView(text("Notas",13,MUTED,true));pane.addView(text(task.notes,14,INK,false));}
        gap(pane,14);
        pane.addView(primaryButton("✎  Editar tarea",()->{for(AlertDialog d:new ArrayList<>(dialogs))if(d.isShowing())d.dismiss();handler.post(()->openEditor(id,null,null));}));
        gap(pane,8);pane.addView(button("☑  Gestionar subtareas",()->{for(AlertDialog d:new ArrayList<>(dialogs))if(d.isShowing())d.dismiss();handler.post(()->openSubtasks(id));}));
        ScrollView scroll=new WindowLayout.DialogScroll(this);scroll.addView(pane);
        dialogBuilder().setTitle("Detalle de tarea").setView(scroll).setPositiveButton("Cerrar",null).show();
    }
    /** Local recycle bin: removing a task is reversible for seven days. */
    void showTrash(){
        List<TaskRecycleBin.Entry> entries=Store.get(this).trash();
        LinearLayout holder=column();holder.setPadding(dp(15),dp(10),dp(15),dp(12));
        ScrollView scroller=new WindowLayout.DialogScroll(this);scroller.addView(holder);
        if(entries.isEmpty())holder.addView(text("No hay tareas en la papelera.",14,MUTED,false));
        for(TaskRecycleBin.Entry item:entries){
            LinearLayout card=card(holder);card.addView(text(item.title,16,INK,true));
            long left=Math.max(0,(item.deletedAt+TaskRecycleBin.RETENTION-System.currentTimeMillis())/86400000L+1);
            card.addView(text("Recuperable durante "+left+" día(s) más",12,MUTED,false));
            LinearLayout controls=row();
            controls.addView(button("Restaurar",()->{
                try{long id=Store.get(this).restoreDeleted(item.id);
                    if(id>0){Task task=Store.get(this).find(id);if(task!=null)Reminders.schedule(this,task);TaskWidget.refresh(this);toast("Tarea recuperada. Comprueba la fecha y el calendario.");}
                    else toast("Ya no está disponible.");
                    for(AlertDialog d:new ArrayList<>(dialogs))if(d.isShowing())d.dismiss();render();
                }catch(Exception ex){toast("No se pudo restaurar la tarea.");}
            }),new LinearLayout.LayoutParams(0,-2,1));
            controls.addView(button("Eliminar",()->dialogBuilder().setTitle("Eliminar definitivamente").setMessage("Esta acción no se puede deshacer.").setNegativeButton("Cancelar",null)
                .setPositiveButton("Eliminar",(d,w)->{Store.get(this).permanentlyDelete(item.id);for(AlertDialog a:new ArrayList<>(dialogs))if(a.isShowing())a.dismiss();showTrash();}).show()),new LinearLayout.LayoutParams(0,-2,1));
            card.addView(controls);
        }
        if(!entries.isEmpty())holder.addView(button("Vaciar toda la papelera",()->dialogBuilder().setTitle("Vaciar papelera").setMessage("Se eliminarán todas las tareas de la papelera definitivamente.").setNegativeButton("Cancelar",null).setPositiveButton("Vaciar",(d,w)->{Store.get(this).emptyTrash();for(AlertDialog a:new ArrayList<>(dialogs))if(a.isShowing())a.dismiss();showTrash();}).show()));
        dialogBuilder().setTitle("Papelera · "+entries.size()+" tareas").setView(scroller).setPositiveButton("Cerrar",null).show();
    }
    void openSubtasks(long taskId){
        Task current=Store.get(this).find(taskId);if(current==null){toast("La tarea no está disponible.");return;}
        LinearLayout holder=column();holder.setPadding(dp(16),dp(8),dp(16),dp(12));
        ScrollView scroll=new WindowLayout.DialogScroll(this);scroll.addView(holder);
        LinearLayout entries=column();holder.addView(entries);
        final Runnable[] reload={null};
        reload[0]=()->{
            entries.removeAllViews();
            List<Store.Subtask> children=Store.get(this).subtasks(taskId);
            entries.addView(text("Progreso: "+Store.get(this).subtaskProgress(taskId)[1]+"/"+children.size(),13,VIOLET,true));
            if(children.isEmpty())entries.addView(text("Todavía no hay subtareas.",13,MUTED,false));
            for(Store.Subtask item:children){
                LinearLayout line=row();CheckBox check=new CheckBox(this);check.setText(item.title);check.setTextColor(INK);check.setChecked(item.done);
                line.addView(check,new LinearLayout.LayoutParams(0,-2,1));
                Button remove=button("×",()->{Store.get(this).deleteSubtask(taskId,item.id);reload[0].run();});
                remove.setContentDescription("Quitar subtarea: "+item.title);line.addView(remove);
                check.setOnCheckedChangeListener((v,on)->{Store.get(this).setSubtaskDone(taskId,item.id,on);reload[0].run();});
                entries.addView(line);
            }
        };
        holder.addView(button("＋ Nueva subtarea",()->{
            EditText name=input("Nombre de subtarea","",android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            LinearLayout wrap=column();wrap.setPadding(dp(16),0,dp(16),0);wrap.addView(name);
            AlertDialog dlg=dialogBuilder().setTitle("Nueva subtarea").setView(wrap).setNegativeButton("Cancelar",null).setPositiveButton("Añadir",null).create();
            dlg.setOnShowListener(d->dlg.getButton(-1).setOnClickListener(v->{
                if(!Store.get(this).addSubtask(taskId,name.getText().toString())){name.setError("Escribe de 1 a 180 caracteres (máximo 50 subtareas).");return;}
                dlg.dismiss();reload[0].run();}));
            dlg.show();
        }));
        AlertDialog dlg=dialogBuilder().setTitle("Subtareas · "+current.title).setView(scroll).setPositiveButton("Cerrar",(d,w)->{forceRefresh=true;render();}).create();
        reload[0].run();dlg.show();
    }
    void calendarPage(){CalendarStudyHub.render(this);}
    void addCell(GridLayout g,View v,int height){GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(height);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(dp(1),dp(1),dp(1),dp(1));g.addView(v,p);}
    void messagesPage(){
        LinearLayout info=card(body);info.addView(text("Revisa antes de guardar",19,INK,true));gap(info,6);info.addView(text("Aquí llegan las posibles actividades de los grupos autorizados. Revisa su mensaje y su fecha antes de guardarlas.",14,MUTED,false));
        LinearLayout options=row();options.addView(button("Mis grupos",()->{page=3;connectionTab=0;render();}),new LinearLayout.LayoutParams(0,-2,1));View reviewGap=new View(this);options.addView(reviewGap,new LinearLayout.LayoutParams(dp(8),1));options.addView(button("Pegar texto",()->importText("","Texto pegado")),new LinearLayout.LayoutParams(0,-2,1));info.addView(options);
        List<Store.Inbox> inbox=Store.get(this).inbox();
        LinearLayout reviewSummary=card(body);
        reviewSummary.addView(text("Propuestas por revisar",18,INK,true));gap(reviewSummary,8);
        reviewSummary.addView(text(inbox.size()+" propuestas pendientes",15,GREEN,true));
        reviewSummary.addView(text("Selecciona una propuesta para confirmar si debe entrar en tu agenda.",12,MUTED,false));
        reviewCount=text("",15,INK,true);body.addView(reviewCount);gap(body,8);
        EditText search=input("Buscar propuestas o mensajes",reviewQuery,android.text.InputType.TYPE_CLASS_TEXT);
        search.setTag("review_search");search.setSingleLine(true);
        search.setContentDescription("Buscar propuestas por actividad, grupo o contenido del mensaje");
        body.addView(search);gap(body,8);
        HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout chips=row();String[] reviewModes={"Todas","Sin fecha","Vencidas","Del historial","Próximas"};
        for(int i=0;i<reviewModes.length;i++){
            final int chosen=i;Button chip=button(reviewModes[i],()->{reviewFilter=chosen;inboxLimit=25;render();});
            chip.setTextColor(chosen==reviewFilter?0xffffffff:MUTED);
            chip.setBackground(rounded(chosen==reviewFilter?GREEN:PALE,18));
            chip.setContentDescription("Mostrar propuestas "+reviewModes[i]+(chosen==reviewFilter?", filtro activo":""));
            LinearLayout.LayoutParams reviewChip=new LinearLayout.LayoutParams(-2,dp(48));reviewChip.rightMargin=dp(8);chips.addView(chip,reviewChip);
        }
        scroller.addView(chips);body.addView(scroller);gap(body,10);
        reviewList=column();body.addView(reviewList);
        fillReviewList(inbox);
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence t,int start,int count,int after){}
            public void onTextChanged(CharSequence t,int start,int before,int count){
                reviewQuery=t.toString();inboxLimit=25;
                if(reviewSearchTask!=null)handler.removeCallbacks(reviewSearchTask);
                reviewSearchTask=()->{if(page==2&&search.isAttachedToWindow())fillReviewList(inbox);};
                handler.postDelayed(reviewSearchTask,190);
            }
            public void afterTextChanged(Editable e){}
        });
    }
    /** Rebuild only the proposal list while typing; preserve the search field and cursor. */
    void fillReviewList(List<Store.Inbox> all){
        if(reviewList==null)return;
        reviewList.removeAllViews();
        List<Store.Inbox> inbox=new ArrayList<>();
        long now=System.currentTimeMillis();
        for(Store.Inbox proposal:all){
            if(ReviewFilters.matches(proposal.title,proposal.source,proposal.original,
               proposal.dateKnown,proposal.due,proposal.historical,reviewFilter,reviewQuery,now))
                inbox.add(proposal);
        }
        if(reviewCount!=null)reviewCount.setText("Propuestas encontradas · "+inbox.size()+" de "+all.size());
        if(inbox.isEmpty()){
            LinearLayout empty=card(reviewList);gap(empty,26);TextView illustration=text("✓",38,GREEN,true);illustration.setGravity(Gravity.CENTER);illustration.setBackground(rounded(PALE,50));
            LinearLayout center=row();center.setGravity(Gravity.CENTER);center.addView(illustration,new LinearLayout.LayoutParams(dp(82),dp(82)));empty.addView(center);gap(empty,15);
            TextView headline=text((all.size()==0?"Tu bandeja está al día":"No hay propuestas con este filtro"),21,INK,true);headline.setGravity(Gravity.CENTER);empty.addView(headline);gap(empty,9);
            TextView infoText=text("Selecciona un grupo para revisar su historial disponible. Las preguntas y los comentarios casuales no generan propuestas por una palabra aislada.",13,MUTED,false);infoText.setGravity(Gravity.CENTER);empty.addView(infoText);gap(empty,24);
            LinearLayout tip=column();tip.setPadding(dp(12),dp(12),dp(12),dp(12));tip.setBackground(rounded(PALE,15));tip.addView(text("✦  Consejo",13,GREEN,true));gap(tip,5);tip.addView(text("Revisa periódicamente tus grupos autorizados para detectar nuevas actividades.",12,MUTED,false));empty.addView(tip);gap(empty,16);
        }
        int shown=0;
        for(Store.Inbox p:inbox){if(shown++>=inboxLimit)break;
            LinearLayout c=card(reviewList);c.setTag("proposal:"+p.id);c.setContentDescription("Propuesta pendiente: "+p.title);boolean isDateChange=p.reason!=null&&p.reason.contains("Cambio de fecha");TextView badge=text(isDateChange?"CAMBIO DE FECHA · CONFIRMAR":p.historical?"DEL HISTORIAL":"PARA REVISAR",10,isDateChange?RED:GREEN,true);badge.setPadding(0,0,0,dp(7));c.addView(badge);
            if(p.dateKnown&&p.due>0&&p.due<System.currentTimeMillis()){
                TextView caution=text("●  PLAZO VENCIDO · CONFIRMA LA FECHA",11,RED,true);
                caution.setPadding(dp(8),dp(6),dp(8),dp(6));caution.setBackground(rounded(0xffffeeee,12));c.addView(caution);gap(c,6);
            }
            c.addView(text(p.title,18,INK,true));gap(c,7);c.addView(text(p.source,12,MUTED,true));
            c.addView(text("Mensaje del "+Instant.ofEpochMilli(p.created).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("d MMM yyyy · h:mm a",new Locale("es","PE"))),11,MUTED,false));gap(c,8);
            c.addView(text(p.reason,13,p.due>0&&p.due<System.currentTimeMillis()?RED:MUTED,false));
            if(p.dateKnown){gap(c,6);c.addView(text("Fecha propuesta: "+(p.timeKnown?TaskLogic.when(p.due):Instant.ofEpochMilli(p.due).atZone(ZoneId.systemDefault()).toLocalDate().toString()),13,INK,true));}
            TextView original=text(p.original,13,MUTED,false);original.setTextIsSelectable(true);original.setVisibility(expandedProposals.contains(p.id)?View.VISIBLE:View.GONE);Button expand=button(expandedProposals.contains(p.id)?"Ocultar mensaje original":"Ver mensaje original",()->{boolean show=original.getVisibility()!=View.VISIBLE;if(show)expandedProposals.add(p.id);else expandedProposals.remove(p.id);original.setVisibility(show?View.VISIBLE:View.GONE);});
            expand.setContentDescription("Expandir u ocultar mensaje original de: "+p.title);c.addView(expand);c.addView(original);
            LinearLayout actions=row();Button add=primaryButton("＋ Agregar",()->openEditor(-1,p,null));actions.addView(add,new LinearLayout.LayoutParams(0,-2,1));View space=new View(this);actions.addView(space,new LinearLayout.LayoutParams(dp(8),1));actions.addView(button("No agregar",()->{Store.get(this).dismiss(p.id);Reminders.cancelProposal(this,p.id);render();}),new LinearLayout.LayoutParams(0,-2,1));c.addView(actions);
        }
        if(inbox.size()>inboxLimit)reviewList.addView(button("Ver más propuestas",()->{inboxLimit+=25;render();}));
    }
    void importText(String initial,String source){
        EditText text=input("Texto del mensaje",initial,android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);text.setMinLines(5);text.setMaxLines(12);text.setPadding(dp(18),dp(10),dp(18),dp(10));
        AlertDialog dialog=dialogBuilder().setTitle("Buscar actividades").setMessage("Revisa las propuestas: la interpretación por reglas puede requerir correcciones. Una actividad por línea ayuda a separarlas.").setView(text).setNegativeButton("Cancelar",null).setPositiveButton("Interpretar",null).create();
        dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{
            if(text.getText().toString().trim().isEmpty()){text.setError("Escribe o pega un mensaje.");return;}
            List<MessageParser.Proposal> proposals=MessageParser.parse(text.getText().toString(),System.currentTimeMillis(),ZoneId.systemDefault(),true);int n=0;
            for(MessageParser.Proposal p:proposals)if(Store.get(this).offer(p,source,System.currentTimeMillis()))n++;
            dialog.dismiss();page=2;render();toast(n+" propuesta(s) nuevas para revisar.");
        }));dialog.show();
    }
    void settingsPage(){
        LinearLayout tabs=row();String[] labels={"WhatsApp","Calendario","Opciones"};
        for(int n=0;n<3;n++){final int tab=n;Button b=button(labels[n],()->{connectionTab=tab;render();});b.setTextSize(11);b.setPadding(dp(4),0,dp(4),0);b.setMinWidth(0);
            ModernGlyph.button(b,new String[]{"whatsapp","google-calendar","widgets"}[n],
                               new int[]{ModernGlyph.GREEN,ModernGlyph.BLUE,ModernGlyph.VIOLET}[n],20);b.setTextColor(tab==connectionTab?0xffffffff:MUTED);b.setBackground(rounded(tab==connectionTab?GREEN:0xffffffff,15));tabs.addView(b,new LinearLayout.LayoutParams(0,dp(64),1));}
        body.addView(tabs);gap(body,14);
        if(connectionTab==0){whatsappSettings();return;}if(connectionTab==1){calendarSettings();return;}
        LinearLayout accessibility=card(body);
        accessibility.addView(text("Accesibilidad y lectura",20,INK,true));
        accessibility.addView(text("Elige el tamaño de letra de Agenda Clara. Se añade al tamaño establecido en Android.",13,MUTED,false));
        String[] sizes={"Normal · 100 %","Grande · 115 %","Muy grande · 130 %"};
        Spinner sizeChoice=new Spinner(this);
        sizeChoice.setContentDescription("Tamaño de texto");
        sizeChoice.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,sizes));
        int selectedSize=UiPreferences.sizePercent(this);
        sizeChoice.setSelection(selectedSize==130?2:selectedSize==115?1:0);
        accessibility.addView(sizeChoice);
        Switch contrast=new Switch(this);
        contrast.setText("Mayor contraste en textos secundarios");
        contrast.setTextColor(INK);contrast.setMinHeight(dp(52));contrast.setChecked(UiPreferences.contrast(this));
        accessibility.addView(contrast);
        accessibility.addView(button("Aplicar preferencias visuales",()->{
            UiPreferences.setSizePercent(this,UiPreferences.SCALES[sizeChoice.getSelectedItemPosition()]);
            UiPreferences.setContrast(this,contrast.isChecked());
            forceRefresh=true;render();toast("Preferencias visuales guardadas");
        }));
        accessibility.addView(text("Los lectores de pantalla reciben etiquetas para los botones de navegación y el estado de las tareas.",12,MUTED,false));
        LinearLayout alarm=card(body);alarm.addView(text("Recordatorios",20,INK,true));
        alarm.addView(text("Notificaciones: "+(Reminders.canNotify(this)?"activas":"pendientes de permiso")+"\nAlarmas exactas: "+(Reminders.exact(this)?"activas":"pendientes de permiso"),14,MUTED,false));
        alarm.addView(button("Activar o revisar notificaciones",this::notificationsPermission));
        alarm.addView(button("Alarmas y recordatorios",()->{if(Build.VERSION.SDK_INT>=31)safeStart(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));else toast("Este Android no requiere acceso especial para alarmas.");}));
        alarm.addView(button("Probar una notificación",()->{Task t=new Task();t.id=1900000000;t.title="Prueba de Agenda Clara";t.due=System.currentTimeMillis()+3600000;Reminders.showTask(this,t);toast(Reminders.canNotify(this)?"Se solicitó la notificación de prueba.":"Activa primero las notificaciones.");}));
        alarm.addView(text("Los avisos repetidos empiezan en la mayor anticipación que elijas y terminan al vencer. Android puede retrasar avisos sin acceso a alarmas exactas.",12,MUTED,false));
        LinearLayout widgets=card(body);widgets.addView(text("Widgets en tu pantalla de inicio",20,INK,true));widgets.addView(text("Lista de tareas con casillas y botón ＋, y una foto sin botones encima. Un doble toque abre sus opciones de imagen, zoom y encuadre. Mantén pulsado cada widget en el inicio para cambiar su tamaño.",14,MUTED,false));
        widgets.addView(button("Añadir widget de tareas",()->pinWidget(TaskWidget.class)));widgets.addView(button("Añadir widget de foto",()->pinWidget(PhotoWidget.class)));
        LinearLayout protection=card(body);
        protection.addView(text("Tus datos y copias de seguridad",20,INK,true));
        protection.addView(text("Exportar/recuperar tareas JSON sin mensajes ni claves de WhatsApp. El archivo NO está cifrado: consérvalo de forma privada.",13,MUTED,false));
        protection.addView(button("Exportar mis tareas",this::exportTasks));
        protection.addView(button("Restaurar tareas desde JSON",this::importTasks));
        protection.addView(text("Recomendado: copia cifrada con contraseña para guardarla fuera del teléfono.",13,MUTED,true));
        protection.addView(button("🔒 Exportar copia cifrada (.acbak)",()->requestSecureBackup(true)));
        protection.addView(button("🔑 Restaurar copia cifrada (.acbak)",()->requestSecureBackup(false)));
        protection.addView(button("♻  Papelera de tareas (7 días)",this::showTrash));
        protection.addView(button("Borrar mensajes y propuestas antiguos",()->dialogBuilder().setTitle("Limpieza de datos")
          .setMessage("Se borrarán los mensajes fuera del periodo de historial y propuestas atendidas hace más de 30 días. No afecta a tareas ni propuestas pendientes.")
          .setNegativeButton("Cancelar",null).setPositiveButton("Limpiar",(d,w)->new Thread(()->{
              int[] result=Store.get(this).purgeOldData(System.currentTimeMillis());
              runOnUiThread(()->toast("Mensajes: "+result[0]+" · Propuestas: "+result[1]+" retirados."));
          },"data-maintenance").start()).show()));
        protection.addView(text("Las tareas completadas se retiran de agenda tras una hora; el total semanal conserva solo fecha, sin título ni notas. Las tareas borradas manualmente permanecen 7 días en la papelera.",12,MUTED,false));
        LinearLayout about=card(body);about.addView(text("Agenda Clara 2.3 · Semana y recuperación",17,INK,true));about.addView(button("Licencias y código fuente",this::showLicenses));about.addView(text("Datos locales. Los permisos son opcionales. La interpretación se realiza en el teléfono. Las tareas vinculadas al calendario se escriben solo en el destino que elijas.",12,MUTED,false));
    }
    private static final int EXPORT_TASKS_REQUEST=642,IMPORT_TASKS_REQUEST=643;
    private static final int EXPORT_ENCRYPTED_REQUEST=644,IMPORT_ENCRYPTED_REQUEST=645;
    private void clearBackupPassword(){if(secureBackupPassword!=null)Arrays.fill(secureBackupPassword,'\0');secureBackupPassword=null;}
    private void requestSecureBackup(boolean exporting){
        clearBackupPassword();
        LinearLayout panel=column();panel.setPadding(dp(16),dp(4),dp(16),dp(4));
        EditText password=input("Contraseña (10 caracteres mínimo)","",android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setTransformationMethod(PasswordTransformationMethod.getInstance());panel.addView(password);
        EditText repeat=null;
        if(exporting){repeat=input("Repite la contraseña","",android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);repeat.setTransformationMethod(PasswordTransformationMethod.getInstance());panel.addView(repeat);}
        final EditText confirm=repeat;
        AlertDialog dlg=dialogBuilder().setTitle(exporting?"Crear copia cifrada":"Restaurar copia cifrada")
            .setMessage("El cifrado utiliza AES-GCM y una contraseña que no se guarda en la app. Si la pierdes, no podrás recuperar la copia. No se incluyen mensajes ni sesiones de WhatsApp.")
            .setView(panel).setNegativeButton("Cancelar",null).setPositiveButton("Continuar",null).create();
        dlg.setOnShowListener(ignore->dlg.getButton(-1).setOnClickListener(v->{
            String value=password.getText().toString();
            if(value.length()<10||value.length()>256){password.setError("De 10 a 256 caracteres.");return;}
            if(confirm!=null&&!value.equals(confirm.getText().toString())){confirm.setError("Las contraseñas no coinciden.");return;}
            secureBackupPassword=value.toCharArray();password.setText("");if(confirm!=null)confirm.setText("");
            dlg.dismiss();
            Intent intent=new Intent(exporting?Intent.ACTION_CREATE_DOCUMENT:Intent.ACTION_OPEN_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE).setType("application/octet-stream");
            if(exporting)intent.putExtra(Intent.EXTRA_TITLE,"Agenda-Clara-copia-cifrada.acbak");
            try{startActivityForResult(intent,exporting?EXPORT_ENCRYPTED_REQUEST:IMPORT_ENCRYPTED_REQUEST);}
            catch(ActivityNotFoundException ex){clearBackupPassword();toast("No hay una aplicación de archivos compatible.");}
        }));dlg.show();
    }
    private void encryptedResult(int request,Uri uri){
        final char[] password=secureBackupPassword;secureBackupPassword=null;
        if(password==null){toast("Vuelve a introducir la contraseña.");return;}
        new Thread(()->{
            try{
                final int count=request==EXPORT_ENCRYPTED_REQUEST?
                    SecureTaskBackup.exportTo(this,uri,password):SecureTaskBackup.importFrom(this,uri,password);
                if(request==IMPORT_ENCRYPTED_REQUEST){CompletedTaskCleanup.run(this);Reminders.rebuild(this);TaskWidget.refresh(this);}
                runOnUiThread(()->{toast(request==EXPORT_ENCRYPTED_REQUEST?"Copia cifrada guardada: "+count+" tareas.":"Restauradas "+count+" tareas desde copia cifrada.");forceRefresh=true;requestRefresh();});
            }catch(Exception ex){runOnUiThread(()->toast("No se pudo procesar la copia. Comprueba contraseña y archivo."));}
            finally{Arrays.fill(password,'\0');}
        },"secure-backup").start();
    }
    void exportTasks(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE,"Agenda-Clara-tareas.json");startActivityForResult(i,EXPORT_TASKS_REQUEST);
    }
    void importTasks(){
        dialogBuilder().setTitle("Restaurar tareas").setMessage("Solo archivos JSON de Agenda Clara. Se omiten duplicados. No se restauran mensajes, sesiones ni ID de eventos de calendario.")
            .setNegativeButton("Cancelar",null).setPositiveButton("Elegir archivo",(d,w)->{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json");
                startActivityForResult(i,IMPORT_TASKS_REQUEST);
            }).show();
    }
    void backupResult(int request,Uri uri){
        new Thread(()->{
            try{
                if(request==EXPORT_TASKS_REQUEST){
                    int count=TaskBackup.exportTo(this,uri);
                    runOnUiThread(()->toast("Se exportaron "+count+" tareas. Guarda el archivo en privado."));
                }else{
                    int count=TaskBackup.importFrom(this,uri);
                    CompletedTaskCleanup.run(this);Reminders.rebuild(this);TaskWidget.refresh(this);
                    runOnUiThread(()->{toast("Se recuperaron "+count+" tareas; duplicados omitidos.");forceRefresh=true;requestRefresh();});
                }
            }catch(Exception ex){runOnUiThread(()->toast("Error de copia: "+(ex.getMessage()==null?"Archivo incompatible":ex.getMessage())));}
        },"agenda-backup").start();
    }
    boolean notificationAccess(){
        String enabled=Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");
        String component=new ComponentName(this,WhatsAppListener.class).flattenToString();
        if(enabled!=null)for(String item:enabled.split(":")){
            ComponentName name=ComponentName.unflattenFromString(item);
            if(name!=null&&name.equals(new ComponentName(this,WhatsAppListener.class)))return true;
        }
        return false;
    }
    void connectWhatsapp(){
        dialogBuilder().setTitle("Vincular notificaciones de WhatsApp")
            .setMessage("Android concede acceso amplio a las notificaciones. Agenda Clara filtra WhatsApp y WhatsApp Business. Solo interpreta mensajes nuevos de los chats que selecciones. Los chats se descubren por sus notificaciones; este permiso no entrega el historial ni el catálogo completo de WhatsApp.")
            .setNegativeButton("Volver",null).setPositiveButton("Continuar",(d,w)->{
                SharedPreferences prefs=Prefs.get(this);
                SharedPreferences.Editor edit=prefs.edit().putBoolean("discover",true).putBoolean("capture",true);
                if(!prefs.getBoolean("capture",false))edit.putLong("capture_since",System.currentTimeMillis());
                edit.apply();
                // POST_NOTIFICATIONS is for showing alerts, NOT for receiving WhatsApp messages.
                // Always open Android's dedicated Notification Listener access screen.
                safeStart(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                sendBroadcast(new Intent(WhatsAppListener.REFRESH).setPackage(getPackageName()));render();
            }).show();
    }
    void session(String action,String value){if("consent".equals(action)&&!WhatsAppSessionService.running)return;try{WhatsAppSessionService.start(this,action,value);}catch(IllegalStateException|SecurityException e){toast("Abre la app y vuelve a iniciar la conexión.");}}
    void chooseHistoryCount(Store.Chat chat){
        if(!chat.selected||chat.jid.isEmpty()){toast("Autoriza primero la lectura del grupo.");return;}
        int[] counts=HistoryPageOptions.values();String[] labels=new String[counts.length];final int[] choice={HistoryPageOptions.saved(Prefs.get(this).getInt("wa_history_count",50))};int selected=counts.length-1;
        for(int n=0;n<counts.length;n++){labels[n]=counts[n]+" mensajes anteriores";if(counts[n]==choice[0])selected=n;}
        consentDialog=dialogBuilder().setTitle("Mensajes anteriores").setSingleChoiceItems(labels,selected,(d,n)->choice[0]=counts[n]).setNegativeButton("Volver",null).setPositiveButton("Solicitar",(d,w)->{
            Store.Chat current=Store.get(this).getChat(chat.key);if(current==null||!current.selected){toast("El permiso de lectura ya no está activo.");return;}
            Prefs.get(this).edit().putInt("wa_history_count",choice[0]).apply();try{WhatsAppSessionService.start(this,"more",chat.jid,choice[0]);toast("Solicitando "+choice[0]+" mensajes anteriores. La entrega depende de WhatsApp.");}catch(IllegalStateException|SecurityException e){toast("Abre la app y reanuda la conexión.");}render();
        }).show();consentDialog.getListView().setTag("history_page_options");
    }
    void linkWhatsapp(){
        dialogBuilder().setTitle("Vincular como dispositivo adicional")
            .setMessage("Esta conexión usa whatsmeow, un cliente no oficial. WhatsApp advierte que las conexiones no oficiales pueden causar restricciones de la cuenta.\n\nEl acceso del dispositivo vinculado es amplio. Pueden recibirse lotes de la cuenta; la app filtra los grupos que autorices antes de interpretar o guardar sus textos. Las claves de sesión se guardan en este teléfono. El historial puede ser parcial.\n\nDespués elegirás cada grupo y autorizarás su lectura. Guardar cada tarea requiere otra decisión tuya.")
            .setNegativeButton("Volver",null).setNeutralButton("Aviso de WhatsApp",(d,w)->safeStart(new Intent(Intent.ACTION_VIEW,Uri.parse("https://faq.whatsapp.com/1217634902127718/"))))
            .setPositiveButton("Entendido, continuar",(d,w)->{
                EditText phone=input("Código de país y número, por ejemplo 519…","",android.text.InputType.TYPE_CLASS_PHONE);phone.setSingleLine(true);phone.setPadding(dp(20),dp(12),dp(20),dp(12));
                AlertDialog dialog=dialogBuilder().setTitle("Vincular tu WhatsApp").setMessage("Escribe tu número con código de país. El código aparecerá aquí; se introduce en WhatsApp → Dispositivos vinculados → Vincular con número de teléfono. No es un código SMS.").setView(phone).setNegativeButton("Volver",null).setPositiveButton("Obtener código",null).create();
                dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{String number=phone.getText().toString().replaceAll("[^0-9]","");if(number.length()<8||number.length()>15){phone.setError("Incluye código de país y número.");return;}Prefs.get(this).edit().putBoolean("wa_link_consent_v1",true).putBoolean("capture",false).putBoolean("discover",false).putBoolean("wa_reading",true).remove("wa_pair_code").apply();notificationsPermission();session("pair",number);dialog.dismiss();render();}));dialog.show();
            }).show();
    }
    void chooseGroup(Store.Chat chat){
        if(chat.community){toast("Despliega la comunidad y selecciona uno de sus grupos.");return;}
        final boolean notificationChat=chat.jid.isEmpty();
        final String kind=chat.group?"grupo":"chat individual";
        if(chat.selected){consentDialog=dialogBuilder().setTitle("Revocar lectura de "+kind).setMessage("Se quitarán los mensajes y propuestas locales asociados a "+chat.title+". Tus tareas se conservarán.").setNegativeButton("Volver",null).setPositiveButton("Revocar lectura",(d,w)->{for(long id:Store.get(this).revokeReading(chat.key))Reminders.cancelProposal(this,id);if(!notificationChat)session("consent",null);render();}).show();return;}
        if(!notificationChat&&!chat.joined){toast("WhatsApp muestra este subgrupo, pero no confirma acceso. Únete desde WhatsApp y actualiza.");return;}
        if(notificationChat){
            consentDialog=dialogBuilder().setTitle("Autorizar "+kind+": "+chat.title)
                .setMessage("Se interpretarán solamente los mensajes NUEVOS que Android entregue mediante notificaciones de este chat y únicamente después de autorizarlo. No se obtiene el historial ni la lista completa de WhatsApp. El permiso del sistema para notificaciones es amplio; solo se guarda el contenido de chats seleccionados. Puedes revocarlo.")
                .setNegativeButton("Cancelar",null).setPositiveButton("Autorizar",(d,w)->{
                    Store.get(this).selectChat(chat.key,true);
                    SharedPreferences prefs=Prefs.get(this);
                    SharedPreferences.Editor edit=prefs.edit().putBoolean("discover",true).putBoolean("capture",true);
                    if(!prefs.getBoolean("capture",false))edit.putLong("capture_since",System.currentTimeMillis());
                    edit.apply();
                    if(!notificationAccess())safeStart(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                    sendBroadcast(new Intent(WhatsAppListener.REFRESH).setPackage(getPackageName()));render();
                }).show();return;
        }
        consentDialog=dialogBuilder().setTitle("Permitir lectura de "+chat.title)
            .setMessage("Autorizas a Agenda Clara a leer e interpretar los mensajes disponibles y los nuevos de este grupo mientras la lectura esté activa. Se revisará el historial sincronizado del periodo elegido. Puedes revocar este permiso tocando de nuevo el grupo.\n\nEsto permite interpretar el chat. Cada posible tarea se propone para que tú la agregues y guardes.")
            .setNegativeButton("Volver",null).setPositiveButton("Permitir lectura",(d,w)->{Store.get(this).selectChat(chat.key,true);Prefs.get(this).edit().putBoolean("wa_reading",true).apply();if(!WhatsAppSessionService.running||!Prefs.get(this).getBoolean("wa_connected",false))session("resume",null);session("history",chat.jid);render();}).show();
    }
    void whatsappSettings(){
        SharedPreferences prefs=Prefs.get(this);boolean linked=prefs.getBoolean("wa_linked",false),connected=prefs.getBoolean("wa_connected",false)&&WhatsAppSessionService.running;
        List<Store.Chat> all=Store.get(this).chats(),chats=new ArrayList<>(all);int selected=0;for(Store.Chat c:chats)if(c.selected)selected++;
        LinearLayout hero=card(body);hero.setBackground(gradient(0xff2748b9,0xff7563d9,23));hero.addView(text(connected?"Tus comunidades, a mano":"Conecta tus comunidades",23,0xffffffff,true));gap(hero,8);hero.addView(text("1  Vincula     2  Elige grupos     3  Revisa",12,0xffd8eadf,true));gap(hero,10);hero.addView(text(prefs.getString("wa_status","Consulta tus grupos sin esperar un mensaje nuevo."),14,0xffedf5ee,false));
        Button connect=button(linked?(connected?"Actualizar grupos":"Reanudar conexión"):"Vincular WhatsApp",()->{if(linked)session(connected?"groups":"resume",null);else linkWhatsapp();});hero.addView(connect);
        String code=prefs.getString("wa_pair_code","");if(!code.isEmpty()){
            LinearLayout pair=card(body);pair.addView(text(System.currentTimeMillis()<prefs.getLong("wa_pair_expires",0)?"Tu código de vinculación":"El código ha caducado",17,INK,true));TextView number=text(code,32,GREEN,true);number.setGravity(Gravity.CENTER);number.setTextIsSelectable(true);number.setPadding(0,dp(12),0,dp(12));pair.addView(number);pair.addView(text("En WhatsApp abre Dispositivos vinculados y elige vincular con número de teléfono. Introduce este código; después regresa aquí.",14,MUTED,false));pair.addView(button("Abrir WhatsApp",this::openWhatsapp));pair.addView(button("Solicitar otro código",this::linkWhatsapp));
        }
        if(linked){
            LinearLayout controls=card(body);Switch reading=new Switch(this);reading.setText("Lectura de grupos autorizados");reading.setTextColor(INK);reading.setMinHeight(dp(52));reading.setChecked(prefs.getBoolean("wa_reading",false));controls.addView(reading);reading.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("wa_reading",on).apply();session(on?"resume":"pause",null);});
            Switch notify=new Switch(this);notify.setText("Avisar de nuevas propuestas");notify.setTextColor(INK);notify.setMinHeight(dp(52));notify.setChecked(prefs.getBoolean("wa_notify",true));controls.addView(notify);notify.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("wa_notify",on).apply();if(on)notificationsPermission();});
            int days=prefs.getInt("wa_history_days",30);controls.addView(button("Historial: últimos "+days+" días",()->dialogBuilder().setTitle("Periodo para revisar").setItems(new String[]{"Últimos 30 días","Últimos 90 días","Último año"},(d,w)->{prefs.edit().putInt("wa_history_days",new int[]{30,90,365}[w]).apply();session("consent",null);render();}).show()));
            controls.addView(text("Se interpreta texto y pies de foto. No se descargan audios ni archivos. WhatsApp decide qué historial entrega; no equivale a todo el chat.",12,MUTED,false));
        }
        LinearLayout diagnostic=card(body);
        diagnostic.setBackground(gradient(0xffffffff,0xfff1f5ff,22));
        diagnostic.addView(text("Diagnóstico de recepción · WhatsApp",17,INK,true));
        gap(diagnostic,6);
        boolean listenerPermission=notificationAccess();
        boolean listenerRunning=prefs.getBoolean("wa_diag_listener_connected",false);
        boolean captureOn=prefs.getBoolean("capture",false);
        diagnostic.addView(text("Acceso de Android: "+(listenerPermission?"Concedido":"Pendiente")+
            "  ·  Servicio: "+(listenerRunning?"Conectado":"No confirmado")+
            "\nCaptura de mensajes: "+(captureOn?"Activada":"Desactivada")+
            "  ·  Chats seleccionados: "+selected,13,INK,false));
        long lastNotif=prefs.getLong("wa_diag_last_whatsapp",0);
        long lastMsg=prefs.getLong("wa_diag_last_received",0);
        diagnostic.addView(text("Última notificación: "+(lastNotif==0?"Sin registrar":new java.util.Date(lastNotif).toString())+
            "\nÚltimo texto autorizado: "+(lastMsg==0?"Sin registrar":new java.util.Date(lastMsg).toString())+
            "\nNotificaciones detectadas: "+prefs.getInt("wa_diag_event_count",0)+
            " · Textos recibidos: "+prefs.getInt("wa_diag_received_count",0)+
            " · Propuestas: "+prefs.getInt("wa_diag_proposal_count",0),12,MUTED,false));
        diagnostic.addView(text(prefs.getString("wa_diag_state","Sin diagnóstico todavía. Envía un mensaje de prueba desde otro dispositivo."),12,MUTED,false));
        diagnostic.addView(button("Configurar acceso de lectura",()->safeStart(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))));
        diagnostic.addView(button("Actualizar diagnóstico",()->{forceRefresh=true;render();}));
        diagnostic.addView(button("Probar intérprete sin guardar datos",()->{
            String sample="Para mañana deben entregar el informe y preparar una exposición.";
            int found=MessageParser.parse(sample,System.currentTimeMillis(),
                java.time.ZoneId.systemDefault(),false).size();
            dialogBuilder().setTitle("Prueba local del intérprete")
                .setMessage("Propuestas detectadas: "+found+
                    "\\nEsta prueba no lee WhatsApp, no guarda mensajes y no crea tareas. "+
                    (found>0?"El análisis básico funciona; comprueba ahora el permiso de recepción.":"No se ha reconocido la muestra: revisa el clasificador."))
                .setPositiveButton("Entendido",null).show();
        }));
        diagnostic.addView(text("Los contadores no guardan texto de chats sin autorizar. Si WhatsApp oculta el contenido de las notificaciones, Android no puede entregarlo al intérprete.",12,MUTED,false));
        subtitle(body,"Comunidades, grupos y chats · "+selected+" autorizados");
        body.addView(text("Abre una comunidad para ver sus grupos. Los chats individuales se identifican cuando Android notifica una conversación y autorizas su detección. La lista no representa todo tu WhatsApp.",12,MUTED,false));gap(body,9);
        EditText search=input("Buscar comunidad, grupo o chat",chatQuery,android.text.InputType.TYPE_CLASS_TEXT);search.setTag("group_search");search.setSingleLine(true);body.addView(search);gap(body,8);
        LinearLayout filters=row();filters.addView(button("Actualizar",()->{if(Prefs.get(this).getBoolean("wa_linked",false))session("groups",null);if(notificationAccess())sendBroadcast(new Intent(WhatsAppListener.REFRESH).setPackage(getPackageName()));render();}),new LinearLayout.LayoutParams(0,-2,1));filters.addView(button("Revisar propuestas",()->{page=2;render();}),new LinearLayout.LayoutParams(0,-2,1));body.addView(filters);gap(body,10);
        HorizontalScrollView filterScroll=new HorizontalScrollView(this);filterScroll.setHorizontalScrollBarEnabled(false);LinearLayout filterChips=row();
        String[] groupLabels={"Todos","Comunidades","Grupos","Individuales","Autorizados","Pendientes","Con historial"};
        for(int j=0;j<groupLabels.length;j++){
            final int selectedFilter=j;Button chip=button(groupLabels[j],()->{groupFilter=selectedFilter;chatLimit=40;render();});
            chip.setTextColor(j==groupFilter?0xffffffff:MUTED);
            chip.setBackground(rounded(j==groupFilter?GREEN:0xfff0f4fd,18));filterChips.addView(chip);
        }
        filterScroll.addView(filterChips);body.addView(filterScroll);gap(body,8);
        LinearLayout list=column();body.addView(list);fillChats(list,chats,chatQuery);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence t,int a,int c,int f){}public void onTextChanged(CharSequence t,int a,int before,int count){chatQuery=t.toString();chatLimit=40;if(groupSearch!=null)handler.removeCallbacks(groupSearch);groupSearch=()->{if(page==3&&connectionTab==0&&search.isAttachedToWindow())fillChats(list,chats,chatQuery);};handler.postDelayed(groupSearch,120);}public void afterTextChanged(Editable e){}});
        LinearLayout scope=card(body);scope.addView(text("Lectura con permiso, tareas con revisión",17,INK,true));gap(scope,6);scope.addView(text("El indicador de selección muestra el permiso para leer e interpretar el grupo. Agregar abre el editor; Guardar crea la tarea. El análisis local puede omitir mensajes o necesitar correcciones.",13,MUTED,false));
        if(linked)scope.addView(button("Desvincular y borrar mensajes locales",()->dialogBuilder().setTitle("Desvincular WhatsApp").setMessage("Se cerrará el dispositivo vinculado y se quitarán sus mensajes y propuestas locales. Tus tareas se conservarán. Necesitas conexión; también puedes revocar el dispositivo desde WhatsApp.").setNegativeButton("Volver",null).setPositiveButton("Desvincular",(d,w)->session("logout",null)).show()));
        scope.addView(button("Abrir WhatsApp",this::openWhatsapp));
        LinearLayout legacy=card(body);legacy.addView(text("Opción por notificaciones",16,INK,true));legacy.addView(text("Disponible como alternativa para mensajes nuevos. Este permiso no carga comunidades ni historial.",12,MUTED,false));legacy.addView(button("Configurar notificaciones de WhatsApp",this::connectWhatsapp));
        Switch capture=new Switch(this);capture.setText("Reconocer grupos y chats individuales desde notificaciones");capture.setTextColor(INK);capture.setMinHeight(dp(52));capture.setChecked(prefs.getBoolean("discover",false));
        capture.setOnCheckedChangeListener((v,on)->{
            SharedPreferences.Editor change=prefs.edit().putBoolean("discover",on).putBoolean("capture",on);
            if(on&&!prefs.getBoolean("capture",false))change.putLong("capture_since",System.currentTimeMillis());
            change.apply();
            if(on){
                if(!notificationAccess())safeStart(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                else {
                    android.service.notification.NotificationListenerService.requestRebind(new ComponentName(this,WhatsAppListener.class));
                    sendBroadcast(new Intent(WhatsAppListener.REFRESH).setPackage(getPackageName()));
                }
            }
        });legacy.addView(capture);
        legacy.addView(text("La detección por notificaciones solo ofrece conversaciones visibles para Android, no un inventario de chats. Toca cada tarjeta para autorizar su lectura.",12,MUTED,false));
    }
    void openWhatsapp(){Intent i=getPackageManager().getLaunchIntentForPackage("com.whatsapp");if(i==null)i=getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b");if(i==null)toast("No se encontró WhatsApp instalado.");else safeStart(i);}
    boolean isChatGroup(Store.Chat chat){return chat.group||(!chat.community&&!chat.jid.isEmpty());}
    boolean matchesConnectionFilter(Store.Chat chat){
        switch(groupFilter){
            case 1:return chat.community;
            case 2:return !chat.community&&isChatGroup(chat);
            case 3:return !chat.community&&!isChatGroup(chat);
            case 4:return !chat.community&&chat.selected;
            case 5:return !chat.community&&!chat.selected;
            case 6:return !chat.community&&Store.get(this).messageCount(chat.key)>0;
            default:return true;
        }
    }
    boolean matchesConnectionSearch(Store.Chat chat,String q,Map<String,Store.Chat> parents){
        if(q.isEmpty())return true;
        String name=chat.title==null?"":chat.title.toLowerCase(Locale.ROOT);
        Store.Chat parent=parents.get(chat.parent);
        return name.contains(q)||(parent!=null&&parent.title.toLowerCase(Locale.ROOT).contains(q));
    }
    void fillChats(LinearLayout list,List<Store.Chat> chats,String query){
        list.removeAllViews();
        String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);
        Map<String,Store.Chat> parents=new LinkedHashMap<>();
        for(Store.Chat chat:chats)if(chat.community&&!chat.jid.isEmpty())parents.put(chat.jid,chat);
        Map<String,List<Store.Chat>> children=new HashMap<>();
        for(Store.Chat chat:chats)if(!chat.community&&parents.containsKey(chat.parent))
            children.computeIfAbsent(chat.parent,k->new ArrayList<>()).add(chat);
        List<Store.Chat> sorted=new ArrayList<>(chats);
        sorted.sort((a,b)->{if(a.community!=b.community)return a.community?-1:1;
            if(a.selected!=b.selected)return a.selected?-1:1;
            return a.title.compareToIgnoreCase(b.title);});
        int visible=0,remaining=0;
        boolean tree=groupFilter==0||groupFilter==1;
        for(Store.Chat chat:sorted){
            boolean isNested=!chat.community&&parents.containsKey(chat.parent);
            if(tree&&isNested)continue;
            if(!matchesConnectionFilter(chat))continue;
            
            if(!matchesConnectionSearch(chat,q,parents)){
                if(!chat.community||!tree)continue;
                boolean childMatch=false;
                for(Store.Chat child:children.getOrDefault(chat.jid,Collections.emptyList()))
                    if(matchesConnectionSearch(child,q,Collections.emptyMap())){childMatch=true;break;}
                if(!childMatch)continue;
            }
            if(visible++>=chatLimit){remaining++;continue;}
            if(chat.community&&tree){
                List<Store.Chat> groupChildren=children.getOrDefault(chat.jid,Collections.emptyList());
                LinearLayout parent=card(list);parent.setTag("community:"+chat.key);
                parent.setPadding(dp(15),dp(13),dp(15),dp(13));
                LinearLayout heading=row();TextView arrow=text("⌄",24,GREEN,true);
                heading.addView(arrow,new LinearLayout.LayoutParams(dp(38),dp(44)));
                LinearLayout labels=column();labels.addView(text(chat.title,17,INK,true));
                labels.addView(text("COMUNIDAD · "+groupChildren.size()+" grupos",11,GREEN,true));
                heading.addView(labels,new LinearLayout.LayoutParams(0,-2,1));parent.addView(heading);
                LinearLayout inner=column();inner.setPadding(dp(9),dp(8),0,0);
                List<Store.Chat> groupSorted=new ArrayList<>(groupChildren);
                groupSorted.sort((a,b)->a.title.compareToIgnoreCase(b.title));
                int shown=0;
                for(Store.Chat child:groupSorted)if(q.isEmpty()||matchesConnectionSearch(child,q,parents)){
                    addConnectionCard(inner,child,chat.title);shown++;
                }
                if(shown==0)inner.addView(text("No hay subgrupos disponibles con ese filtro. Actualiza desde WhatsApp.",12,MUTED,false));
                parent.addView(inner);
                boolean open=expandedChatCards.contains(chat.key)||!q.isEmpty();
                inner.setVisibility(open?View.VISIBLE:View.GONE);arrow.setText(open?"⌃":"›");
                heading.setOnClickListener(v->{boolean expanded=inner.getVisibility()!=View.VISIBLE;
                    inner.setVisibility(expanded?View.VISIBLE:View.GONE);arrow.setText(expanded?"⌃":"›");
                    if(expanded)expandedChatCards.add(chat.key);else expandedChatCards.remove(chat.key);});
                parent.setOnClickListener(v->heading.performClick());
                heading.setContentDescription("Desplegar comunidad "+chat.title);
            }else addConnectionCard(list,chat,parents.containsKey(chat.parent)?parents.get(chat.parent).title:null);
        }
        if(remaining>0)list.addView(button("Ver "+Math.min(40,remaining)+" conversaciones más",()->{
            chatLimit+=40;fillChats(list,chats,query);
        }));
        if(visible==0){LinearLayout empty=card(list);
            empty.addView(text(chats.isEmpty()?"Aún no hay conversaciones detectadas":"Sin coincidencias",18,INK,true));
            empty.addView(text(chats.isEmpty()?"Vincula WhatsApp para obtener grupos compatibles o activa la detección por notificaciones para descubrir conversaciones nuevas.":"Modifica el filtro o escribe otro nombre.",13,MUTED,false));
        }
    }
    void addConnectionCard(LinearLayout container,Store.Chat chat,String parent){
        boolean nativeChat=!chat.jid.isEmpty();boolean group=isChatGroup(chat);
        LinearLayout card=card(container);card.setTag("chat:"+chat.key);
        card.setBackground(outlined(chat.selected?0xfff0f5ff:0xffffffff,18,chat.selected?0xffbed2ff:STROKE));
        card.setPadding(dp(14),dp(12),dp(14),dp(12));
        LinearLayout heading=row();TextView arrow=text("›",22,GREEN,true);
        heading.addView(arrow,new LinearLayout.LayoutParams(dp(34),dp(42)));
        LinearLayout labels=column();labels.addView(text(chat.title,16,INK,true));
        String type=group?"GRUPO":"CHAT INDIVIDUAL";
        String origin=nativeChat?" · VINCULADO":" · NOTIFICACIONES";
        labels.addView(text(type+origin,10,GREEN,true));
        if(parent!=null)labels.addView(text("Comunidad: "+parent,11,MUTED,false));
        heading.addView(labels,new LinearLayout.LayoutParams(0,-2,1));card.addView(heading);
        LinearLayout details=column();details.setPadding(dp(6),dp(7),dp(6),dp(6));
        details.addView(text(chat.selected?"✓ Lectura autorizada":nativeChat&&!chat.joined?"Acceso al subgrupo sin confirmar":"Lectura pendiente de autorización",12,MUTED,false));
        if(!chat.scanState.isEmpty())details.addView(text(chat.scanState,12,MUTED,false));
        int saved=Store.get(this).messageCount(chat.key);
        if(saved>0)details.addView(text("Mensajes almacenados: "+saved,12,MUTED,false));
        details.addView(button(chat.selected?"Revocar lectura":"Autorizar lectura",()->chooseGroup(chat)));
        if(chat.selected){
            if(nativeChat){
                details.addView(button("Revisar historial sincronizado",()->session("history",chat.jid)));
                details.addView(button("Mensajes anteriores · "+HistoryPageOptions.saved(Prefs.get(this).getInt("wa_history_count",50)),()->chooseHistoryCount(chat)));
            }
            details.addView(button("Importar conversación .txt",()->importHistory(chat)));
        }
        if(!nativeChat)details.addView(text("Solo notificaciones observadas; no incluye chats que aún no hayan notificado.",11,MUTED,false));
        card.addView(details);
        boolean open=expandedChatCards.contains(chat.key);
        details.setVisibility(open?View.VISIBLE:View.GONE);arrow.setText(open?"⌃":"›");
        heading.setOnClickListener(v->{boolean expanding=details.getVisibility()!=View.VISIBLE;
            details.setVisibility(expanding?View.VISIBLE:View.GONE);arrow.setText(expanding?"⌃":"›");
            if(expanding)expandedChatCards.add(chat.key);else expandedChatCards.remove(chat.key);
        });
        card.setOnClickListener(v->heading.performClick());
        heading.setContentDescription((open?"Contraer ":"Desplegar ")+chat.title);
    }
    void importHistory(Store.Chat chat){
        if(!chat.selected){toast("Autoriza primero la lectura de esta conversación.");return;}
        dialogBuilder().setTitle("Importar historial de "+chat.title).setMessage("En WhatsApp exporta este chat sin archivos multimedia y elige su archivo .txt. Se conservarán las fechas originales. Se usa día/mes/año y la zona horaria de este teléfono. Se revisan hasta 4.000 mensajes dentro del periodo elegido. No se puede verificar que el archivo corresponda al grupo: elígelo con cuidado.").setNegativeButton("Volver",null).setPositiveButton("Elegir archivo",(d,w)->{pendingHistoryChat=chat.key;Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(pick,540);}).show();
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==EXPORT_ENCRYPTED_REQUEST||request==IMPORT_ENCRYPTED_REQUEST){
            if(result==RESULT_OK&&data!=null&&data.getData()!=null)encryptedResult(request,data.getData());
            else clearBackupPassword();return;
        }
        if((request==EXPORT_TASKS_REQUEST||request==IMPORT_TASKS_REQUEST)&&result==RESULT_OK&&data!=null&&data.getData()!=null){backupResult(request,data.getData());return;}
        if(request!=540||result!=RESULT_OK||data==null||data.getData()==null)return;
        final String key=pendingHistoryChat;pendingHistoryChat="";final Uri uri=data.getData();Store.Chat chat=Store.get(this).getChat(key);
        if(chat==null||!chat.selected){toast("La conversación ya no tiene permiso de lectura.");return;}
        toast("Revisando el archivo del grupo…");new Thread(()->{
            try(java.io.InputStream stream=getContentResolver().openInputStream(uri)){
                if(stream==null)throw new java.io.IOException("No se pudo abrir el archivo.");
                List<ConversationAnalyzer.Message> messages=HistoryTextParser.parse(stream,ZoneId.systemDefault());int stored=0;long cutoff=System.currentTimeMillis()-Prefs.get(this).getInt("wa_history_days",30)*86400000L;
                for(ConversationAnalyzer.Message m:messages)if(m.time>=cutoff&&m.time<=System.currentTimeMillis()+60000L&&(chat.jid.isEmpty()?Store.get(this).recordImportedMessage(key,m):Store.get(this).recordMessage(key,m)))stored++;
                int count=chat.jid.isEmpty()?ReviewFlow.analyzeImported(this,key):ReviewFlow.analyzeLinked(this,key,true,"");Store.get(this).scanState(key,stored+" mensajes del archivo · "+count+" propuestas nuevas");runOnUiThread(()->{toast(count+" propuestas nuevas. Revisa el contenido y las fechas.");render();});
            }catch(Exception e){runOnUiThread(()->toast(e.getMessage()==null?"No se pudo interpretar este archivo.":e.getMessage()));}
        },"import-group-history").start();
    }
    /** Cada cuenta es un acordeón independiente: sin confundir calendarios de cuentas distintas. */
    void calendarSettings(){
        LinearLayout info=card(body);info.addView(text("Google Calendar · Por cuentas",20,INK,true));gap(info,8);
        info.addView(text("Los calendarios proceden de las cuentas sincronizadas en este Android. Pulsa una cuenta y después su calendario para desplegarlo.",13,MUTED,false));
        boolean allowed=CalendarBridge.allowed(this);
        info.addView(text(allowed?"● Calendario autorizado":"○ Requiere permiso de calendario",13,allowed?SUCCESS:RED,true));
        info.addView(button(allowed?"Actualizar cuentas y calendarios":"Conectar Google Calendar",this::chooseCalendar));
        if(!allowed){info.addView(text("Para ver calendarios de cada cuenta, concede permisos de lectura y escritura. Agenda Clara no solicita contraseñas de Google.",12,MUTED,false));return;}
        List<CalendarBridge.CalendarInfo> calendars;
        try{calendars=CalendarBridge.calendars(this);}catch(Exception error){info.addView(text("No se pudieron leer calendarios. Comprueba la sincronización de Android.",13,RED,false));return;}
        Map<String,List<CalendarBridge.CalendarInfo>> accounts=new LinkedHashMap<>();
        for(CalendarBridge.CalendarInfo k:calendars){String key=(k.google?"Google: ":"Android: ")+(k.account==null?"Cuenta sin nombre":k.account);
            accounts.computeIfAbsent(key,unused->new ArrayList<>()).add(k);}
        if(accounts.isEmpty()){
            LinearLayout missing=card(body);missing.addView(text("No se encontraron calendarios",17,INK,true));
            missing.addView(text("Añade una cuenta en Android y activa la sincronización del Calendario.",13,MUTED,false));
            missing.addView(button("Abrir cuentas de Android",()->safeStart(new Intent(Settings.ACTION_SYNC_SETTINGS))));
        }
        for(Map.Entry<String,List<CalendarBridge.CalendarInfo>> account:accounts.entrySet()){
            String key=account.getKey();List<CalendarBridge.CalendarInfo> members=account.getValue();
            LinearLayout card=card(body);card.setTag("calendar_account:"+key);
            LinearLayout heading=row();TextView arrow=text("›",22,GREEN,true);heading.addView(arrow,new LinearLayout.LayoutParams(dp(35),dp(42)));
            LinearLayout labels=column();labels.addView(text(key,16,INK,true));
            labels.addView(text(members.size()+(members.size()==1?" calendario":" calendarios"),12,MUTED,false));
            heading.addView(labels,new LinearLayout.LayoutParams(0,-2,1));card.addView(heading);
            LinearLayout inside=column();inside.setPadding(dp(6),dp(9),0,0);
            for(CalendarBridge.CalendarInfo cal:members)calendarAccountChild(inside,cal,key);
            card.addView(inside);boolean open=expandedCalendarAccounts.contains(key);inside.setVisibility(open?View.VISIBLE:View.GONE);arrow.setText(open?"⌃":"›");
            heading.setContentDescription("Desplegar cuenta "+key);
            heading.setOnClickListener(v->{boolean show=inside.getVisibility()!=View.VISIBLE;inside.setVisibility(show?View.VISIBLE:View.GONE);arrow.setText(show?"⌃":"›");
                if(show)expandedCalendarAccounts.add(key);else expandedCalendarAccounts.remove(key);});
        }
        LinearLayout actions=card(body);actions.addView(text("Importar y exportar",18,INK,true));
        actions.addView(text("Elige un calendario dentro de su cuenta para importar sus eventos como clases semanales de Mi horario. Antes de guardarlos se muestra una revisión.",12,MUTED,false));
        actions.addView(button("Revisar eventos como tareas",this::pickEvents));
        actions.addView(button("Exportar tareas vinculadas a Google Calendar",()->background(()->CalendarBridge.sendAll(this))));
        actions.addView(button("Comprobar enlaces con Google Calendar",()->background(()->CalendarBridge.diagnostics(this))));
        actions.addView(text("La importación de clases no modifica ni borra eventos de Google Calendar. Los cambios remotos dependen de la sincronización de Android.",12,MUTED,false));
        info.addView(text("Destino actual para tareas: "+Prefs.get(this).getString("calendar_name","Sin elegir"),12,GREEN,true));
    }
    void calendarAccountChild(LinearLayout container,CalendarBridge.CalendarInfo calendar,String account){
        LinearLayout item=card(container);item.setTag("calendar:"+calendar.id);
        LinearLayout head=row();TextView arrow=text("›",19,GREEN,true);head.addView(arrow,new LinearLayout.LayoutParams(dp(30),dp(40)));
        LinearLayout summary=column();summary.addView(text(calendar.name,15,INK,true));summary.addView(text(calendar.writable?"Puede recibir tareas":"Solo lectura",11,MUTED,false));
        head.addView(summary,new LinearLayout.LayoutParams(0,-2,1));item.addView(head);
        LinearLayout details=column();details.setPadding(dp(4),dp(6),dp(4),dp(6));
        CheckBox selected=new CheckBox(this);selected.setText("Incluir en revisión de eventos");selected.setTextColor(INK);
        selected.setChecked(Prefs.calendars(this).contains(""+calendar.id));
        selected.setOnCheckedChangeListener((v,on)->Prefs.selectCalendar(this,calendar.id,on));details.addView(selected);
        details.addView(button("Ver eventos y exportar a Mi horario",()->previewCalendarSchedule(calendar)));
        if(calendar.writable)details.addView(button(Prefs.calendar(this)==calendar.id?"✓ Destino actual de tareas":"Usar como destino de tareas",()->{
            Prefs.get(this).edit().putLong("calendar",calendar.id).putString("calendar_name",calendar.name+" · "+calendar.account).apply();
            Prefs.selectCalendar(this,calendar.id,true);toast("Destino actualizado: "+calendar.name);render();}));
        item.addView(details);boolean open=expandedCalendarIds.contains(calendar.id);details.setVisibility(open?View.VISIBLE:View.GONE);arrow.setText(open?"⌃":"›");
        head.setContentDescription("Desplegar calendario "+calendar.name+" de "+account);
        head.setOnClickListener(v->{boolean show=details.getVisibility()!=View.VISIBLE;details.setVisibility(show?View.VISIBLE:View.GONE);arrow.setText(show?"⌃":"›");
            if(show)expandedCalendarIds.add(calendar.id);else expandedCalendarIds.remove(calendar.id);});
    }
    void previewCalendarSchedule(CalendarBridge.CalendarInfo calendar){
        if(!CalendarBridge.allowed(this)){chooseCalendar();return;}
        toast("Leyendo eventos del calendario…");
        new Thread(()->{
            try{
                // Solo consulta al proveedor del calendario Android. No se transfieren contraseñas.
                List<CalendarBridge.Event> events=CalendarBridge.events(this,calendar.id);
                List<CalendarScheduleImport.Group> groups=CalendarScheduleImport.groups(events,java.time.ZoneId.systemDefault());
                runOnUiThread(()->{if(isFinishing()||isDestroyed())return;showCalendarSchedulePreview(calendar,groups);});
            }catch(Exception error){runOnUiThread(()->toast("No se pudieron leer eventos de esta cuenta."));}
        },"read-calendar-schedule").start();
    }
    void showCalendarSchedulePreview(CalendarBridge.CalendarInfo calendar,List<CalendarScheduleImport.Group> groups){
        if(groups.isEmpty()){
            dialogBuilder().setTitle("Sin clases importables").setMessage("No hay eventos con horas compatibles con clases semanales entre los eventos disponibles. Los eventos de día completo o demasiado largos se omiten. Revisa la sincronización de la cuenta.").setPositiveButton("Entendido",null).show();return;
        }
        boolean[] marked=new boolean[groups.size()];
        String[] labels=new String[groups.size()];
        for(int i=0;i<groups.size();i++){CalendarScheduleImport.Group group=groups.get(i);
            StringBuilder days=new StringBuilder();for(ScheduleEntry entry:group.sessions){if(days.length()>0)days.append(", ");days.append(ScheduleEntry.dayName(entry.day)).append(" ").append(ScheduleEntry.clock(entry.start));}
            labels[i]=group.name+" · "+group.sessions.size()+" día(s)\n"+days;
        }
        dialogBuilder().setTitle("Importar horario de "+calendar.name)
            .setMultiChoiceItems(labels,marked,(d,i,on)->marked[i]=on)
            .setNegativeButton("Cancelar",null)
            .setPositiveButton("Revisar importación",(d,w)->{
                ArrayList<ScheduleEntry> picked=new ArrayList<>();
                for(int i=0;i<marked.length;i++)if(marked[i])for(ScheduleEntry entry:groups.get(i).sessions)picked.add(entry.copy());
                if(picked.isEmpty()){toast("Selecciona al menos un curso.");return;}
                int existing=0;List<ScheduleEntry> saved=ScheduleDatabase.get(this).all();
                for(ScheduleEntry candidate:picked)for(ScheduleEntry old:saved){
                    if(old.day==candidate.day&&old.start==candidate.start&&old.end==candidate.end&&ScheduleCourseColors.same(old.course,candidate.course)){existing++;break;}}
                final int duplicates=existing;final int total=picked.size();
                dialogBuilder().setTitle("Confirmar horario importado")
                    .setMessage("Cuenta: "+calendar.account+"\nCalendario: "+calendar.name+"\nBloques propuestos: "+total+"\nPosibles duplicados: "+duplicates+".\n\nSe importarán como clases SEMANALES en Mi horario. Revisa los días, horas, y fecha de fin del semestre después de importarlos. No se editarán los eventos de Google Calendar.")
                    .setNegativeButton("Volver",null).setPositiveButton("Importar clases",(agree,which)->{
                        new Thread(()->{
                            ScheduleDatabase db=ScheduleDatabase.get(this);int count=db.importReviewed(picked);ScheduleReminders.rebuild(this);
                            runOnUiThread(()->toast(count+" clase(s) importadas a Mi horario. Revisa tu calendario."));
                        },"import-calendar-classes").start();
                    }).show();
            }).show();
    }
    void notificationsPermission(){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},31);
        else safeStart(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));
    }
    void safeStart(Intent i){try{startActivity(i);}catch(ActivityNotFoundException|SecurityException e){toast("Este ajuste no está disponible. Revísalo en Ajustes de Android.");}}
    interface Work{String run();}
    void background(Work work){toast("Procesando…");new Thread(()->{String result;try{result=work.run();}catch(Exception e){result="No se pudo completar la operación. Revisa los permisos y la cuenta del teléfono.";}final String value=result;runOnUiThread(()->{if(isFinishing())return;toast(value);render();});},"calendar-operation").start();}
    void chooseCalendar(){
        connectionTab=1;page=3;
        if(!CalendarBridge.allowed(this)){requestPermissions(new String[]{Manifest.permission.READ_CALENDAR,Manifest.permission.WRITE_CALENDAR},41);return;}render();
    }
    void pickEvents(){
        if(!CalendarBridge.allowed(this)){chooseCalendar();return;}
        if(Prefs.calendars(this).isEmpty()){toast("Selecciona al menos un calendario para consultar.");return;}
        new Thread(()->{
            try{List<CalendarBridge.Event> events=CalendarBridge.selectedEvents(this);runOnUiThread(()->{
                if(isFinishing())return;if(events.isEmpty()){toast("No hay eventos próximos en los calendarios elegidos.");return;}
                String[] labels=new String[events.size()];boolean[] selected=new boolean[events.size()];for(int j=0;j<labels.length;j++)labels[j]=events.get(j).toString();
                dialogBuilder().setTitle("Eventos para revisar").setMultiChoiceItems(labels,selected,(d,w,checked)->selected[w]=checked).setNegativeButton("Volver",null).setPositiveButton("Enviar a revisión",(d,w)->{
                    int count=0;for(int j=0;j<selected.length;j++)if(selected[j]){CalendarBridge.Event e=events.get(j);MessageParser.Proposal p=new MessageParser.Proposal();p.title=e.title;p.original=e.notes.isEmpty()?e.title:e.title+"\n"+e.notes;p.due=e.start;p.dateKnown=true;p.timeKnown=!e.allDay;p.reason=e.allDay?"Evento de día completo: elige la hora o fin del día.":"Confirma fecha y hora del evento antes de guardar.";
                        if(e.allDay)p.due=Instant.ofEpochMilli(e.start).atZone(ZoneOffset.UTC).toLocalDate().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
                        long id=Store.get(this).offerProposal(p,"Calendar · "+e.calendarName,System.currentTimeMillis(),"calendar:"+e.calendarId+":"+e.id+":"+e.start);if(id>0)count++;
                    }page=2;render();toast(count+" propuesta(s) nuevas para revisar.");
                }).show();
            });}catch(Exception e){runOnUiThread(()->toast("No se pudieron leer los eventos."));}
        },"calendar-events").start();
    }
    void pinWidget(Class<?> type){
        AppWidgetManager wm=AppWidgetManager.getInstance(this);
        if(Build.VERSION.SDK_INT>=26&&wm.isRequestPinAppWidgetSupported())wm.requestPinAppWidget(new ComponentName(this,type),null,null);
        else toast("Mantén pulsado el inicio → Widgets → Agenda Clara.");
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(request,permissions,grants);
        VoiceQuickTask.permissionResult(this,request,permissions,grants);
        if(request==32)safeStart(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        if(request==41&&CalendarBridge.allowed(this))chooseCalendar();else if(request==41)toast("Puedes usar las tareas sin conectar el calendario.");
        if(root!=null)render();
    }
    void shareTask(Task t){
        String msg=t.title+(t.due>0?"\n"+TaskLogic.when(t.due):"")+(t.notes.isEmpty()?"":"\n"+t.notes);
        dialogBuilder().setTitle("Compartir tarea").setItems(new String[]{"WhatsApp","WhatsApp Business","Otras aplicaciones"},(d,n)->{
            Intent i=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,msg);
            if(n<2)i.setPackage(n==0?"com.whatsapp":"com.whatsapp.w4b");
            try{startActivity(n<2?i:Intent.createChooser(i,"Compartir tarea"));}catch(ActivityNotFoundException e){toast("Esa aplicación no está instalada.");}
        }).show();
    }
    void openEditor(long taskId,Store.Inbox proposal,Bundle draft){
        if(editor!=null&&editor.isShowing())return;
        Task existing=taskId>0?Store.get(this).find(taskId):null;
        if(taskId>0&&existing==null){toast("Esta tarea ya no está disponible.");return;}
        Task t=existing!=null?existing:new Task();
        if(proposal!=null){t.title=proposal.title;t.source=proposal.source;t.originKey=proposal.key;t.due=proposal.due;}
        if(draft!=null){t.title=draft.getString("title","");t.notes=draft.getString("notes","");t.source=draft.getString("source","");t.originKey=draft.getString("origin","");}
        LinearLayout box=column();box.setPadding(dp(20),dp(16),dp(20),dp(32));ScrollView scroll=new WindowLayout.DialogScroll(this);scroll.setFocusableInTouchMode(true);scroll.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);scroll.addView(box);
        EditText title=input("Nombre de la tarea",t.title,android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);title.setSingleLine(false);title.setMaxLines(3);subtitle(box,"Nombre de la tarea");box.addView(title);
        EditText notes=input("Notas (opcional)",t.notes,android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);notes.setMinLines(2);
        if(proposal!=null){box.addView(text(proposal.reason,12,MUTED,false));TextView original=text(proposal.original,13,MUTED,false);original.setVisibility(View.GONE);box.addView(button("Ver mensaje original",()->original.setVisibility(original.getVisibility()==View.GONE?View.VISIBLE:View.GONE)));box.addView(original);}
        CheckBox schedule=new CheckBox(this);schedule.setButtonTintList(ColorStateList.valueOf(GREEN));schedule.setTextColor(INK);schedule.setText("Establecer fecha y hora límite");schedule.setMinHeight(dp(48));schedule.setChecked(t.due>0||existing==null);box.addView(schedule);
        ZonedDateTime def=ZonedDateTime.now().withHour(23).withMinute(59).withSecond(0).withNano(0);
        if(page==1&&existing==null&&proposal==null)def=selectedDay.atTime(def.toLocalTime()).atZone(ZoneId.systemDefault());
        if(t.due>0)def=Instant.ofEpochMilli(t.due).atZone(ZoneId.systemDefault());
        final LocalDate[] date={def.toLocalDate()};final LocalTime[] time={def.toLocalTime()};
        final boolean[] dateSet={proposal==null||proposal.dateKnown},timeSet={proposal==null||proposal.timeKnown};
        if(draft!=null){date[0]=LocalDate.parse(draft.getString("date",date[0].toString()));time[0]=LocalTime.parse(draft.getString("time",time[0].toString()));dateSet[0]=draft.getBoolean("date_set");timeSet[0]=draft.getBoolean("time_set");schedule.setChecked(draft.getBoolean("schedule"));}
        LinearLayout dateSection=card(box);
        LinearLayout dateHeading=row();dateHeading.addView(ModernGlyph.view(this,"date",ModernGlyph.BLUE,24),new LinearLayout.LayoutParams(dp(24),dp(24)));
        dateHeading.addView(text("  Fecha y hora de entrega",17,INK,true));
        dateSection.addView(dateHeading);gap(dateSection,10);
        TextView dateSummary=text("",16,INK,true);dateSummary.setTag("date_summary");dateSection.addView(dateSummary);gap(dateSection,6);
        Button dateBtn=button("Elegir fecha",()->{}),timeBtn=button("",()->{});timeBtn.setTag("choose_time");LinearLayout quick=row();dateSection.addView(quick);
        Button today=button("Hoy",()->{}),tomorrow=button("Mañana",()->{});
        for(Button b:new Button[]{today,tomorrow,dateBtn}){b.setMinWidth(0);b.setPadding(dp(5),0,dp(5),0);LinearLayout.LayoutParams quickParams=new LinearLayout.LayoutParams(0,dp(48),1);quickParams.setMargins(dp(4),0,dp(4),dp(4));b.setTextSize(UiPreferences.scaled(this,12));quick.addView(b,quickParams);}
        ModernGlyph.button(dateBtn,"date",ModernGlyph.BLUE,19);
        ModernGlyph.button(timeBtn,"time",ModernGlyph.VIOLET,20);
        timeBtn.setContentDescription("Elegir hora límite");
        dateSection.addView(timeBtn);
        Runnable refresh=()->{dateSummary.setText(dateSet[0]?date[0].format(DateTimeFormatter.ofPattern("EEEE d MMM yyyy",new Locale("es","PE"))):"Elige un día");dateSection.setVisibility(schedule.isChecked()?View.VISIBLE:View.GONE);timeBtn.setText(timeSet[0]?"Hora límite · "+time[0].format(DateTimeFormatter.ofPattern("h:mm a",new Locale("es","PE"))):"Elegir hora · reloj de 12 h");dateBtn.setEnabled(schedule.isChecked());timeBtn.setEnabled(schedule.isChecked());};
        today.setOnClickListener(v->{date[0]=LocalDate.now();dateSet[0]=true;refresh.run();});tomorrow.setOnClickListener(v->{date[0]=LocalDate.now().plusDays(1);dateSet[0]=true;refresh.run();});
        dateBtn.setOnClickListener(v->{ModernPickers.showDate(this,date[0],chosenDate->{date[0]=chosenDate;dateSet[0]=true;refresh.run();});});
        timeBtn.setOnClickListener(v->{ModernPickers.showTime(this,time[0],chosenTime->{time[0]=chosenTime;timeSet[0]=true;refresh.run();});});
        dateSection.addView(text("La prioridad se calcula automáticamente según el tiempo restante.",12,MUTED,false));
        schedule.setOnCheckedChangeListener((v,checked)->refresh.run());refresh.run();
        String currentCategory=draft!=null?draft.getString("category",t.category):t.category;
        LinearLayout categoryHeading=row();ImageView categoryHeadingIcon=ApprovedPng.view(this,CategoryRegistry.icon(this,currentCategory),26);
        LinearLayout.LayoutParams categoryHeadingSpace=new LinearLayout.LayoutParams(dp(30),dp(30));
        categoryHeadingSpace.rightMargin=dp(10);
        categoryHeading.addView(categoryHeadingIcon,categoryHeadingSpace);
        categoryHeading.addView(text("  Categoría",17,INK,true));gap(box,12);box.addView(categoryHeading);gap(box,8);
        Spinner categoryPicker=new Spinner(this);
        ArrayAdapter<String> categoriesAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new ArrayList<String>(java.util.Arrays.asList(CategoryRegistry.names(this))));
        categoryPicker.setAdapter(categoriesAdapter);
        for(int i=0;i<categoriesAdapter.getCount();i++)if(categoriesAdapter.getItem(i).equalsIgnoreCase(TaskOrganization.category(currentCategory)))categoryPicker.setSelection(i);
        categoryPicker.setBackground(UiDesign.tintedBackground(this,CategoryRegistry.color(this,currentCategory),15,18));
        categoryPicker.setPadding(dp(12),dp(8),dp(10),dp(8));
        categoryPicker.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> parent,View view,int position,long id){
                String category=String.valueOf(categoryPicker.getSelectedItem());
                categoryPicker.setBackground(UiDesign.tintedBackground(MainActivity.this,
                    CategoryRegistry.color(MainActivity.this,category),15,18));
                if(view instanceof TextView)UiDesign.text((TextView)view,true);
            }
            public void onNothingSelected(AdapterView<?> parent){}
        });
        box.addView(categoryPicker,new LinearLayout.LayoutParams(dp(1),dp(1)));
        categoryPicker.setVisibility(View.GONE);
        Button categoryDisplay=button(TaskOrganization.category(currentCategory)+"  ›",()->{});
        categoryDisplay.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        categoryDisplay.setContentDescription("Seleccionar categoría: "+TaskOrganization.category(currentCategory));
        categoryDisplay.setMinHeight(dp(58));
        categoryDisplay.setBackground(UiDesign.tintedBackground(this,
            CategoryRegistry.color(this,currentCategory),16,18));
        ApprovedPng.button(categoryDisplay,CategoryRegistry.icon(this,currentCategory),24);
        categoryDisplay.setOnClickListener(v->ModernPickers.showCategory(this,
            String.valueOf(categoryPicker.getSelectedItem()),selected->{
                for(int i=0;i<categoriesAdapter.getCount();i++)
                    if(selected.equalsIgnoreCase(categoriesAdapter.getItem(i)))categoryPicker.setSelection(i);
                categoryDisplay.setText(selected+"  ›");
                categoryDisplay.setContentDescription("Seleccionar categoría: "+selected);
                categoryDisplay.setBackground(UiDesign.tintedBackground(this,
                    CategoryRegistry.color(this,selected),16,18));
                ApprovedPng.button(categoryDisplay,CategoryRegistry.icon(this,selected),24);
                categoryHeadingIcon.setImageDrawable(ApprovedPng.drawable(this,CategoryRegistry.icon(this,selected)));
            }));
        box.addView(categoryDisplay,new LinearLayout.LayoutParams(-1,dp(60)));gap(box,9);
        box.addView(button("＋  Crear nueva categoría",()->showCategoryEditor(null,newName->{
            categoriesAdapter.clear();categoriesAdapter.addAll(CategoryRegistry.names(this));
            categoriesAdapter.notifyDataSetChanged();
            for(int i=0;i<categoriesAdapter.getCount();i++)
                if(categoriesAdapter.getItem(i).equalsIgnoreCase(newName))categoryPicker.setSelection(i);
            categoryDisplay.setText(newName+"  ›");
            categoryDisplay.setContentDescription("Seleccionar categoría: "+newName);
            categoryDisplay.setBackground(UiDesign.tintedBackground(this,
                CategoryRegistry.color(this,newName),16,18));
            ApprovedPng.button(categoryDisplay,CategoryRegistry.icon(this,newName),24);
            categoryHeadingIcon.setImageDrawable(ApprovedPng.drawable(this,CategoryRegistry.icon(this,newName)));
        })));
        CheckBox urgent=new CheckBox(this);urgent.setText("Marcar urgente manualmente");urgent.setMinHeight(dp(48));urgent.setChecked(draft!=null?draft.getBoolean("urgent"):t.urgent);
        CheckBox done=new CheckBox(this);done.setText("Tarea completada");done.setMinHeight(dp(48));done.setChecked(draft!=null?draft.getBoolean("done"):t.done);
        LinearLayout remindersHeader=row();remindersHeader.addView(ModernGlyph.view(this,"bell",ModernGlyph.AMBER,24),new LinearLayout.LayoutParams(dp(24),dp(24)));
        remindersHeader.addView(text("  Avisarme antes",17,INK,true));gap(box,12);box.addView(remindersHeader);gap(box,8);
        final SortedSet<Integer> offsets=new TreeSet<>(Collections.reverseOrder());offsets.addAll(TaskLogic.offsets(draft!=null?draft.getString("offsets",t.offsets):t.offsets));
        LinearLayout chosen=column();box.addView(chosen);
        Button reminderButton=button("",()->{});box.addView(reminderButton);
        Runnable redraw=()->{List<String> labels=new ArrayList<>();for(int n:offsets)labels.add(TaskLogic.offsetName(n));reminderButton.setText(labels.isEmpty()?"Sin recordatorios · cambiar":android.text.TextUtils.join(" · ",labels)+" · cambiar");};redraw.run();
        reminderButton.setOnClickListener(v->{
            int[] values={0,15,30,60,180,720,1440,2880,4320,10080,20160,43200};String[] labels=new String[values.length];boolean[] selected=new boolean[values.length];SortedSet<Integer> pending=new TreeSet<>(offsets);
            for(int j=0;j<values.length;j++){labels[j]=TaskLogic.offsetName(values[j]);selected[j]=pending.contains(values[j]);}
            dialogBuilder().setTitle("¿Cuándo te aviso?").setMultiChoiceItems(labels,selected,(d,w,on)->{if(on)pending.add(values[w]);else pending.remove(values[w]);}).setNegativeButton("Volver",null).setPositiveButton("Listo",(d,w)->{offsets.clear();offsets.addAll(pending);redraw.run();})
            .setNeutralButton("Personalizar",(d,w)->{
                LinearLayout wrap=column();wrap.setPadding(dp(18),0,dp(18),0);EditText amount=input("Cantidad","3",android.text.InputType.TYPE_CLASS_NUMBER);wrap.addView(amount);Spinner unit=new Spinner(this);unit.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Minutos","Horas","Días","Semanas"}));unit.setSelection(2);wrap.addView(unit);
                AlertDialog custom=dialogBuilder().setTitle("Aviso personalizado").setView(wrap).setNegativeButton("Volver",null).setPositiveButton("Añadir",null).create();custom.setOnShowListener(a->custom.getButton(-1).setOnClickListener(b->{try{long n=Long.parseLong(amount.getText().toString())*new int[]{1,60,1440,10080}[unit.getSelectedItemPosition()];if(n<0||n>5256000)throw new NumberFormatException();offsets.add((int)n);redraw.run();custom.dismiss();}catch(NumberFormatException e){amount.setError("Usa una anticipación de hasta 10 años.");}}));custom.show();
            }).show();
        });
        LinearLayout advanced=column();advanced.setVisibility(View.GONE);
        box.addView(button("Más opciones · notas y repetición del aviso  ›",()->{
          boolean visible=advanced.getVisibility()!=View.VISIBLE;
          advanced.setVisibility(visible?View.VISIBLE:View.GONE);
          if(visible)UiMotion.reveal(advanced);
        }));gap(box,10);box.addView(advanced);
        advanced.addView(notes);if(existing!=null)advanced.addView(done);
        subtitle(advanced,"Repetir el aviso");
        int rv=draft!=null?draft.getInt("repeat"):t.repeatMinutes;
        final int[] repeatMinutes={rv};
        Button repeatButton=button(ModernRepeat.title(rv)+"  ›",()->{});
        ApprovedPng.button(repeatButton,"repeat",22);
        repeatButton.setOnClickListener(v->ModernRepeat.show(this,repeatMinutes[0],chosenValue->{
            repeatMinutes[0]=chosenValue;
            repeatButton.setText(ModernRepeat.title(chosenValue)+"  ›");
        }));
        advanced.addView(repeatButton);
        advanced.addView(text("Desde la mayor anticipación seleccionada hasta el vencimiento. Completar la tarea detiene los avisos.",12,MUTED,false));
        CheckBox google=new CheckBox(this);google.setMinHeight(dp(48));google.setText("Vincular al calendario elegido");boolean available=CalendarBridge.allowed(this)&&Prefs.calendar(this)>0;google.setEnabled(available);google.setChecked(available&&(draft!=null?draft.getBoolean("google"):t.calendarEnabled));gap(box,16);box.addView(google);
        if(!available)box.addView(text("Elige tu calendario en Conexiones para activar esta opción.",12,MUTED,false));
        editor=dialogBuilder().setTitle(existing==null?"Nueva tarea":"Editar tarea").setView(scroll).setNegativeButton("Volver",null).setPositiveButton("Guardar",null).create();
        if(existing!=null)editor.setButton(DialogInterface.BUTTON_NEUTRAL,"Borrar",(DialogInterface.OnClickListener)null);
        final long inboxId=proposal!=null?proposal.id:draft!=null?draft.getLong("inbox_id",-1):-1;
        captureDraft=()->{
            Bundle b=new Bundle();b.putLong("task_id",t.id);b.putLong("inbox_id",inboxId);b.putString("title",title.getText().toString());b.putString("notes",notes.getText().toString());b.putString("source",t.source);b.putString("origin",t.originKey);b.putString("category",String.valueOf(categoryPicker.getSelectedItem()));b.putBoolean("schedule",schedule.isChecked());b.putBoolean("date_set",dateSet[0]);b.putBoolean("time_set",timeSet[0]);b.putString("date",date[0].toString());b.putString("time",time[0].toString());b.putBoolean("urgent",false);b.putBoolean("done",done.isChecked());b.putString("offsets",join(offsets));b.putInt("repeat",repeatMinutes[0]);b.putBoolean("google",google.isChecked());restoreDraft=b;
        };
        editor.setOnDismissListener(d->{captureDraft=null;restoreDraft=null;editor=null;});
        editor.setOnShowListener(d->{
            editor.getButton(-1).setTag("task_save");editor.getButton(-2).setTag("task_cancel");title.setTag("task_title");
            if(existing!=null)editor.getButton(-3).setOnClickListener(v->dialogBuilder().setTitle("Borrar tarea").setMessage("La tarea y sus subtareas irán a la papelera durante 7 días. Los avisos se cancelarán; el evento de calendario existente se conservará.").setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(confirm,w)->{Reminders.cancel(this,t.id);Store.get(this).delete(t.id);TaskWidget.refresh(this);editor.dismiss();toast("Tarea enviada a papelera. Puedes restaurarla desde Conexiones.");render();}).show());
            editor.getButton(-1).setOnClickListener(v->{
                String value=title.getText().toString().trim();if(value.isEmpty()){title.setError("Escribe un nombre.");return;}
                if(schedule.isChecked()&&(!dateSet[0]||!timeSet[0])){toast("Elige la fecha y la hora, o desactiva la programación.");return;}
                t.title=value;t.category=String.valueOf(categoryPicker.getSelectedItem());t.notes=notes.getText().toString().trim();t.due=schedule.isChecked()?date[0].atTime(time[0]).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli():0;t.urgent=false;t.done=done.isChecked();t.offsets=join(offsets);t.repeatMinutes=repeatMinutes[0];t.calendarEnabled=google.isChecked()&&schedule.isChecked();
                if(t.calendarEnabled&&t.calendarId<0)t.calendarId=Prefs.calendar(this);
                try{if(inboxId>0){if(!Store.get(this).acceptProposal(t,inboxId)){toast("Esta propuesta ya fue atendida.");return;}}else Store.get(this).save(t);}catch(android.database.sqlite.SQLiteConstraintException e){toast("Esta propuesta ya fue convertida en tarea.");return;}
                if(inboxId>0)Reminders.cancelProposal(this,inboxId);if(t.done)Reminders.cancel(this,t.id);else Reminders.schedule(this,t);TaskWidget.refresh(this);editor.dismiss();render();
                if(t.calendarEnabled)background(()->{String result=CalendarBridge.upsert(this,t);return result.isEmpty()?"Tarea guardada y evento escrito en el calendario del teléfono.":result;});
                else toast(t.due>0&&t.due<System.currentTimeMillis()?"Tarea guardada con fecha vencida.":"Tarea guardada.");
            });
        });editor.show();scroll.requestFocus();scroll.post(()->scroll.scrollTo(0,0));editor.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }
    void showCategories(){
        LinearLayout pane=column();pane.setPadding(dp(16),dp(12),dp(16),dp(20));
        pane.addView(text("General es la única categoría predefinida.",13,MUTED,false));gap(pane,12);
        pane.addView(primaryButton("＋  Crear categoría",()->{
            for(AlertDialog d:new ArrayList<>(dialogs))if(d.isShowing())d.dismiss();
            handler.post(()->showCategoryEditor(null,name->showCategories()));
        }));gap(pane,14);
        for(CategoryRegistry.Entry entry:CategoryRegistry.all(this)){
            LinearLayout card=card(pane);LinearLayout row=row();
            ImageView categoryIcon=ApprovedPng.view(this,entry.icon,28);
            LinearLayout.LayoutParams iconSpace=new LinearLayout.LayoutParams(dp(32),dp(32));
            iconSpace.rightMargin=dp(12);
            row.addView(categoryIcon,iconSpace);
            int count=0;for(Task task:Store.get(this).all())if(entry.name.equalsIgnoreCase(TaskOrganization.category(task.category)))count++;
            LinearLayout categoryInfo=column();categoryInfo.addView(text(entry.name,16,UiDesign.accentInk(entry.color),true));
            categoryInfo.addView(text(count+(count==1?" tarea":" tareas"),13,INK,false));
            TextView name=text("  ",1,INK,false);
            row.addView(categoryInfo,new LinearLayout.LayoutParams(0,-2,1));
            if(!"General".equalsIgnoreCase(entry.name)){
                row.addView(button("Editar",()->{for(AlertDialog d:new ArrayList<>(dialogs))if(d.isShowing())d.dismiss();handler.post(()->showCategoryEditor(entry.name,edited->showCategories()));}));
                row.addView(button("×",()->dialogBuilder().setTitle("Eliminar "+entry.name)
                    .setMessage("Las tareas de esta categoría pasarán a General. Ninguna tarea será eliminada.")
                    .setNegativeButton("Cancelar",null)
                    .setPositiveButton("Eliminar",(dialog,which)->{
                        if(CategoryRegistry.delete(this,entry.name)){
                            if(selectedCategory.equalsIgnoreCase(entry.name))selectedCategory="General";
                            for(AlertDialog open:new ArrayList<>(dialogs))if(open.isShowing())open.dismiss();
                            render();handler.post(this::showCategories);
                        }
                    }).show()));
            }else row.addView(text("  Fija",12,MUTED,false));
            card.addView(row);
            card.setBackground(UiDesign.tintedBackground(this,entry.color,19,17));
        }
        ScrollView scroll=new WindowLayout.DialogScroll(this);scroll.addView(pane);
        dialogBuilder().setTitle("Gestión de categorías").setView(scroll).setPositiveButton("Listo",null).show();
    }
    void showCategoryEditor(String existing,java.util.function.Consumer<String> onSaved){
        CategorySymbolChooser.show(this,existing,name->{
            if(existing!=null&&selectedCategory.equalsIgnoreCase(existing))selectedCategory=name;
            render();
            if(onSaved!=null)onSaved.accept(name);
        });
    }
    String join(Collection<Integer> offsets){StringBuilder b=new StringBuilder();for(int n:offsets){if(b.length()>0)b.append(',');b.append(n);}return b.toString();}
}
