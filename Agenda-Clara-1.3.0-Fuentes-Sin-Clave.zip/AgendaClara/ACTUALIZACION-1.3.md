# Agenda Clara 1.3.0 — proyecto fuente actualizado

Este proyecto es una modificación del **código fuente existente de Agenda Clara 1.2.1**, no una aplicación nueva. Mantiene `applicationId pe.agendaclara.app`, la integración nativa de WhatsApp, las notificaciones, Calendar, los widgets, el editor de tareas y la revisión manual de propuestas.

## Rediseño de productividad

- Pantalla **Mi agenda**: encabezado azul, tarjetas blancas, estadísticas de pendientes, urgentes y completadas, progreso porcentual, chips de filtrado y acciones compactas.
- **Calendario**: selección de fecha en azul, superficies suaves, actividades y botones conservados.
- **Por revisar**: resumen destacado, accesos a Mis grupos/Pegar texto, estado vacío renovado, tarjetas con propuesta aceptable/descartable y elementos informativos.
- **Conexiones**: nueva paleta, grupos autorizados destacados, accesos compactos a historial, selección del número de mensajes anteriores e importación de `.txt`.
- Navegación inferior e interfaces de diálogo adoptan la misma paleta.

## Eliminación de tareas completadas tras una hora

- Base SQLite pasa de la versión **3 a 4**; agrega `tasks.completed_at` (epoch ms).
- Cuando la tarea pasa a completada se almacena el momento exacto de finalización. Editarla mientras sigue completada **no reinicia** el temporizador.
- Tras `60 × 60 × 1000` ms, la tarea se borra del almacenamiento local y deja de mostrarse en Agenda, Calendario y widget. No se borran eventos de Google Calendar ajenos al registro local.
- Si se vuelve a marcar como pendiente antes de cumplirse el plazo, su `completed_at` pasa a cero.
- El receptor `CompletedTaskReceiver` programa el siguiente vencimiento mediante `AlarmManager`, con alternativa para dispositivos que no otorgan alarmas exactas. En ese caso Android puede retrasar la limpieza; también se aplica al abrir la app, al consultar tareas y al recuperar el dispositivo tras reinicio.
- Para completadas existentes en la instalación anterior sin fecha de cierre, la migración inicia una ventana de una hora a partir de la actualización (no inventa un momento de cierre pasado).

## Compilar una APK

Necesitas Android SDK API 35 y JDK 17. La forma recomendada es abrir esta carpeta con Android Studio y ejecutar `Build > Build APK(s)`, o lanzar `./gradlew :app:assembleDebug` en un equipo con SDK configurado. El APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

También se incluye `.github/workflows/build-agenda-clara-1_3.yml` para compilar en GitHub Actions; la APK verificable se descargará como artefacto del flujo **solo si termina correctamente**.

**Firma:** se conserva `signing/development.jks` del proyecto original. La huella SHA-256 del certificado del respaldo es `9232f9e8bc93197d2d402800d11a6c1027b6f2f42210c4f12ea237420df96eb3`. Esta clave es **de desarrollo** y se distribuyó en el proyecto anterior.

**Precaución:** instala una APK de actualización con el mismo certificado y un `versionCode` superior. No desinstales la aplicación anterior si quieres conservar sus tareas y conexiones locales. Haz una copia de seguridad antes de probar cambios no certificados.

## Estado de verificación en este entorno

- **Revisado:** fuentes, esquema SQLite, certificado de la clave de desarrollo.
- **Pruebas JVM:** CoreTests (65/65), ConversationTests (76/76) sobre datos sintéticos.
- **No verificado:** compilación Android 1.3.0, firma del nuevo APK, instalación y prueba en un Android físico/emulador; este entorno carece del SDK y las herramientas Android. No se adjunta un APK disfrazado de compilación nueva.
