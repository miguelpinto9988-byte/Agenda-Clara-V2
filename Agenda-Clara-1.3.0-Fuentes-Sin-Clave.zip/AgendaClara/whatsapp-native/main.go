// Agenda Clara linked-device transport. It exposes no chat-send or member-management API.
package main

/*
#include <stdlib.h>
*/
import "C"

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	_ "github.com/mattn/go-sqlite3"
	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/proto/waHistorySync"
	"go.mau.fi/whatsmeow/store"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
	"google.golang.org/protobuf/proto"
)

type object = map[string]any
type request struct {
	Op       string   `json:"op"`
	Path     string   `json:"path"`
	Phone    string   `json:"phone"`
	JID      string   `json:"jid"`
	Selected []string `json:"selected"`
	Days     int      `json:"days"`
	Count    int      `json:"count"`
	Enabled  bool     `json:"enabled"`
}
type group struct {
	JID       string `json:"jid"`
	Name      string `json:"name"`
	Parent    string `json:"parent"`
	Community bool   `json:"community"`
	Joined    bool   `json:"joined"`
}
type transport struct {
	mu            sync.Mutex
	operations    sync.Mutex
	historyLock   sync.Mutex
	client        *whatsmeow.Client
	container     *sqlstore.Container
	dir           string
	selected      map[string]bool
	enabled       bool
	unlinked      bool
	days          int
	notifications []*waE2E.HistorySyncNotification
	processed     map[string]map[string]bool
	anchors       map[string]*types.MessageInfo
	queue         chan object
	stop          chan struct{}
}

var bridge = &transport{selected: map[string]bool{}, anchors: map[string]*types.MessageInfo{}, processed: map[string]map[string]bool{}, queue: make(chan object, 512), days: 30}

func main()                      {}
func marshaled(v any) string     { b, _ := json.Marshal(v); return string(b) }
func fail(message string) object { return object{"ok": false, "error": message} }
func (t *transport) emit(v object) {
	t.mu.Lock()
	stop := t.stop
	t.mu.Unlock()
	if stop == nil {
		select {
		case t.queue <- v:
		default:
		}
		return
	}
	select {
	case <-stop:
		return
	default:
	}
	select {
	case t.queue <- v:
	case <-stop:
	}
}
func (t *transport) allowed(jid string) bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.enabled && t.selected[jid]
}
func (t *transport) saveNotifications() {
	t.mu.Lock()
	defer t.mu.Unlock()
	var data [][]byte
	for _, n := range t.notifications {
		if len(n.GetInitialHistBootstrapInlinePayload()) > 0 {
			continue
		} // inline data is message content, not an encrypted pointer
		if b, e := proto.Marshal(n); e == nil {
			data = append(data, b)
		}
	}
	b, _ := json.Marshal(data)
	tmp := filepath.Join(t.dir, "history-pointers.tmp")
	if os.WriteFile(tmp, b, 0600) == nil {
		_ = os.Rename(tmp, filepath.Join(t.dir, "history-pointers.json"))
	}
}
func (t *transport) init(dir string) error {
	if !filepath.IsAbs(dir) {
		return errors.New("Ruta privada no válida")
	}
	if t.client != nil {
		return nil
	}
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	store.SetOSInfo("Agenda Clara", [3]uint32{1, 2, 0})
	store.DeviceProps.RequireFullSync = proto.Bool(true)
	store.DeviceProps.HistorySyncConfig.FullSyncDaysLimit = proto.Uint32(365)
	store.DeviceProps.HistorySyncConfig.FullSyncSizeMbLimit = proto.Uint32(64)
	store.DeviceProps.HistorySyncConfig.StorageQuotaMb = proto.Uint32(128)
	store.DeviceProps.HistorySyncConfig.SupportCallLogHistory = proto.Bool(false)
	store.DeviceProps.HistorySyncConfig.OnDemandReady = proto.Bool(true)
	c, err := sqlstore.New(context.Background(), "sqlite3", "file:"+filepath.Join(dir, "session.db")+"?_foreign_keys=on&_busy_timeout=5000&_journal_mode=WAL", waLog.Noop)
	if err != nil {
		return err
	}
	device, err := c.GetFirstDevice(context.Background())
	if err != nil {
		_ = c.Close()
		return err
	}
	cli := whatsmeow.NewClient(device, waLog.Noop)
	// History is downloaded explicitly after the user authorizes interpretation.
	cli.ManualHistorySyncDownload = true
	t.mu.Lock()
	t.dir = dir
	t.unlinked = false
	t.client = cli
	t.container = c
	t.stop = make(chan struct{})
	t.mu.Unlock()
	var saved [][]byte
	if b, e := os.ReadFile(filepath.Join(dir, "history-pointers.json")); e == nil && len(b) <= 4*1024*1024 {
		if json.Unmarshal(b, &saved) == nil {
			for _, b := range saved {
				var n waE2E.HistorySyncNotification
				if proto.Unmarshal(b, &n) == nil {
					t.notifications = append(t.notifications, &n)
				}
			}
		}
	}
	cli.AddEventHandler(func(e any) {
		t.mu.Lock()
		active := t.client == cli
		t.mu.Unlock()
		if active {
			t.event(e)
		}
	})
	return nil
}
func (t *transport) connect(phone string) error {
	cli := t.client
	if cli == nil {
		return errors.New("Primero inicializa la conexión")
	}
	if cli.IsConnected() {
		return nil
	}
	if cli.Store.ID != nil {
		return cli.Connect()
	}
	if len(phone) < 8 || len(phone) > 15 || strings.Trim(phone, "0123456789") != "" {
		return errors.New("Escribe tu número con código de país, solo dígitos")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 170*time.Second)
	qr, err := cli.GetQRChannel(ctx)
	if err != nil {
		cancel()
		return err
	}
	if err = cli.Connect(); err != nil {
		cancel()
		return err
	}
	go func() {
		defer cancel()
		paired := false
		for item := range qr {
			if item.Event == "code" && !paired {
				paired = true
				code, e := cli.PairPhone(ctx, phone, false, whatsmeow.PairClientChrome, "Chrome (Linux)")
				if e != nil {
					t.emit(object{"type": "error", "message": "No se pudo obtener el código de vinculación. Vuelve a intentarlo."})
					return
				}
				t.emit(object{"type": "pair_code", "code": code, "expires": time.Now().Add(140 * time.Second).UnixMilli()})
			} else if item.Event == "timeout" {
				t.emit(object{"type": "error", "message": "El código caducó. Solicita otro código."})
			}
		}
	}()
	return nil
}
func (t *transport) event(raw any) {
	switch e := raw.(type) {
	case *events.Connected:
		t.emit(object{"type": "connected"})
		go t.groups()
	case *events.Disconnected:
		t.emit(object{"type": "disconnected"})
	case *events.LoggedOut:
		t.mu.Lock()
		t.unlinked = true
		t.enabled = false
		t.selected = map[string]bool{}
		t.mu.Unlock()
		t.emit(object{"type": "logged_out", "message": "WhatsApp cerró esta sesión. Puedes volver a vincularla."})
	case *events.ConnectFailure:
		t.emit(object{"type": "error", "message": "WhatsApp rechazó la conexión. Revisa tus dispositivos vinculados."})
	case *events.TemporaryBan:
		t.emit(object{"type": "error", "message": "WhatsApp informó de una restricción temporal. Desconecta esta integración."})
	case *events.PairError:
		t.emit(object{"type": "error", "message": "No se completó la vinculación. Revisa WhatsApp y vuelve a intentarlo."})
	case *events.Message:
		if notif := e.Message.GetProtocolMessage().GetHistorySyncNotification(); notif != nil {
			t.mu.Lock()
			t.notifications = append(t.notifications, proto.Clone(notif).(*waE2E.HistorySyncNotification))
			if len(t.notifications) > 48 {
				t.notifications = t.notifications[len(t.notifications)-48:]
			}
			hasConsent := t.enabled && len(t.selected) > 0
			t.mu.Unlock()
			t.saveNotifications()
			if hasConsent {
				go t.history("")
			}
			return
		}
		if t.allowed(e.Info.Chat.String()) {
			t.deliver(e, false)
		}
	case *events.HistorySync:
		if e.Data != nil {
			t.processHistory(e.Data, "", nil)
		}
	}
}
func (t *transport) groups() {
	cli := t.client
	if cli == nil || !cli.IsLoggedIn() {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	all, err := cli.GetJoinedGroups(ctx)
	if err != nil {
		t.emit(object{"type": "error", "message": "No se pudo obtener la lista de grupos. Comprueba la conexión y pulsa Actualizar."})
		return
	}
	result := map[string]group{}
	for _, g := range all {
		result[g.JID.String()] = group{g.JID.String(), g.Name, g.LinkedParentJID.String(), g.IsParent, true}
	}
	// Subgroup metadata is shown even when no new messages have arrived.
	for _, g := range all {
		if g.IsParent {
			sub, err := cli.GetSubGroups(ctx, g.JID)
			if err != nil {
				continue
			}
			for _, s := range sub {
				if _, ok := result[s.JID.String()]; !ok {
					result[s.JID.String()] = group{s.JID.String(), s.Name, g.JID.String(), false, false}
				}
			}
		}
	}
	list := make([]group, 0, len(result))
	for _, g := range result {
		if g.Parent == "0@" || g.Parent == "@" {
			g.Parent = ""
		}
		list = append(list, g)
	}
	sort.Slice(list, func(i, j int) bool {
		if list[i].Community != list[j].Community {
			return list[i].Community
		}
		return strings.ToLower(list[i].Name) < strings.ToLower(list[j].Name)
	})
	t.emit(object{"type": "groups", "groups": list, "updated": time.Now().UnixMilli()})
}
func (t *transport) deliver(e *events.Message, historical bool) {
	jid := e.Info.Chat.String()
	if !t.allowed(jid) || e.IsViewOnce || e.IsViewOnceV2 || e.IsViewOnceV2Extension {
		return
	}
	m := e.Message
	text := m.GetConversation()
	quoted := ""
	replyID := ""
	if x := m.GetExtendedTextMessage(); x != nil {
		text = x.GetText()
		quoted = x.GetContextInfo().GetQuotedMessage().GetConversation()
		if quoted == "" {
			quoted = x.GetContextInfo().GetQuotedMessage().GetExtendedTextMessage().GetText()
		}
		replyID = x.GetContextInfo().GetStanzaID()
	}
	// Text captions are eligible. Media bodies, audio, documents and view-once media are not downloaded.
	if text == "" {
		text = m.GetImageMessage().GetCaption()
	}
	if text == "" {
		text = m.GetDocumentMessage().GetCaption()
	}
	if text == "" {
		text = m.GetVideoMessage().GetCaption()
	}
	if strings.TrimSpace(text) == "" {
		return
	}
	if len(text) > 16000 {
		text = text[:16000]
	}
	if len(quoted) > 4000 {
		quoted = quoted[:4000]
	}
	t.emit(object{"type": "message", "jid": jid, "id": e.Info.ID, "text": text, "sender": e.Info.Sender.String(), "name": e.Info.PushName, "timestamp": e.Info.Timestamp.UnixMilli(), "historical": historical, "quoted": quoted, "reply_id": replyID, "edited": e.IsEdit, "from_me": e.Info.IsFromMe})
}
func (t *transport) processHistory(h *waHistorySync.HistorySync, only string, scope map[string]bool) int {
	t.mu.Lock()
	cli := t.client
	t.mu.Unlock()
	if cli == nil {
		return 0
	}
	count := 0
	t.mu.Lock()
	days := t.days
	t.mu.Unlock()
	cutoff := time.Now().Add(-time.Duration(days) * 24 * time.Hour)
	for _, conv := range h.GetConversations() {
		jid, err := types.ParseJID(conv.GetID())
		if err != nil {
			continue
		}
		id := jid.String()
		// This check occurs BEFORE parsing or extracting any conversation text.
		if (only != "" && only != id) || (scope != nil && !scope[id]) || !t.allowed(id) {
			continue
		}
		msgs := conv.GetMessages()
		sort.SliceStable(msgs, func(i, j int) bool {
			return msgs[i].GetMessage().GetMessageTimestamp() < msgs[j].GetMessage().GetMessageTimestamp()
		})
		for _, wm := range msgs {
			e, err := cli.ParseWebMessage(jid, wm.GetMessage())
			if err != nil {
				continue
			}
			t.mu.Lock()
			a := t.anchors[id]
			if a == nil || e.Info.Timestamp.Before(a.Timestamp) {
				copy := e.Info
				t.anchors[id] = &copy
			}
			t.mu.Unlock()
			if e.Info.Timestamp.Before(cutoff) {
				continue
			}
			t.deliver(e, true)
			count++
		}
	}
	return count
}
func (t *transport) history(only string) {
	t.historyLock.Lock()
	defer t.historyLock.Unlock()
	if only != "" && !t.allowed(only) {
		return
	}
	t.mu.Lock()
	ns := append([]*waE2E.HistorySyncNotification(nil), t.notifications...)
	t.mu.Unlock()
	// A queued duplicate job does not re-run the Java history analysis.
	if len(ns) > 0 {
		pending := false
		t.mu.Lock()
		for _, n := range ns {
			encoded, _ := proto.Marshal(n)
			fingerprint := fmt.Sprintf("%x", sha256.Sum256(encoded))
			for id, yes := range t.selected {
				if yes && t.enabled && (only == "" || only == id) && !t.processed[fingerprint][fmt.Sprintf("%s:%d", id, t.days)] {
					pending = true
					break
				}
			}
			if pending {
				break
			}
		}
		t.mu.Unlock()
		if !pending {
			return
		}
	}
	t.emit(object{"type": "history_start", "jid": only})
	count := 0
	failed := 0
	for _, n := range ns {
		encoded, _ := proto.Marshal(n)
		fingerprint := fmt.Sprintf("%x", sha256.Sum256(encoded))
		needed := map[string]bool{}
		t.mu.Lock()
		for id, yes := range t.selected {
			if yes && t.enabled && (only == "" || only == id) {
				cacheKey := fmt.Sprintf("%s:%d", id, t.days)
				if !t.processed[fingerprint][cacheKey] {
					needed[id] = true
				}
			}
		}
		cli := t.client
		t.mu.Unlock()
		if len(needed) == 0 || cli == nil {
			continue
		}
		ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
		h, err := cli.DownloadHistorySync(ctx, n, true)
		cancel()
		if err != nil {
			failed++
			continue
		}
		// The linked-device protocol transfers account-wide encrypted batches. We discard
		// nonselected conversation bodies before the task parser or app message storage.
		count += t.processHistory(h, only, needed)
		t.mu.Lock()
		if t.processed[fingerprint] == nil {
			t.processed[fingerprint] = map[string]bool{}
		}
		for id := range needed {
			if t.selected[id] {
				t.processed[fingerprint][fmt.Sprintf("%s:%d", id, t.days)] = true
			}
		}
		t.mu.Unlock()
	}
	t.emit(object{"type": "history_done", "jid": only, "messages": count, "failed_chunks": failed, "has_pointers": len(ns) > 0})
}
func (t *transport) moreRequest(jid string, count int) (*waE2E.Message, error) {
    if count == 0 { count = 50 }
    if count < 10 || count > 50 || count%10 != 0 { return nil, errors.New("Elige 10, 20, 30, 40 o 50 mensajes anteriores") }
    if !t.allowed(jid) { return nil, errors.New("Este grupo no tiene autorización de lectura") }
    t.mu.Lock(); a:=t.anchors[jid]; t.mu.Unlock()
    if a==nil { return nil,errors.New("Todavía no hay un mensaje de referencia. Revisa primero el historial sincronizado") }
    if t.client==nil { return nil,errors.New("Reanuda primero la conexión de WhatsApp") }
    return t.client.BuildHistorySyncRequest(a, count), nil
}
func (t *transport) more(jid string, count int) error {
    message,err:=t.moreRequest(jid,count);if err!=nil{return err}
    ctx,cancel:=context.WithTimeout(context.Background(),30*time.Second);defer cancel()
    _,err=t.client.SendPeerMessage(ctx, message);return err
}
func (t *transport) handle(r request) object {
	t.operations.Lock()
	defer t.operations.Unlock()
	if r.Op == "init" {
		if err := t.init(r.Path); err != nil {
			return fail("No se pudo abrir la sesión privada de WhatsApp")
		}
		return object{"ok": true, "linked": t.client.Store.ID != nil, "connected": t.client.IsLoggedIn()}
	}
	if t.client == nil {
		return fail("La conexión aún no está preparada")
	}
	switch r.Op {
	case "connect":
		if err := t.connect(r.Phone); err != nil {
			return fail(err.Error())
		}
	case "consent":
		next := map[string]bool{}
		for _, id := range r.Selected {
			next[id] = true
		}
		t.mu.Lock()
		for id := range t.selected {
			if !next[id] {
				for _, done := range t.processed {
					for k := range done {
						if strings.HasPrefix(k, id+":") {
							delete(done, k)
						}
					}
				}
			}
		}
		t.selected = next
		t.enabled = r.Enabled
		if r.Days == 30 || r.Days == 90 || r.Days == 365 {
			t.days = r.Days
		}
		for id := range t.anchors {
			if !next[id] {
				delete(t.anchors, id)
			}
		}
		t.mu.Unlock()
	case "groups":
		go t.groups()
	case "history":
		if !t.allowed(r.JID) {
			return fail("Autoriza primero la lectura del grupo")
		}
		go t.history(r.JID)
	case "more":
		if err := t.more(r.JID, r.Count); err != nil {
			return fail(err.Error())
		}
	case "stop":
		t.mu.Lock()
		t.enabled = false
		t.mu.Unlock()
		t.client.Disconnect()
	case "logout":
		ctx, cancel := context.WithTimeout(context.Background(), 25*time.Second)
		defer cancel()
		if t.client.Store.ID != nil {
			if err := t.client.Logout(ctx); err != nil {
				return fail("No se pudo desvincular en WhatsApp. Conecta a Internet y vuelve a intentarlo, o revoca el dispositivo desde WhatsApp")
			}
		}
		return t.forgetLocal()
	case "forget":
		t.mu.Lock()
		unlinked := t.unlinked
		t.mu.Unlock()
		if !unlinked {
			return fail("Desvincula primero el dispositivo desde WhatsApp")
		}
		return t.forgetLocal()
	case "status":
		return object{"ok": true, "linked": t.client.Store.ID != nil, "connected": t.client.IsLoggedIn()}
	default:
		return fail("Operación desconocida")
	}
	return object{"ok": true}
}

func (t *transport) forgetLocal() object {
	t.mu.Lock()
	cli := t.client
	container := t.container
	t.client = nil
	t.container = nil
	close(t.stop)
	t.enabled = false
	t.selected = map[string]bool{}
	t.notifications = nil
	t.anchors = map[string]*types.MessageInfo{}
	t.processed = map[string]map[string]bool{}
	t.mu.Unlock()
	cli.Disconnect()
	_ = container.Close()
	for _, name := range []string{"session.db", "session.db-wal", "session.db-shm", "history-pointers.json"} {
		_ = os.Remove(filepath.Join(t.dir, name))
	}
	for {
		select {
		case <-t.queue:
			continue
		default:
			return object{"ok": true}
		}
	}
}

//export ACCommand
func ACCommand(input *C.char) *C.char {
	var r request
	if err := json.Unmarshal([]byte(C.GoString(input)), &r); err != nil {
		return C.CString(marshaled(fail("Solicitud no válida")))
	}
	return C.CString(marshaled(bridge.handle(r)))
}

//export ACPoll
func ACPoll() *C.char {
	items := make([]object, 0, 128)
	for len(items) < 128 {
		select {
		case item := <-bridge.queue:
			items = append(items, item)
		default:
			return C.CString(marshaled(items))
		}
	}
	return C.CString(marshaled(items))
}
