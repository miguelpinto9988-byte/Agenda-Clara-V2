#!/usr/bin/env python3
"""Compile the Android app and package the prebuilt native transport with SDK tools and ECJ or javac."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from xml.etree import ElementTree as ET


def run(args, cwd=None):
    subprocess.run([str(x) for x in args], cwd=cwd, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--android-jar", type=Path, required=True)
    parser.add_argument("--build-tools", type=Path, required=True)
    parser.add_argument("--ecj", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    build = root / "build"
    dist = root / "dist"
    if build.exists():
        shutil.rmtree(build)
    for d in [build / "gen", build / "classes", build / "dex", dist]:
        d.mkdir(parents=True, exist_ok=True)
    sdk = args.build_tools.resolve()
    android = args.android_jar.resolve()
    ET.register_namespace("android", "http://schemas.android.com/apk/res/android")
    manifest_root = ET.parse(root / "app/src/main/AndroidManifest.xml").getroot()
    manifest_root.set("package", "pe.agendaclara.app")
    manifest_root.set("{http://schemas.android.com/apk/res/android}versionCode", "5")
    manifest_root.set("{http://schemas.android.com/apk/res/android}versionName", "1.3.0")
    manifest = build / "AndroidManifest.xml"
    ET.ElementTree(manifest_root).write(manifest, encoding="utf-8", xml_declaration=True)
    run([sdk / "aapt2", "compile", "--dir", root / "app/src/main/res", "-o", build / "resources.zip"])
    run([sdk / "aapt2", "link", "-I", android, "--manifest", manifest, "--java", build / "gen",
         "--min-sdk-version", "26", "--target-sdk-version", "35", "--auto-add-overlay",
         "-o", build / "base.apk", build / "resources.zip"])
    sources = sorted((root / "app/src/main/java").rglob("*.java")) + sorted((build / "gen").rglob("*.java"))
    compiler = ["java", "-jar", args.ecj.resolve(), "-1.8", "-nowarn"] if args.ecj else ["javac", "-source", "8", "-target", "8"]
    boot = str(android) + os.pathsep + str(sdk / "core-lambda-stubs.jar")
    run(compiler + ["-encoding", "UTF-8", "-bootclasspath", boot, "-d", build / "classes"] + sources)
    with zipfile.ZipFile(build / "classes.jar", "w", zipfile.ZIP_DEFLATED) as z:
        for p in (build / "classes").rglob("*.class"):
            z.write(p, p.relative_to(build / "classes"))
    run(["java", "-cp", sdk / "lib/d8.jar", "com.android.tools.r8.D8",
         "--min-api", "26", "--lib", android, "--output", build / "dex", build / "classes.jar"])
    shutil.copy2(build / "base.apk", build / "unsigned.apk")
    with zipfile.ZipFile(build / "unsigned.apk", "a", zipfile.ZIP_DEFLATED) as z:
        for p in (build / "dex").glob("*.dex"):
            z.write(p, p.name)
        for p in (root / "app/src/main/jniLibs").rglob("*.so"):
            z.write(p, "lib/" + str(p.relative_to(root / "app/src/main/jniLibs")))
        for p in (root / "app/src/main/assets").rglob("*"):
            if p.is_file():z.write(p, "assets/" + str(p.relative_to(root / "app/src/main/assets")))
    run([sdk / "zipalign", "-f", "4", build / "unsigned.apk", build / "aligned.apk"])
    # A project-specific development key is included so the owner can build updates.
    signing = root / "signing"
    signing.mkdir(exist_ok=True)
    keystore = signing / "development.jks"
    if not keystore.exists():
        run(["keytool", "-genkeypair", "-keystore", keystore, "-storepass", "android", "-keypass", "android",
             "-alias", "agendaclara", "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
             "-dname", "CN=Agenda Clara Development, O=Personal Project, C=PE"])
    output = dist / "Agenda-Clara-1.3.0.apk"
    run(["java", "-jar", sdk / "lib/apksigner.jar", "sign", "--ks", keystore, "--ks-key-alias", "agendaclara",
         "--ks-pass", "pass:android", "--key-pass", "pass:android", "--out", output, build / "aligned.apk"])
    run(["java", "-jar", sdk / "lib/apksigner.jar", "verify", "--verbose", "--print-certs", output])
    run([sdk / "zipalign", "-c", "4", output])
    print(f"APK: {output} ({output.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
