package pe.agendaclara.tests;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.CalendarContract;
import android.view.*;
import android.widget.*;
import java.lang.reflect.*;
import java.util.*;
import org.json.*;
import pe.agendaclara.app.*;

/** Synthetic emulator data only. This does not authenticate to Google or WhatsApp. */
public final class ReviewInstrumentation extends Instrumentation {
    Bundle args;Context c;Store db;volatile Activity current;JSONArray checks=new JSONArray();
    List<Long> tasks=new ArrayList<>(),proposals=new ArrayList<>();long calendar=-1;int widget=-1;AppWidgetHost host;
    @Override public void onCreate(Bundle args){super.onCreate(args);this.args=args;start();}
    interface Condition {boolean ok() throws Exception;}
    void await(Condition condition,long timeout)throws Exception{long end=SystemClock.elapsedRealtime()+timeout;while(SystemClock.elapsedRealtime()<end){if(condition.ok())return;SystemClock.sleep(80);}throw new AssertionError("Timeout: "+timeout+" ms");}
    void check(boolean good,String name)throws Exception{checks.put(new JSONObject().put("name",name).put("passed",good));Bundle progress=new Bundle();progress.putString("check",name);progress.putInt("count",checks.length());sendStatus(good?0:-1,progress);if(!good)throw new AssertionError(name);}
    Object field(Object o,String name)throws Exception{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
    AlertDialog editor()throws Exception{Activity a=current;return a==null?null:(AlertDialog)field(a,"editor");}
    boolean editorVisible()throws Exception{final boolean[] visible={false};runOnMainSync(()->{try{AlertDialog d=editor();visible[0]=d!=null&&d.isShowing();}catch(Exception ignored){}});return visible[0];}
    View tagged(String tag)throws Exception{final View[] out={null};runOnMainSync(()->{Activity a=current;if(a!=null)out[0]=a.getWindow().getDecorView().findViewWithTag(tag);});return out[0];}
    void editorButton(int which)throws Exception{runOnMainSync(()->{try{editor().getButton(which).performClick();}catch(Exception e){throw new RuntimeException(e);}});}
    void launch(String action,int tab)throws Exception{
        Intent i=new Intent(c,MainActivity.class).setAction(action).putExtra("tab",tab).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivitySync(i);await(()->current!=null,15000);waitForIdleSync();
    }
    android.service.notification.StatusBarNotification notification(long id){for(android.service.notification.StatusBarNotification n:c.getSystemService(NotificationManager.class).getActiveNotifications())if("proposal".equals(n.getTag())&&n.getId()==(int)id)return n;return null;}
    long incoming(String key,String text)throws Exception{
        long stamp=System.currentTimeMillis();int offered=ReviewFlow.receive(c,key,text,stamp);check(offered==1,"Selected chat offers proposal");
        Store.Inbox p=db.inbox().get(0);proposals.add(p.id);return p.id;
    }
    void tapPending(long id,int action)throws Exception{await(()->notification(id)!=null,15000);android.service.notification.StatusBarNotification n=notification(id);check(n!=null,"Proposal notification exists: "+id);n.getNotification().actions[action].actionIntent.send();}
    TextView named(View v,String name){if(v instanceof TextView&&name.equals(((TextView)v).getText().toString()))return (TextView)v;if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int n=0;n<g.getChildCount();n++){TextView t=named(g.getChildAt(n),name);if(t!=null)return t;}}return null;}
    @Override public void onStart(){
        JSONObject report=new JSONObject();boolean passed=false;
        try{
            c=getTargetContext();db=Store.get(c);
            if("seed_v1".equals(args.getString("mode"))){
                Task old=new Task();old.title="QA tarea existente V1";old.notes="Preservar al actualizar";db.save(old);c.getSharedPreferences("qa",0).edit().putLong("seed",old.id).commit();check(old.id>0,"Created migration seed in original v1 APK");
            }else{
                Application app=(Application)c.getApplicationContext();
                app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks(){
                    public void onActivityResumed(Activity a){if(a instanceof MainActivity)current=a;}
                    public void onActivityCreated(Activity a,Bundle b){}public void onActivityStarted(Activity a){}public void onActivityPaused(Activity a){}public void onActivityStopped(Activity a){}public void onActivitySaveInstanceState(Activity a,Bundle b){}public void onActivityDestroyed(Activity a){}
                });
                if("photo".equals(args.getString("mode"))){launch("tasks",0);await(()->current!=null&&field(current,"root")!=null,20000);photoChecks();}else runChecks();
            }
            passed=true;
        }catch(Throwable e){try{report.put("error",e.toString());if(current!=null){report.put("last_intent",current.getIntent().toUri(0));report.put("editor_showing",editorVisible());}}catch(Exception ignored){}}
        finally{
            try{for(long id:tasks){Task t=db.find(id);if(t!=null&&t.eventId>0)c.getContentResolver().delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,t.eventId),null,null);Reminders.cancel(c,id);db.delete(id);}for(long id:proposals){db.dismiss(id);Reminders.cancelProposal(c,id);}if(widget>0&&host!=null)host.deleteAppWidgetId(widget);if(calendar>0){Prefs.selectCalendar(c,calendar,false);if(Prefs.calendar(c)==calendar)Prefs.get(c).edit().putLong("calendar",-1).remove("calendar_name").commit();c.getContentResolver().delete(ContentUris.withAppendedId(CalendarContract.Calendars.CONTENT_URI,calendar),null,null);}}catch(Exception ignored){}
        }
        try{report.put("passed",passed).put("checks",checks).put("scope","Synthetic Android emulator; no personal WhatsApp or Google account");}catch(Exception ignored){}
        Bundle result=new Bundle();result.putString("report",report.toString());finish(passed?Activity.RESULT_OK:Activity.RESULT_CANCELED,result);
    }
    void runChecks()throws Exception{
        long seed=c.getSharedPreferences("qa",0).getLong("seed",-1);Task old=db.find(seed);
        check(old!=null&&"QA tarea existente V1".equals(old.title)&&"Preservar al actualizar".equals(old.notes),"Update preserves existing task and notes");
        check(db.getReadableDatabase().getVersion()==3,"Database migrated to v3");
        launch("tasks",0);await(()->current!=null && field(current,"root")!=null,20000);
        Prefs.get(c).edit().putBoolean("wa_reading",false).putBoolean("capture",true).putLong("capture_since",System.currentTimeMillis()-5000).putBoolean("auto",true).commit();
        String key=Store.chatKey("com.whatsapp","qa-review","QA Grupo de prueba");db.observeChat(key,"com.whatsapp","QA Grupo de prueba",true,System.currentTimeMillis());db.selectChat(key,false);
        int before=db.all().size();check(ReviewFlow.receive(c,key,"Entregar informe mañana a las 3 pm",System.currentTimeMillis())==0,"Unselected chat ignored");
        db.selectChat(key,true);long stamp=System.currentTimeMillis();check(ReviewFlow.receive(c,key,"Entregar informe mañana a las 3 pm",stamp)==1,"Selected message produces a proposal");
        Store.Inbox p=db.inbox().get(0);proposals.add(p.id);check(db.all().size()==before,"Incoming message creates no Task despite legacy auto preference");
        check(ReviewFlow.receive(c,key,"Entregar informe mañana a las 3 pm",stamp)==0,"Repeated notification is deduplicated");
        await(()->notification(p.id)!=null,15000);android.service.notification.StatusBarNotification n=notification(p.id);check(n!=null,"Proposal notification posted");
        check(n.getNotification().actions.length==2,"Exactly two decision actions");
        check("Agregar".contentEquals(n.getNotification().actions[0].title)&&"No agregar".contentEquals(n.getNotification().actions[1].title),"Decision labels match requested UI");
        tapPending(p.id,0);await(()->editorVisible(),45000);check(db.all().size()==before,"Agregar opens editor without saving");
        editorButton(DialogInterface.BUTTON_POSITIVE);await(()->db.findOrigin(p.key)!=null,15000);
        Task accepted=db.findOrigin(p.key);tasks.add(accepted.id);check(db.all().size()==before+1&&db.pending(p.id)==null,"Only Save creates one Task and handles proposal");
        await(()->notification(p.id)==null,10000);check(notification(p.id)==null,"Saved proposal notification dismissed");check(!db.acceptProposal(new Task(),p.id),"Stale proposal cannot create a duplicate Task");
        long no=incoming(key,"Reunión mañana a las 4 pm");tapPending(no,1);await(()->db.pending(no)==null,10000);check(db.all().size()==before+1,"No agregar creates no Task");await(()->notification(no)==null,10000);check(notification(no)==null,"No agregar dismisses its notification");
        long cancel=incoming(key,"Examen mañana a las 5 pm");tapPending(cancel,0);await(()->editorVisible(),45000);editorButton(DialogInterface.BUTTON_NEGATIVE);check(db.pending(cancel)!=null&&db.all().size()==before+1,"Volver preserves proposal and creates no Task");
        linkedChecks();
        calendarChecks();photoChecks();
    }
    void uiClick(String label)throws Exception{
        await(()->{final boolean[] ready={false};runOnMainSync(()->{try{AlertDialog dialog=(AlertDialog)field(current,"consentDialog");ready[0]=dialog!=null&&dialog.isShowing()&&dialog.getButton(DialogInterface.BUTTON_POSITIVE)!=null;}catch(Exception ignored){}});return ready[0];},15000);
        runOnMainSync(()->{try{AlertDialog dialog=(AlertDialog)field(current,"consentDialog");Button b=dialog.getButton(DialogInterface.BUTTON_POSITIVE);if(!label.equalsIgnoreCase(b.getText().toString()))throw new AssertionError("Unexpected consent action: "+b.getText());b.performClick();}catch(Exception e){throw new RuntimeException(e);}});
    }
    void linkedChecks()throws Exception{
        int before=db.all().size();String jid="123456789@g.us",key=Store.linkedKey(jid);
        db.linkedGroup("123456700@g.us","QA Comunidad","",true,true,System.currentTimeMillis());db.linkedGroup(jid,"QA Grupo de comunidad","123456700@g.us",false,true,System.currentTimeMillis());for(long id:db.revokeReading(key))Reminders.cancelProposal(c,id);
        ConversationAnalyzer.Message old=new ConversationAnalyzer.Message();old.id="qa-old";old.body="Entregar informe mañana a las 3 pm";old.sender="profesor";old.time=System.currentTimeMillis()-40*86400000L;
        Prefs.get(c).edit().putBoolean("wa_reading",true).putBoolean("wa_link_consent_v1",false).commit();
        check(!db.recordMessage(key,old),"Unselected group body cannot be stored");
        launch("connections",0);await(()->tagged("chat:"+key)!=null,20000);View row=tagged("chat:"+key);
        check(db.messageCount(key)==0&&row!=null,"Community group visible before any incoming message");
        int neutral=((GradientDrawable)row.getBackground()).getColor().getDefaultColor();runOnMainSync(()->row.performClick());
        check(!db.getChat(key).selected,"Touching group does not bypass reading consent");uiClick("Permitir lectura");await(()->db.getChat(key).selected&&tagged("chat:"+key)!=null,15000);
        check(db.getChat(key).selected,"Per-group reading consent persisted");
        check(neutral!=((GradientDrawable)tagged("chat:"+key).getBackground()).getColor().getDefaultColor(),"Selected community group changes color");
        check(db.recordMessage(key,old),"Authorized historical message stored");
        check(ReviewFlow.analyzeLinked(c,key,true,"")==1,"Selecting group history offers an old activity");
        Store.Inbox box=null;for(Store.Inbox candidate:db.inbox())if(key.equals(candidate.chatKey)){box=candidate;break;}
        check(box!=null&&box.historical&&box.reason.contains("Fecha pasada"),"Old proposal records past date and historical source");
        proposals.add(box.id);final long historyId=box.id;
        check(box.created==old.time,"Original message timestamp preserved");
        check(db.all().size()==before,"History interpretation creates no task");
        check(ReviewFlow.analyzeLinked(c,key,true,"")==0,"Repeated history scan creates no duplicate proposal");
        check(notification(historyId)==null,"History review does not flood individual notifications");
        Prefs.get(c).edit().putBoolean("wa_reading",false).commit();ConversationAnalyzer.Message paused=new ConversationAnalyzer.Message();paused.id="qa-paused";paused.body=old.body;paused.sender="profesor";paused.time=System.currentTimeMillis();
        check(!db.recordMessage(key,paused)&&ReviewFlow.analyzeLinked(c,key,true,"")==0,"Global pause blocks storage and interpretation");Prefs.get(c).edit().putBoolean("wa_reading",true).commit();
        ConversationAnalyzer.Message casual=new ConversationAnalyzer.Message();casual.id="qa-question";casual.body="¿Qué tarea tenemos mañana?";casual.time=System.currentTimeMillis();casual.sender="alumno";db.recordMessage(key,casual);
        check(ReviewFlow.analyzeLinked(c,key,true,"")==0,"Question in selected group produces no proposal");
        ConversationAnalyzer.Message cancellation=new ConversationAnalyzer.Message();cancellation.id="qa-cancel";cancellation.body="Se cancela esa entrega";cancellation.reply=old.id;cancellation.sender=old.sender;cancellation.time=old.time+1000;db.recordMessage(key,cancellation);ReviewFlow.analyzeLinked(c,key,true,"");
        check(db.pending(historyId)==null&&db.all().size()==before,"Quoted cancellation withdraws suggestion without editing tasks");
        android.database.sqlite.SQLiteDatabase sql=db.getWritableDatabase();sql.beginTransaction();try{
            android.database.sqlite.SQLiteStatement insert=sql.compileStatement("INSERT OR REPLACE INTO messages(chat_key,message_id,body,quoted,reply_id,sender,stamp,from_me) VALUES(?,?,?,'','','qa',?,0)");
            for(int j=0;j<4005;j++){insert.bindString(1,key);insert.bindString(2,"qa-cache-"+j);insert.bindString(3,"Gracias, buenos días");insert.bindLong(4,System.currentTimeMillis()-86400000L+j);insert.executeInsert();}insert.close();sql.setTransactionSuccessful();
        }finally{sql.endTransaction();}
        ConversationAnalyzer.Message latest=new ConversationAnalyzer.Message();latest.id="qa-cache-last";latest.body="Gracias";latest.sender="qa";latest.time=System.currentTimeMillis();db.recordMessage(key,latest);
        check(db.messageCount(key)==4000,"Live message cache bounded to 4000 rows per group");
        launch("connections",0);await(()->tagged("chat:"+key)!=null,20000);final View revokeRow=tagged("chat:"+key);runOnMainSync(()->revokeRow.performClick());uiClick("Revocar lectura");await(()->!db.getChat(key).selected,15000);
        check(db.messageCount(key)==0,"Revoking reading clears stored group messages");
        check(db.all().size()==before,"Revoking reading preserves saved tasks");
        JSONObject init=WhatsAppNative.call(new JSONObject().put("op","init").put("path",new java.io.File(c.getNoBackupFilesDir(),"whatsapp").getAbsolutePath()));
        check(!init.getBoolean("linked"),"Actual JNI transport loads and opens private SQLite without an account");
        WhatsAppNative.call(new JSONObject().put("op","consent").put("selected",new JSONArray()).put("enabled",false).put("days",90));
        check(WhatsAppNative.events().length()==0,"Idle native connection emits no fake groups or messages");
        boolean denied=false;try{WhatsAppNative.call(new JSONObject().put("op","more").put("jid",jid));}catch(Exception expected){denied=true;}check(denied,"Native older-history request requires group consent");
        Prefs.get(c).edit().putBoolean("wa_reading",false).commit();db.clearLinked();
    }
    void calendarChecks()throws Exception{
        ContentValues v=new ContentValues();v.put(CalendarContract.Calendars.ACCOUNT_NAME,"QA LOCAL");v.put(CalendarContract.Calendars.ACCOUNT_TYPE,CalendarContract.ACCOUNT_TYPE_LOCAL);v.put(CalendarContract.Calendars.NAME,"QA Agenda");v.put(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,"QA Calendario de prueba");v.put(CalendarContract.Calendars.CALENDAR_COLOR,0xff286855);v.put(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL,700);v.put(CalendarContract.Calendars.OWNER_ACCOUNT,"QA LOCAL");v.put(CalendarContract.Calendars.VISIBLE,1);v.put(CalendarContract.Calendars.SYNC_EVENTS,1);v.put(CalendarContract.Calendars.CALENDAR_TIME_ZONE,TimeZone.getDefault().getID());
        android.net.Uri uri=CalendarContract.Calendars.CONTENT_URI.buildUpon().appendQueryParameter(CalendarContract.CALLER_IS_SYNCADAPTER,"true").appendQueryParameter(CalendarContract.Calendars.ACCOUNT_NAME,"QA LOCAL").appendQueryParameter(CalendarContract.Calendars.ACCOUNT_TYPE,CalendarContract.ACCOUNT_TYPE_LOCAL).build();
        calendar=ContentUris.parseId(c.getContentResolver().insert(uri,v));check(calendar>0,"Real Calendar Provider local test calendar created");
        Prefs.selectCalendar(c,calendar,false);if(Prefs.calendar(c)==calendar)Prefs.get(c).edit().putLong("calendar",-1).remove("calendar_name").commit();
        launch("connections",1);await(()->tagged("calendar:"+calendar)!=null,20000);View row=tagged("calendar:"+calendar);runOnMainSync(()->row.performClick());check(Prefs.calendars(c).contains(""+calendar),"Calendar card selects actual provider ID");
        View card=tagged("calendar:"+calendar);TextView dest=named(card,"Usar para nuevas tareas");check(dest!=null,"Writable calendar offers destination button");runOnMainSync(()->dest.performClick());check(Prefs.calendar(c)==calendar,"Destination selection persisted");
        Task t=new Task();t.title="QA evento desde tarea";t.due=System.currentTimeMillis()+86400000L;t.calendarEnabled=true;t.calendarId=calendar;db.save(t);tasks.add(t.id);check(CalendarBridge.upsert(c,t).isEmpty(),"Task writes an event in local Calendar Provider");
        t=db.find(t.id);long event=t.eventId;check(event>0,"Event link persisted");
        try(Cursor cur=c.getContentResolver().query(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,event),new String[]{"title","dtstart"},null,null,null)){check(cur!=null&&cur.moveToFirst()&&t.title.equals(cur.getString(0))&&t.due==cur.getLong(1),"Provider event contains title and date");}
        t.title="QA evento editado";db.save(t);check(CalendarBridge.upsert(c,t).isEmpty()&&db.find(t.id).eventId==event,"Editing linked Task reuses event ID");
        await(()->!CalendarBridge.selectedEvents(c).isEmpty(),10000);check(!CalendarBridge.selectedEvents(c).isEmpty(),"Selected calendar events read from provider");
    }
    void photoChecks()throws Exception{
        host=new AppWidgetHost(c,611);widget=host.allocateAppWidgetId();AppWidgetManager m=AppWidgetManager.getInstance(c);check(m.bindAppWidgetIdIfAllowed(widget,new ComponentName(c,PhotoWidget.class)),"Photo widget bound to actual Android host");
        final AppWidgetHostView[] view={null};runOnMainSync(()->{view[0]=host.createView(c,widget,m.getAppWidgetInfo(widget));host.startListening();PhotoWidget.update(c,widget);});
        await(()->{final boolean[] present={false};runOnMainSync(()->present[0]=view[0].findViewById(R.id.photo_image)!=null&&view[0].findViewById(R.id.photo_image).hasOnClickListeners());return present[0];},15000);
        View image=view[0].findViewById(R.id.photo_image);check(image!=null,"Photo fills widget without overlay controls");
        final int[] configs={0};((Application)c.getApplicationContext()).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks(){public void onActivityCreated(Activity a,Bundle b){}public void onActivityResumed(Activity a){if(a instanceof PhotoConfigActivity)configs[0]++;}public void onActivityStarted(Activity a){}public void onActivityPaused(Activity a){}public void onActivityStopped(Activity a){}public void onActivitySaveInstanceState(Activity a,Bundle b){}public void onActivityDestroyed(Activity a){}});
        Prefs.get(c).edit().remove("photo_tap_"+widget).commit();runOnMainSync(()->image.performClick());
        await(()->Prefs.get(c).contains("photo_tap_"+widget),15000);check(configs[0]==0,"Single widget tap does not open editor");
        // Reset expired first touch, then deliver two distinct taps on the main queue.
        Prefs.get(c).edit().remove("photo_tap_"+widget).commit();
        runOnMainSync(()->{image.performClick();new Handler(Looper.getMainLooper()).postDelayed(()->image.performClick(),120);});
        await(()->configs[0]>0,15000);check(configs[0]==1,"Double widget tap opens one photo configuration");
        check(!Prefs.get(c).contains("photo_tap_"+widget),"Double tap state resets after opening");
        host.stopListening();
    }
}
