package pe.agendaclara.app;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.widget.*;
import java.util.*;

public final class TaskWidget extends AppWidgetProvider {
    public static RemoteViews row(Context c,Task t){
        RemoteViews row=new RemoteViews(c.getPackageName(),R.layout.widget_row);
        row.setTextViewText(R.id.row_title,t.title.length()>200?t.title.substring(0,197)+"…":t.title);row.setTextViewText(R.id.row_check,t.done?"☑":"☐");
        row.setTextViewText(R.id.row_meta,TaskLogic.status(t,System.currentTimeMillis())+" · "+TaskLogic.when(t.due));
        row.setTextColor(R.id.row_meta,t.due>0&&t.due-System.currentTimeMillis()<2*86400000L&&!t.done?0xffa23e32:0xff61766a);
        row.setOnClickFillInIntent(R.id.row_check,new Intent().putExtra("task_id",t.id).putExtra("toggle",true));
        row.setOnClickFillInIntent(R.id.row_content,new Intent().putExtra("task_id",t.id).putExtra("toggle",false));
        return row;
    }
    public static void refresh(Context c){
        AppWidgetManager m=AppWidgetManager.getInstance(c);
        int[] ids=m.getAppWidgetIds(new ComponentName(c,TaskWidget.class));
        List<Task> all=Store.get(c).all();
        for(int id:ids)update(c,m,id,all);
    }
    private static void update(Context c,AppWidgetManager m,int id,List<Task> all){
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_tasks);
        Intent add=new Intent(c,MainActivity.class).setAction("new_task").setData(Uri.parse("agenda://new/widget/"+id));
        v.setOnClickPendingIntent(R.id.widget_add,PendingIntent.getActivity(c,id,add,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
        v.setOnClickPendingIntent(R.id.widget_header,PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class).setAction("tasks"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
        Intent template=new Intent(c,MainActivity.class).setAction("widget_task").setData(Uri.parse("agenda://widget/"+id));
        int flags=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=31)flags|=PendingIntent.FLAG_MUTABLE;
        v.setPendingIntentTemplate(R.id.widget_list,PendingIntent.getActivity(c,9000+id,template,flags));
        if(Build.VERSION.SDK_INT>=31&&all.size()<=300){
            RemoteViews.RemoteCollectionItems.Builder items=new RemoteViews.RemoteCollectionItems.Builder().setHasStableIds(true).setViewTypeCount(1);
            for(Task t:all)items.addItem(t.id,row(c,t));
            v.setRemoteAdapter(R.id.widget_list,items.build());
        }else{
            Intent service=new Intent(c,TaskWidgetService.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
            service.setData(Uri.parse("agenda://widget-service/"+id));v.setRemoteAdapter(R.id.widget_list,service);
        }
        v.setEmptyView(R.id.widget_list,R.id.widget_empty);
        v.setTextViewText(R.id.widget_header,"Mis tareas · "+all.size());
        m.updateAppWidget(id,v);
        if(Build.VERSION.SDK_INT<31||all.size()>300)m.notifyAppWidgetViewDataChanged(id,R.id.widget_list);
    }
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){List<Task> all=Store.get(c).all();for(int id:ids)update(c,m,id,all);}
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle b){update(c,m,id,Store.get(c).all());}
}
