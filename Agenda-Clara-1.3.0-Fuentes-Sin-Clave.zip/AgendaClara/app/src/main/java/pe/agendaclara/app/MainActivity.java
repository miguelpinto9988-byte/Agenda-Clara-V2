package pe.agendaclara.app;

import android.Manifest;
import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class MainActivity extends Activity {
    static final int BG=0xfff4f7ff,INK=0xff101d43,GREEN=0xff2765f2,MUTED=0xff647393,RED=0xffe55c5c;
    static final int VIOLET=0xff7158e8,SUCCESS=0xff078568,SURFACE=0xffffffff,PALE=0xffe9f0ff,STROKE=0xffe0e8f8;
    String pendingHistoryChat="";ScrollView contentScroll;int renderedPage=-1,chatLimit=40,inboxLimit=25,taskLimit=60;String chatQuery="";boolean communitiesOnly=false;
    LinearLayout root,body,nav,taskList;TextView statusLine,headerTitle,headerDate;int page=0,filter=0,connectionTab=0;String query="";
    LocalDate selectedDay=LocalDate.now(),month=selectedDay.withDayOfMonth(1);
    Handler handler=new Handler(Looper.getMainLooper());AlertDialog editor,consentDialog;Bundle restoreDraft;Runnable captureDraft;
    boolean resumed=false,refreshPending=false,refreshPosted=false,forceRefresh=false,allowFocusedRefresh=false,touching=false,selectingText=false;
    long lastRefresh=0,lastScroll=0;int renderCount=0;String lastDataSignature="";
    final Set<AlertDialog> dialogs=new HashSet<>();final Set<Long> expandedProposals=new HashSet<>();
    Runnable taskSearch,groupSearch;
    final Runnable tick=new Runnable(){public void run(){
        if(resumed){CompletedTaskCleanup.run(MainActivity.this);if(page<2){forceRefresh=true;requestRefresh();}handler.postDelayed(this,60000);}
    }};
    boolean dataReceiverRegistered=false;
    final Runnable refreshData=()->{refreshPosted=false;refreshVisibleData();};
    final BroadcastReceiver dataReceiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){requestRefresh();}};
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        if(Prefs.get(this).getBoolean("capture",false)&&!Prefs.get(this).contains("discover"))Prefs.get(this).edit().putBoolean("discover",true).apply();
        Prefs.get(this).edit().remove("auto").apply();
        IntentFilter dataFilter=new IntentFilter(ReviewFlow.DATA_CHANGED);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(dataReceiver,dataFilter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(dataReceiver,dataFilter);
        dataReceiverRegistered=true;
        if(handleWidgetToggle(getIntent()))return;
        if(state!=null){pendingHistoryChat=state.getString("history_chat","");page=Math.max(0,Math.min(3,state.getInt("page")));connectionTab=Math.max(0,Math.min(2,state.getInt("connection_tab")));chatQuery=state.getString("chat_query","");communitiesOnly=state.getBoolean("communities_only",false);filter=state.getInt("filter");query=state.getString("query","");selectedDay=LocalDate.parse(state.getString("day",selectedDay.toString()));month=LocalDate.parse(state.getString("month",month.toString()));restoreDraft=state.getBundle("draft");}
        LinearLayout loading=column();loading.setGravity(Gravity.CENTER);loading.setBackgroundColor(BG);
        ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.ic_app);loading.addView(icon,new LinearLayout.LayoutParams(dp(96),dp(96)));
        TextView name=text("Agenda Clara",28,INK,true);name.setGravity(Gravity.CENTER);loading.addView(name);
        ProgressBar progress=new ProgressBar(this);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(36),dp(36));pp.topMargin=dp(20);loading.addView(progress,pp);setContentView(loading);
        new Thread(()->{Store.get(this).getReadableDatabase();Reminders.channels(this);runOnUiThread(()->{if(isFinishing()||isDestroyed())return;render();if(restoreDraft!=null){Bundle d=restoreDraft;restoreDraft=null;openEditor(d.getLong("task_id",-1),null,d);}else route(getIntent());});},"load-agenda").start();
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);if(!handleWidgetToggle(i))route(i);}
    boolean handleWidgetToggle(Intent i){
        if(!"widget_task".equals(i.getAction())||!i.getBooleanExtra("toggle",false))return false;
        Task t=Store.get(this).find(i.getLongExtra("task_id",-1));if(t!=null){t.done=!t.done;Store.get(this).save(t);if(t.done)Reminders.cancel(this,t.id);else Reminders.schedule(this,t);TaskWidget.refresh(this);}
        finish();return true;
    }
    void route(Intent i){
        if(Intent.ACTION_SEND.equals(i.getAction())&&"text/plain".equals(i.getType())){String s=i.getStringExtra(Intent.EXTRA_TEXT);if(s!=null){page=2;render();importText(s,"Mensaje compartido");}return;}
        if("review_proposal".equals(i.getAction())){
            Store.Inbox box=Store.get(this).pending(i.getLongExtra("proposal_id",-1));
            if(box==null){toast("Esta propuesta ya fue atendida.");return;}
            page=2;render();openEditor(-1,box,null);return;
        }
        if("connections".equals(i.getAction())){page=3;connectionTab=Math.max(0,Math.min(2,i.getIntExtra("tab",0)));render();return;}
        if("new_task".equals(i.getAction())){openEditor(-1,null,null);return;}
        if("inbox".equals(i.getAction())){page=2;render();return;}
        long id=i.getLongExtra("task_id",-1);if(id>0)openEditor(id,null,null);
    }
    @Override protected void onResume(){super.onResume();resumed=true;handler.removeCallbacks(tick);handler.postDelayed(tick,60000);if(root!=null){forceRefresh=true;requestRefresh();}if(Prefs.get(this).getBoolean("wa_linked",false)&&Prefs.get(this).getBoolean("wa_reading",false)&&!WhatsAppSessionService.running)session("resume",null);new Thread(()->{CompletedTaskCleanup.run(this);Reminders.rebuild(this);TaskWidget.refresh(this);},"resume-reminders").start();}
    @Override protected void onPause(){resumed=false;handler.removeCallbacks(tick);handler.removeCallbacks(refreshData);refreshPosted=false;super.onPause();}
    @Override public void onActionModeStarted(ActionMode mode){super.onActionModeStarted(mode);selectingText=true;}
    @Override public void onActionModeFinished(ActionMode mode){super.onActionModeFinished(mode);selectingText=false;if(refreshPending)requestRefresh();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);if(dataReceiverRegistered)unregisterReceiver(dataReceiver);for(AlertDialog d:new ArrayList<>(dialogs))if(d.isShowing())d.dismiss();dialogs.clear();super.onDestroy();}
    @Override protected void onSaveInstanceState(Bundle out){
        super.onSaveInstanceState(out);out.putString("history_chat",pendingHistoryChat);out.putString("chat_query",chatQuery);out.putBoolean("communities_only",communitiesOnly);out.putInt("page",page);out.putInt("connection_tab",connectionTab);out.putInt("filter",filter);out.putString("query",query);out.putString("day",selectedDay.toString());out.putString("month",month.toString());if(captureDraft!=null)captureDraft.run();if(restoreDraft!=null)out.putBundle("draft",restoreDraft);
    }
    LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    GradientDrawable rounded(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    GradientDrawable gradient(int left,int right,int radius){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{left,right});
        g.setCornerRadius(dp(radius));return g;
    }
    Button primaryButton(String label,Runnable action){
        Button button=button(label,action);button.setTextColor(0xffffffff);button.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        button.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x30ffffff),gradient(GREEN,0xff477df4,14),null));
        return button;
    }
    TextView statLabel(String title,String value,int color){
        TextView text=text(value+"\n"+title,12,color,true);text.setGravity(Gravity.CENTER);
        text.setPadding(dp(6),dp(10),dp(6),dp(10));text.setBackground(rounded(color==SUCCESS?0xffe2f6ee:color==RED?0xffffebeb:PALE,13));
        return text;
    }
    GradientDrawable outlined(int color,int radius,int line){GradientDrawable d=rounded(color,radius);d.setStroke(dp(1),line);return d;}
    Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(GREEN);b.setMinHeight(dp(44));b.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(0x222765f2),rounded(PALE,13),null));b.setElevation(0);b.setOnClickListener(v->action.run());return b;}
    EditText input(String hint,String value,int type){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextColor(INK);e.setTextSize(16);e.setInputType(type);e.setMinHeight(dp(48));e.setHintTextColor(MUTED);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(outlined(0xffffffff,16,STROKE));return e;}
    void gap(LinearLayout p,int h){p.addView(new View(this),new LinearLayout.LayoutParams(1,dp(h)));}
    LinearLayout card(LinearLayout parent){
        LinearLayout c=column();c.setPadding(dp(15),dp(14),dp(15),dp(14));c.setBackground(outlined(SURFACE,19,STROKE));c.setElevation(dp(3));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(12);parent.addView(c,lp);return c;
    }
    void subtitle(LinearLayout p,String label){TextView t=text(label,16,INK,true);t.setPadding(0,dp(14),0,dp(8));p.addView(t);}
    void showLicenses(){
        try(java.io.InputStream in=getAssets().open("licenses.txt")){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);TextView value=text(new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8),12,MUTED,false);value.setTextIsSelectable(true);value.setPadding(dp(18),dp(12),dp(18),dp(12));ScrollView scroll=new ScrollView(this);scroll.addView(value);dialogBuilder().setTitle("Licencias y fuentes").setView(scroll).setPositiveButton("Cerrar",null).show();}catch(java.io.IOException e){toast("Consulta THIRD_PARTY_NOTICES.md en el proyecto.");}
    }
    void toast(String s){if(!isFinishing()&&!isDestroyed())Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    AlertDialog.Builder dialogBuilder(){return new AlertDialog.Builder(this,R.style.DialogTheme){@Override public AlertDialog create(){AlertDialog d=super.create();trackDialog(d);return d;}};}
    void trackDialog(AlertDialog d){dialogs.add(d);d.getWindow().getDecorView().addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){WindowLayout.boundDialog(MainActivity.this,d);}public void onViewDetachedFromWindow(View v){dialogs.remove(d);if(refreshPending||forceRefresh)requestRefresh();}});}
    boolean modalVisible(){for(AlertDialog d:dialogs)if(d.isShowing())return true;return false;}
    void requestRefresh(){refreshPending=true;if(!resumed||root==null||refreshPosted||isFinishing()||isDestroyed())return;refreshPosted=true;handler.postDelayed(refreshData,Math.max(250,700-(SystemClock.uptimeMillis()-lastRefresh)));}
    void refreshVisibleData(){
        if(!resumed||root==null||isFinishing()||isDestroyed())return;View focus=getCurrentFocus();
        if(modalVisible()||selectingText||(!allowFocusedRefresh&&focus instanceof EditText&&focus.hasFocus()))return;
        if(touching||SystemClock.uptimeMillis()-lastScroll<350){refreshPosted=true;handler.postDelayed(refreshData,400);return;}
        if(forceRefresh||!lastDataSignature.equals(dataSignature()))render();else refreshPending=false;
    }
    String dataSignature(){
        StringBuilder s=new StringBuilder().append(page).append(':').append(connectionTab);
        if(page==2){List<Store.Inbox> all=Store.get(this).inbox();s.append(':').append(all.size());for(int n=0;n<Math.min(inboxLimit,all.size());n++){Store.Inbox p=all.get(n);s.append('|').append(p.id).append(':').append(p.title).append(':').append(p.original).append(':').append(p.reason).append(':').append(p.due);}}
        else if(page==3&&connectionTab==0){Map<String,?> prefs=Prefs.get(this).getAll();for(String k:new String[]{"wa_status","wa_linked","wa_connected","wa_reading","wa_notify","wa_history_days","wa_history_count","wa_pair_code","wa_pair_expires","capture","discover"})s.append('|').append(k).append('=').append(prefs.get(k));s.append(WhatsAppSessionService.running);for(Store.Chat c:Store.get(this).chats())s.append('|').append(c.key).append(':').append(c.title).append(':').append(c.selected).append(':').append(c.parent).append(':').append(c.joined).append(':').append(c.scanState);}
        else if(page<2){for(Task t:Store.get(this).all())s.append('|').append(t.id).append(':').append(t.title).append(':').append(t.notes).append(':').append(t.due).append(':').append(t.done).append(':').append(t.urgent);}
        return s.toString();
    }
    static final class ScrollAnchor{Object tag;int y;ScrollAnchor(Object tag,int y){this.tag=tag;this.y=y;}}
    ScrollAnchor scrollAnchor(View v){
        if(v==null)return null;Object tag=v.getTag();android.graphics.Rect visible=new android.graphics.Rect();
        if(tag instanceof String&&(((String)tag).startsWith("task:")||((String)tag).startsWith("chat:")||((String)tag).startsWith("proposal:"))&&v.getGlobalVisibleRect(visible)){int[] position=new int[2];v.getLocationInWindow(position);return new ScrollAnchor(tag,position[1]);}
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int n=0;n<g.getChildCount();n++){ScrollAnchor result=scrollAnchor(g.getChildAt(n));if(result!=null)return result;}}return null;
    }
    void render(){
        if(isFinishing()||isDestroyed())return;if(modalVisible()){forceRefresh=true;allowFocusedRefresh=true;refreshPending=true;return;}
        handler.removeCallbacks(refreshData);refreshPosted=false;if(taskSearch!=null)handler.removeCallbacks(taskSearch);if(groupSearch!=null)handler.removeCallbacks(groupSearch);
        boolean samePage=renderedPage==page&&contentScroll!=null;final int scrollY=samePage?contentScroll.getScrollY():0;final ScrollAnchor anchor=samePage?scrollAnchor(body):null;renderedPage=page;
        View focus=samePage?getCurrentFocus():null;Object tag=focus instanceof EditText?focus.getTag():null;int selection=focus instanceof EditText?((EditText)focus).getSelectionStart():-1;
        if(root==null)createShell();headerTitle.setText(new String[]{"Mi agenda","Calendario","Por revisar","Conexiones"}[page]);headerDate.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE d MMMM",new Locale("es","PE"))).toUpperCase(new Locale("es","PE")));
        body.removeAllViews();if(page==0)tasksPage();else if(page==1)calendarPage();else if(page==2)messagesPage();else settingsPage();
        if(tag!=null){View restored=body.findViewWithTag(tag);if(restored instanceof EditText){restored.requestFocus();((EditText)restored).setSelection(Math.max(0,Math.min(selection,((EditText)restored).length())));}}
        for(int n=0;n<nav.getChildCount();n++){LinearLayout item=(LinearLayout)nav.getChildAt(n);item.setBackground(rounded(page==n?PALE:0xffffffff,15));((ImageView)item.getChildAt(0)).setImageTintList(ColorStateList.valueOf(page==n?GREEN:MUTED));TextView label=(TextView)item.getChildAt(1);label.setTextColor(page==n?GREEN:MUTED);label.setTypeface(Typeface.DEFAULT,page==n?Typeface.BOLD:Typeface.NORMAL);}
        contentScroll.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener(){public boolean onPreDraw(){if(contentScroll.getViewTreeObserver().isAlive())contentScroll.getViewTreeObserver().removeOnPreDrawListener(this);View target=anchor==null?null:body.findViewWithTag(anchor.tag);if(target!=null){int[] position=new int[2];target.getLocationInWindow(position);contentScroll.scrollTo(0,Math.max(0,contentScroll.getScrollY()+position[1]-anchor.y));}else contentScroll.scrollTo(0,scrollY);return true;}});
        lastRefresh=SystemClock.uptimeMillis();lastDataSignature=dataSignature();forceRefresh=false;allowFocusedRefresh=false;refreshPending=false;renderCount++;
    }
    void createShell(){
        root=column();root.setTag("app_shell");root.setBackgroundColor(BG);root.setFocusableInTouchMode(true);
        LinearLayout header=row();header.setPadding(dp(20),dp(18),dp(18),dp(12));LinearLayout names=column();headerDate=text("",10,MUTED,true);headerTitle=text("",28,INK,true);names.addView(headerDate);names.addView(headerTitle);header.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        Button add=button("＋",()->openEditor(-1,null,null));add.setTag("new_task_button");add.setTextSize(28);add.setTextColor(0xffffffff);add.setBackground(gradient(GREEN,0xff397dff,17));add.setElevation(dp(4));add.setContentDescription("Crear una tarea");header.addView(add,new LinearLayout.LayoutParams(dp(54),dp(54)));root.addView(header);
        contentScroll=new ScrollView(this);contentScroll.setFillViewport(true);contentScroll.setClipToPadding(false);body=column();body.setPadding(dp(16),dp(6),dp(16),dp(20));contentScroll.addView(body);root.addView(contentScroll,new LinearLayout.LayoutParams(-1,0,1));
        contentScroll.setOnTouchListener((v,e)->{if(e.getActionMasked()==MotionEvent.ACTION_DOWN)touching=true;else if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){touching=false;if(refreshPending)requestRefresh();}return false;});contentScroll.setOnScrollChangeListener((View v,int x,int y,int ox,int oy)->{lastScroll=SystemClock.uptimeMillis();if(refreshPending)requestRefresh();});
        nav=row();nav.setPadding(dp(7),dp(6),dp(7),dp(7));nav.setBackgroundColor(0xffffffff);String[] labels={"Agenda","Calendario","Revisar","Conexiones"};int[] icons={R.drawable.ic_nav_tasks,R.drawable.ic_nav_calendar,R.drawable.ic_nav_inbox,R.drawable.ic_nav_link};
        for(int n=0;n<4;n++){final int index=n;LinearLayout item=column();item.setGravity(Gravity.CENTER);item.setPadding(0,dp(5),0,dp(4));ImageView icon=new ImageView(this);icon.setImageResource(icons[n]);item.addView(icon,new LinearLayout.LayoutParams(dp(23),dp(23)));TextView label=text(labels[n],10,MUTED,false);label.setGravity(Gravity.CENTER);item.addView(label);item.setContentDescription(labels[n]);item.setFocusable(true);item.setOnClickListener(v->{if(page!=index){root.requestFocus();((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(root.getWindowToken(),0);page=index;render();}});nav.addView(item,new LinearLayout.LayoutParams(0,dp(56),1));}
        View line=new View(this);line.setBackgroundColor(STROKE);root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));root.addView(nav);setContentView(root);WindowLayout.apply(this,root);root.getViewTreeObserver().addOnGlobalFocusChangeListener((old,next)->{if(refreshPending&&!(next instanceof EditText))requestRefresh();});
    }
    void tasksPage(){
        List<Task> all=Store.get(this).all();int urgent=0,pending=0,done=0;
        for(Task t:all){String s=TaskLogic.status(t,System.currentTimeMillis());if(t.done)done++;else{pending++;if(s.equals("Urgente")||s.equals("Vencida"))urgent++;}}
        LinearLayout summary=card(body);summary.setBackground(gradient(0xffffffff,0xfff0f5ff,19));
        LinearLayout heading=row();LinearLayout title=column();title.addView(text(pending==0?"Todo en orden.":"Tu productividad",21,INK,true));
        gap(title,4);title.addView(text(done+" de "+all.size()+" actividades completadas",12,MUTED,false));
        heading.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView percent=text((all.isEmpty()?100:done*100/all.size())+"%",24,GREEN,true);
        percent.setGravity(Gravity.CENTER);percent.setBackground(outlined(PALE,40,0xffd2e1fe));heading.addView(percent,new LinearLayout.LayoutParams(dp(66),dp(66)));
        summary.addView(heading);gap(summary,12);
        ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(Math.max(1,all.size()));progress.setProgress(done);progress.setProgressTintList(ColorStateList.valueOf(GREEN));progress.setProgressBackgroundTintList(ColorStateList.valueOf(STROKE));summary.addView(progress,new LinearLayout.LayoutParams(-1,dp(5)));gap(summary,12);
        LinearLayout stats=row();stats.addView(statLabel("Pendientes",""+pending,MUTED),new LinearLayout.LayoutParams(0,-2,1));
        View pad=new View(this);stats.addView(pad,new LinearLayout.LayoutParams(dp(7),1));
        stats.addView(statLabel("Urgentes",""+urgent,RED),new LinearLayout.LayoutParams(0,-2,1));
        View pad2=new View(this);stats.addView(pad2,new LinearLayout.LayoutParams(dp(7),1));
        stats.addView(statLabel("Completadas",""+done,SUCCESS),new LinearLayout.LayoutParams(0,-2,1));summary.addView(stats);
        if(!Reminders.canNotify(this)||!Reminders.exact(this)){LinearLayout c=card(body);c.addView(text("Revisa tus avisos",15,INK,true));c.addView(text(!Reminders.canNotify(this)?"Activa las notificaciones en Conexiones para recibir recordatorios.":"Activa «Alarmas y recordatorios» para avisos a la hora elegida. Sin ese permiso, Android puede retrasarlos.",13,MUTED,false));c.addView(button("Ir a Conexiones",()->{page=3;render();}));}
        EditText search=input("Buscar en tus tareas",query,android.text.InputType.TYPE_CLASS_TEXT);search.setTag("task_search");search.setSingleLine(true);body.addView(search);gap(body,8);
        HorizontalScrollView horizontal=new HorizontalScrollView(this);horizontal.setHorizontalScrollBarEnabled(false);LinearLayout chips=row();
        String[] names={"Todas","Urgentes","Pendientes","Próximas","Hechas"};
        for(int j=0;j<names.length;j++){final int k=j;Button b=button(names[j],()->{filter=k;render();});b.setTextColor(j==filter?0xffffffff:MUTED);b.setBackground(rounded(j==filter?GREEN:0xffffffff,18));chips.addView(b);}
        horizontal.addView(chips);body.addView(horizontal);gap(body,8);
        taskList=column();body.addView(taskList);fillTasks(all,null);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int before,int count){query=s.toString();taskLimit=60;if(taskSearch!=null)handler.removeCallbacks(taskSearch);taskSearch=()->{if(page==0&&search.isAttachedToWindow())fillTasks(all,null);};handler.postDelayed(taskSearch,120);}public void afterTextChanged(Editable e){}});
        TextView guide=text("Urgente: hasta 48 h · Pendiente: hasta 7 días · Próxima: más de 7 días. La prioridad se actualiza con el tiempo.",11,MUTED,false);guide.setPadding(0,dp(10),0,0);body.addView(guide);
    }
    void fillTasks(List<Task> all,LocalDate date){
        taskList.removeAllViews();int count=0;long now=System.currentTimeMillis();
        for(Task t:all){
            String status=TaskLogic.status(t,now);
            if(date!=null&&(t.due<=0||!Instant.ofEpochMilli(t.due).atZone(ZoneId.systemDefault()).toLocalDate().equals(date)))continue;
            if(date==null){
                if(filter==1&&!(status.equals("Urgente")||status.equals("Vencida")))continue;
                if(filter==2&&!status.equals("Pendiente")&&!status.equals("Sin fecha"))continue;
                if(filter==3&&!status.equals("Próxima"))continue;
                if(filter==4&&!t.done)continue;
                if(!query.isEmpty()&&!(t.title+" "+t.notes).toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT)))continue;
            }
            if(count<taskLimit)taskCard(taskList,t);count++;
        }
        if(count>taskLimit)taskList.addView(button("Ver más tareas ("+(count-taskLimit)+")",()->{taskLimit+=60;fillTasks(all,date);}));
        if(count==0){LinearLayout c=card(taskList);gap(c,14);TextView empty=text(date==null?"Espacio para tus pendientes":"Este día está libre",20,INK,true);empty.setGravity(Gravity.CENTER);c.addView(empty);TextView msg=text(date==null?"Toca ＋ para crear tu primera tarea o comparte un mensaje para revisarlo.":"Toca ＋ para planificar una actividad.",14,MUTED,false);msg.setGravity(Gravity.CENTER);c.addView(msg);gap(c,14);}
    }
    void taskCard(LinearLayout parent,Task t){
        LinearLayout c=card(parent),top=row();c.setTag("task:"+t.id);CheckBox check=new CheckBox(this);check.setChecked(t.done);check.setButtonTintList(ColorStateList.valueOf(GREEN));check.setContentDescription("Completar "+t.title);top.addView(check,new LinearLayout.LayoutParams(dp(44),dp(48)));
        TextView title=text(t.title,17,t.done?MUTED:INK,true);title.setPadding(dp(4),0,0,0);if(t.done)title.setPaintFlags(title.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
        top.addView(title,new LinearLayout.LayoutParams(0,-2,1));c.addView(top);
        String status=TaskLogic.status(t,System.currentTimeMillis());boolean red=status.equals("Urgente")||status.equals("Vencida");
        TextView badge=text(status+((System.currentTimeMillis()-t.created<86400000L&&!t.done)?" · Nueva":""),11,t.done?SUCCESS:red?RED:GREEN,true);
        badge.setPadding(dp(9),dp(5),dp(9),dp(5));badge.setBackground(rounded(t.done?0xffe5f6ed:red?0xffffeeee:PALE,10));c.addView(badge);gap(c,8);
        if(t.done&&t.completedAt>0){long seconds=Math.max(0,(t.completedAt+TaskExpiryPolicy.RETENTION_MILLIS-System.currentTimeMillis())/1000L);c.addView(text("Se quitará de tu agenda en " + (seconds/60)+" min",11,MUTED,false));gap(c,5);}
        c.addView(text(TaskLogic.when(t.due),14,INK,false));if(!t.done)c.addView(text(TaskLogic.remaining(t.due,System.currentTimeMillis()),12,MUTED,false));
        if(!t.notes.isEmpty()){TextView notes=text(t.notes,13,MUTED,false);notes.setMaxLines(2);c.addView(notes);}
        LinearLayout actions=row();actions.addView(button("✎  Editar",()->openEditor(t.id,null,null)),new LinearLayout.LayoutParams(0,-2,1));actions.addView(button("♧  Compartir",()->shareTask(t)),new LinearLayout.LayoutParams(0,-2,1));c.addView(actions);
        check.setOnCheckedChangeListener((b,checked)->{t.done=checked;Store.get(this).save(t);if(t.done)Reminders.cancel(this,t.id);else Reminders.schedule(this,t);TaskWidget.refresh(this);render();});
    }
    void calendarPage(){
        LinearLayout c=card(body),line=row();
        Button prev=button("‹",()->{month=month.minusMonths(1);render();});line.addView(prev,new LinearLayout.LayoutParams(dp(48),dp(48)));
        TextView label=text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy",new Locale("es","PE"))),19,INK,true);label.setGravity(Gravity.CENTER);line.addView(label,new LinearLayout.LayoutParams(0,-2,1));line.addView(button("›",()->{month=month.plusMonths(1);render();}),new LinearLayout.LayoutParams(dp(48),dp(48)));c.addView(line);
        GridLayout grid=new GridLayout(this);grid.setColumnCount(7);String[] days={"L","M","X","J","V","S","D"};
        for(String s:days){TextView d=text(s,12,MUTED,true);d.setGravity(Gravity.CENTER);addCell(grid,d,30);}
        int offset=month.getDayOfWeek().getValue()-1;List<Task> all=Store.get(this).all();
        for(int i=0;i<offset;i++)addCell(grid,new View(this),46);
        for(int n=1;n<=month.lengthOfMonth();n++){
            LocalDate date=month.withDayOfMonth(n);boolean has=false;for(Task t:all)if(t.due>0&&!t.done&&Instant.ofEpochMilli(t.due).atZone(ZoneId.systemDefault()).toLocalDate().equals(date)){has=true;break;}
            TextView d=text(n+(has?"\n•":""),14,date.equals(selectedDay)?0xffffffff:INK,date.equals(LocalDate.now()));d.setGravity(Gravity.CENTER);d.setBackground(rounded(date.equals(selectedDay)?GREEN:date.equals(LocalDate.now())?PALE:0xffffffff,12));d.setContentDescription(date.toString()+(has?", con tareas":""));d.setOnClickListener(v->{selectedDay=date;render();});addCell(grid,d,46);
        }
        c.addView(grid);gap(c,10);c.addView(button("▣  Ir a hoy",()->{selectedDay=LocalDate.now();month=selectedDay.withDayOfMonth(1);render();}));
        subtitle(body,selectedDay.format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM",new Locale("es","PE"))));
        taskList=column();body.addView(taskList);fillTasks(all,selectedDay);
    }
    void addCell(GridLayout g,View v,int height){GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(height);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(dp(1),dp(1),dp(1),dp(1));g.addView(v,p);}
    void messagesPage(){
        LinearLayout info=card(body);info.addView(text("▤  Tú decides qué entra en tu agenda",19,INK,true));gap(info,6);info.addView(text("Aquí llegan las posibles actividades de los grupos autorizados. Revisa su mensaje y su fecha antes de guardarlas.",14,MUTED,false));
        LinearLayout options=row();options.addView(button("Mis grupos",()->{page=3;connectionTab=0;render();}),new LinearLayout.LayoutParams(0,-2,1));options.addView(button("Pegar texto",()->importText("","Texto pegado")),new LinearLayout.LayoutParams(0,-2,1));info.addView(options);
        List<Store.Inbox> inbox=Store.get(this).inbox();subtitle(body,"Propuestas pendientes · "+inbox.size());
        if(inbox.isEmpty()){
            LinearLayout empty=card(body);gap(empty,26);TextView illustration=text("✓",38,GREEN,true);illustration.setGravity(Gravity.CENTER);illustration.setBackground(rounded(PALE,50));
            LinearLayout center=row();center.setGravity(Gravity.CENTER);center.addView(illustration,new LinearLayout.LayoutParams(dp(82),dp(82)));empty.addView(center);gap(empty,15);
            TextView headline=text("Tu bandeja está al día",21,INK,true);headline.setGravity(Gravity.CENTER);empty.addView(headline);gap(empty,9);
            TextView infoText=text("Selecciona un grupo para revisar su historial disponible. Las preguntas y los comentarios casuales no generan propuestas por una palabra aislada.",13,MUTED,false);infoText.setGravity(Gravity.CENTER);empty.addView(infoText);gap(empty,24);
            LinearLayout tip=column();tip.setPadding(dp(12),dp(12),dp(12),dp(12));tip.setBackground(rounded(PALE,15));tip.addView(text("✦  Consejo",13,GREEN,true));gap(tip,5);tip.addView(text("Revisa periódicamente tus grupos autorizados para detectar nuevas actividades.",12,MUTED,false));empty.addView(tip);gap(empty,16);
        }
        int shown=0;
        for(Store.Inbox p:inbox){if(shown++>=inboxLimit)break;
            LinearLayout c=card(body);c.setTag("proposal:"+p.id);TextView badge=text(p.historical?"DEL HISTORIAL":"PARA REVISAR",10,GREEN,true);badge.setPadding(0,0,0,dp(7));c.addView(badge);
            c.addView(text(p.title,18,INK,true));gap(c,7);c.addView(text(p.source,12,MUTED,true));
            c.addView(text("Mensaje del "+Instant.ofEpochMilli(p.created).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("d MMM yyyy · h:mm a",new Locale("es","PE"))),11,MUTED,false));gap(c,8);
            c.addView(text(p.reason,13,p.due>0&&p.due<System.currentTimeMillis()?RED:MUTED,false));
            if(p.dateKnown){gap(c,6);c.addView(text("Fecha propuesta: "+(p.timeKnown?TaskLogic.when(p.due):Instant.ofEpochMilli(p.due).atZone(ZoneId.systemDefault()).toLocalDate().toString()),13,INK,true));}
            TextView original=text(p.original,13,MUTED,false);original.setTextIsSelectable(true);original.setVisibility(expandedProposals.contains(p.id)?View.VISIBLE:View.GONE);c.addView(button("Ver mensaje original",()->{boolean show=original.getVisibility()!=View.VISIBLE;if(show)expandedProposals.add(p.id);else expandedProposals.remove(p.id);original.setVisibility(show?View.VISIBLE:View.GONE);}));c.addView(original);
            LinearLayout actions=row();Button add=primaryButton("＋ Agregar",()->openEditor(-1,p,null));actions.addView(add,new LinearLayout.LayoutParams(0,-2,1));View space=new View(this);actions.addView(space,new LinearLayout.LayoutParams(dp(8),1));actions.addView(button("No agregar",()->{Store.get(this).dismiss(p.id);Reminders.cancelProposal(this,p.id);render();}),new LinearLayout.LayoutParams(0,-2,1));c.addView(actions);
        }
        if(inbox.size()>inboxLimit)body.addView(button("Ver más propuestas",()->{inboxLimit+=25;render();}));
    }
    void importText(String initial,String source){
        EditText text=input("Texto del mensaje",initial,android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);text.setMinLines(5);text.setMaxLines(12);text.setPadding(dp(18),dp(10),dp(18),dp(10));
        AlertDialog dialog=dialogBuilder().setTitle("Buscar actividades").setMessage("Revisa las propuestas: la interpretación por reglas puede requerir correcciones. Una actividad por línea ayuda a separarlas.").setView(text).setNegativeButton("Cancelar",null).setPositiveButton("Interpretar",null).create();
        dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{
            if(text.getText().toString().trim().isEmpty()){text.setError("Escribe o pega un mensaje.");return;}
            List<MessageParser.Proposal> proposals=MessageParser.parse(text.getText().toString(),System.currentTimeMillis(),ZoneId.systemDefault(),true);int n=0;
            for(MessageParser.Proposal p:proposals)if(Store.get(this).offer(p,source,System.currentTimeMillis()))n++;
            dialog.dismiss();page=2;render();toast(n+" propuesta(s) nuevas para revisar.");
        }));dialog.show();
    }
    void settingsPage(){
        LinearLayout tabs=row();String[] labels={"WhatsApp","Calendar","Avisos y widgets"};
        for(int n=0;n<3;n++){final int tab=n;Button b=button(labels[n],()->{connectionTab=tab;render();});b.setTextSize(12);b.setPadding(dp(3),0,dp(3),0);b.setMinWidth(0);b.setTextColor(tab==connectionTab?0xffffffff:MUTED);b.setBackground(rounded(tab==connectionTab?GREEN:0xffffffff,15));tabs.addView(b,new LinearLayout.LayoutParams(0,dp(50),1));}
        body.addView(tabs);gap(body,14);
        if(connectionTab==0){whatsappSettings();return;}if(connectionTab==1){calendarSettings();return;}
        LinearLayout alarm=card(body);alarm.addView(text("Recordatorios",20,INK,true));
        alarm.addView(text("Notificaciones: "+(Reminders.canNotify(this)?"activas":"pendientes de permiso")+"\nAlarmas exactas: "+(Reminders.exact(this)?"activas":"pendientes de permiso"),14,MUTED,false));
        alarm.addView(button("Activar o revisar notificaciones",this::notificationsPermission));
        alarm.addView(button("Alarmas y recordatorios",()->{if(Build.VERSION.SDK_INT>=31)safeStart(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));else toast("Este Android no requiere acceso especial para alarmas.");}));
        alarm.addView(button("Probar una notificación",()->{Task t=new Task();t.id=1900000000;t.title="Prueba de Agenda Clara";t.due=System.currentTimeMillis()+3600000;Reminders.showTask(this,t);toast(Reminders.canNotify(this)?"Se solicitó la notificación de prueba.":"Activa primero las notificaciones.");}));
        alarm.addView(text("Los avisos repetidos empiezan en la mayor anticipación que elijas y terminan al vencer. Android puede retrasar avisos sin acceso a alarmas exactas.",12,MUTED,false));
        LinearLayout widgets=card(body);widgets.addView(text("Widgets en tu pantalla de inicio",20,INK,true));widgets.addView(text("Lista de tareas con casillas y botón ＋, y una foto sin botones encima. Un doble toque abre sus opciones de imagen, zoom y encuadre. Mantén pulsado cada widget en el inicio para cambiar su tamaño.",14,MUTED,false));
        widgets.addView(button("Añadir widget de tareas",()->pinWidget(TaskWidget.class)));widgets.addView(button("Añadir widget de foto",()->pinWidget(PhotoWidget.class)));
        LinearLayout about=card(body);about.addView(text("Agenda Clara 1.3 · Diseño productividad",17,INK,true));about.addView(button("Licencias y código fuente",this::showLicenses));about.addView(text("Datos locales. Los permisos son opcionales. La interpretación se realiza en el teléfono. Las tareas vinculadas al calendario se escriben solo en el destino que elijas.",12,MUTED,false));
    }
    boolean notificationAccess(){
        String enabled=Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");
        String component=new ComponentName(this,WhatsAppListener.class).flattenToString();
        if(enabled!=null)for(String item:enabled.split(":"))if(component.equals(item))return true;return false;
    }
    void connectWhatsapp(){
        dialogBuilder().setTitle("Vincular notificaciones de WhatsApp")
            .setMessage("Android concede acceso amplio a las notificaciones. Agenda Clara filtra WhatsApp y WhatsApp Business. Solo interpreta mensajes nuevos de los chats que selecciones. Los chats se descubren por sus notificaciones; este permiso no entrega el historial ni el catálogo completo de WhatsApp.")
            .setNegativeButton("Volver",null).setPositiveButton("Continuar",(d,w)->{
                Prefs.get(this).edit().putBoolean("discover",true).putBoolean("capture",true).putLong("capture_since",System.currentTimeMillis()).apply();
                if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},32);
                else safeStart(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                sendBroadcast(new Intent(WhatsAppListener.REFRESH).setPackage(getPackageName()));render();
            }).show();
    }
    void session(String action,String value){if("consent".equals(action)&&!WhatsAppSessionService.running)return;try{WhatsAppSessionService.start(this,action,value);}catch(IllegalStateException|SecurityException e){toast("Abre la app y vuelve a iniciar la conexión.");}}
    void chooseHistoryCount(Store.Chat chat){
        if(!chat.selected||chat.jid.isEmpty()){toast("Autoriza primero la lectura del grupo.");return;}
        int[] counts=HistoryPageOptions.values();String[] labels=new String[counts.length];final int[] choice={HistoryPageOptions.saved(Prefs.get(this).getInt("wa_history_count",50))};int selected=counts.length-1;
        for(int n=0;n<counts.length;n++){labels[n]=counts[n]+" mensajes anteriores";if(counts[n]==choice[0])selected=n;}
        consentDialog=dialogBuilder().setTitle("Mensajes anteriores").setSingleChoiceItems(labels,selected,(d,n)->choice[0]=counts[n]).setNegativeButton("Volver",null).setPositiveButton("Solicitar",(d,w)->{
            Store.Chat current=Store.get(this).getChat(chat.key);if(current==null||!current.selected){toast("El permiso de lectura ya no está activo.");return;}
            Prefs.get(this).edit().putInt("wa_history_count",choice[0]).apply();try{WhatsAppSessionService.start(this,"more",chat.jid,choice[0]);toast("Solicitando "+choice[0]+" mensajes anteriores. La entrega depende de WhatsApp.");}catch(IllegalStateException|SecurityException e){toast("Abre la app y reanuda la conexión.");}render();
        }).show();consentDialog.getListView().setTag("history_page_options");
    }
    void linkWhatsapp(){
        dialogBuilder().setTitle("Vincular como dispositivo adicional")
            .setMessage("Esta conexión usa whatsmeow, un cliente no oficial. WhatsApp advierte que las conexiones no oficiales pueden causar restricciones de la cuenta.\n\nEl acceso del dispositivo vinculado es amplio. Pueden recibirse lotes de la cuenta; la app filtra los grupos que autorices antes de interpretar o guardar sus textos. Las claves de sesión se guardan en este teléfono. El historial puede ser parcial.\n\nDespués elegirás cada grupo y autorizarás su lectura. Guardar cada tarea requiere otra decisión tuya.")
            .setNegativeButton("Volver",null).setNeutralButton("Aviso de WhatsApp",(d,w)->safeStart(new Intent(Intent.ACTION_VIEW,Uri.parse("https://faq.whatsapp.com/1217634902127718/"))))
            .setPositiveButton("Entendido, continuar",(d,w)->{
                EditText phone=input("Código de país y número, por ejemplo 519…","",android.text.InputType.TYPE_CLASS_PHONE);phone.setSingleLine(true);phone.setPadding(dp(20),dp(12),dp(20),dp(12));
                AlertDialog dialog=dialogBuilder().setTitle("Vincular tu WhatsApp").setMessage("Escribe tu número con código de país. El código aparecerá aquí; se introduce en WhatsApp → Dispositivos vinculados → Vincular con número de teléfono. No es un código SMS.").setView(phone).setNegativeButton("Volver",null).setPositiveButton("Obtener código",null).create();
                dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{String number=phone.getText().toString().replaceAll("[^0-9]","");if(number.length()<8||number.length()>15){phone.setError("Incluye código de país y número.");return;}Prefs.get(this).edit().putBoolean("wa_link_consent_v1",true).putBoolean("capture",false).putBoolean("discover",false).putBoolean("wa_reading",true).remove("wa_pair_code").apply();notificationsPermission();session("pair",number);dialog.dismiss();render();}));dialog.show();
            }).show();
    }
    void chooseGroup(Store.Chat chat){
        if(chat.community){chatQuery=chat.title;chatLimit=40;render();toast("Elige los grupos de esta comunidad que quieres leer.");return;}
        if(chat.selected){consentDialog=dialogBuilder().setTitle("Dejar de leer este grupo").setMessage("Se quitarán los mensajes y propuestas de "+chat.title+" guardados por esta conexión. Tus tareas se conservarán.").setNegativeButton("Volver",null).setPositiveButton("Revocar lectura",(d,w)->{for(long id:Store.get(this).revokeReading(chat.key))Reminders.cancelProposal(this,id);session("consent",null);render();}).show();return;}
        if(!chat.joined){toast("WhatsApp muestra este subgrupo en la comunidad, pero no figura entre tus grupos con acceso. Únete desde WhatsApp y actualiza.");return;}
        consentDialog=dialogBuilder().setTitle("Permitir lectura de "+chat.title)
            .setMessage("Autorizas a Agenda Clara a leer e interpretar los mensajes disponibles y los nuevos de este grupo mientras la lectura esté activa. Se revisará el historial sincronizado del periodo elegido. Puedes revocar este permiso tocando de nuevo el grupo.\n\nEsto permite interpretar el chat. Cada posible tarea se propone para que tú la agregues y guardes.")
            .setNegativeButton("Volver",null).setPositiveButton("Permitir lectura",(d,w)->{Store.get(this).selectChat(chat.key,true);Prefs.get(this).edit().putBoolean("wa_reading",true).apply();if(!WhatsAppSessionService.running||!Prefs.get(this).getBoolean("wa_connected",false))session("resume",null);session("history",chat.jid);render();}).show();
    }
    void whatsappSettings(){
        SharedPreferences prefs=Prefs.get(this);boolean linked=prefs.getBoolean("wa_linked",false),connected=prefs.getBoolean("wa_connected",false)&&WhatsAppSessionService.running;
        List<Store.Chat> all=Store.get(this).chats(),chats=new ArrayList<>();int selected=0;for(Store.Chat c:all)if(!c.jid.isEmpty()){chats.add(c);if(c.selected)selected++;}
        LinearLayout hero=card(body);hero.setBackground(rounded(GREEN,22));hero.addView(text(connected?"Tus comunidades, a mano":"Conecta tus comunidades",23,0xffffffff,true));gap(hero,8);hero.addView(text("1  Vincula     2  Elige grupos     3  Revisa",12,0xffd8eadf,true));gap(hero,10);hero.addView(text(prefs.getString("wa_status","Consulta tus grupos sin esperar un mensaje nuevo."),14,0xffedf5ee,false));
        Button connect=button(linked?(connected?"Actualizar grupos":"Reanudar conexión"):"Vincular WhatsApp",()->{if(linked)session(connected?"groups":"resume",null);else linkWhatsapp();});hero.addView(connect);
        String code=prefs.getString("wa_pair_code","");if(!code.isEmpty()){
            LinearLayout pair=card(body);pair.addView(text(System.currentTimeMillis()<prefs.getLong("wa_pair_expires",0)?"Tu código de vinculación":"El código ha caducado",17,INK,true));TextView number=text(code,32,GREEN,true);number.setGravity(Gravity.CENTER);number.setTextIsSelectable(true);number.setPadding(0,dp(12),0,dp(12));pair.addView(number);pair.addView(text("En WhatsApp abre Dispositivos vinculados y elige vincular con número de teléfono. Introduce este código; después regresa aquí.",14,MUTED,false));pair.addView(button("Abrir WhatsApp",this::openWhatsapp));pair.addView(button("Solicitar otro código",this::linkWhatsapp));
        }
        if(linked){
            LinearLayout controls=card(body);Switch reading=new Switch(this);reading.setText("Lectura de grupos autorizados");reading.setTextColor(INK);reading.setMinHeight(dp(52));reading.setChecked(prefs.getBoolean("wa_reading",false));controls.addView(reading);reading.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("wa_reading",on).apply();session(on?"resume":"pause",null);});
            Switch notify=new Switch(this);notify.setText("Avisar de nuevas propuestas");notify.setTextColor(INK);notify.setMinHeight(dp(52));notify.setChecked(prefs.getBoolean("wa_notify",true));controls.addView(notify);notify.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("wa_notify",on).apply();if(on)notificationsPermission();});
            int days=prefs.getInt("wa_history_days",90);controls.addView(button("Historial: últimos "+days+" días",()->dialogBuilder().setTitle("Periodo para revisar").setItems(new String[]{"Últimos 30 días","Últimos 90 días","Último año"},(d,w)->{prefs.edit().putInt("wa_history_days",new int[]{30,90,365}[w]).apply();session("consent",null);render();}).show()));
            controls.addView(text("Se interpreta texto y pies de foto. No se descargan audios ni archivos. WhatsApp decide qué historial entrega; no equivale a todo el chat.",12,MUTED,false));
        }
        subtitle(body,"Mis grupos · "+selected+" autorizados");
        EditText search=input("Buscar comunidad o grupo",chatQuery,android.text.InputType.TYPE_CLASS_TEXT);search.setTag("group_search");search.setSingleLine(true);body.addView(search);gap(body,8);
        LinearLayout filters=row();filters.addView(button(communitiesOnly?"Ver todos":"Solo comunidades",()->{communitiesOnly=!communitiesOnly;chatLimit=40;render();}),new LinearLayout.LayoutParams(0,-2,1));filters.addView(button("Revisar propuestas",()->{page=2;render();}),new LinearLayout.LayoutParams(0,-2,1));body.addView(filters);gap(body,10);
        LinearLayout list=column();body.addView(list);fillChats(list,chats,chatQuery);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence t,int a,int c,int f){}public void onTextChanged(CharSequence t,int a,int before,int count){chatQuery=t.toString();chatLimit=40;if(groupSearch!=null)handler.removeCallbacks(groupSearch);groupSearch=()->{if(page==3&&connectionTab==0&&search.isAttachedToWindow())fillChats(list,chats,chatQuery);};handler.postDelayed(groupSearch,120);}public void afterTextChanged(Editable e){}});
        LinearLayout scope=card(body);scope.addView(text("Lectura con permiso, tareas con revisión",17,INK,true));gap(scope,6);scope.addView(text("El indicador de selección muestra el permiso para leer e interpretar el grupo. Agregar abre el editor; Guardar crea la tarea. El análisis local puede omitir mensajes o necesitar correcciones.",13,MUTED,false));
        if(linked)scope.addView(button("Desvincular y borrar mensajes locales",()->dialogBuilder().setTitle("Desvincular WhatsApp").setMessage("Se cerrará el dispositivo vinculado y se quitarán sus mensajes y propuestas locales. Tus tareas se conservarán. Necesitas conexión; también puedes revocar el dispositivo desde WhatsApp.").setNegativeButton("Volver",null).setPositiveButton("Desvincular",(d,w)->session("logout",null)).show()));
        scope.addView(button("Abrir WhatsApp",this::openWhatsapp));
        LinearLayout legacy=card(body);legacy.addView(text("Opción por notificaciones",16,INK,true));legacy.addView(text("Disponible como alternativa para mensajes nuevos. Este permiso no carga comunidades ni historial.",12,MUTED,false));legacy.addView(button("Configurar notificaciones de WhatsApp",this::connectWhatsapp));
        List<Store.Chat> detected=new ArrayList<>();for(Store.Chat c:all)if(c.jid.isEmpty())detected.add(c);
        if(!detected.isEmpty()){Switch capture=new Switch(this);capture.setText("Leer notificaciones de chats marcados");capture.setMinHeight(dp(52));capture.setChecked(prefs.getBoolean("capture",false));capture.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean("capture",on).putLong("capture_since",System.currentTimeMillis()).apply());legacy.addView(capture);for(Store.Chat c:detected){CheckBox check=new CheckBox(this);check.setText(c.title);check.setChecked(c.selected);check.setOnCheckedChangeListener((v,on)->Store.get(this).selectChat(c.key,on));legacy.addView(check);}}
    }
    void openWhatsapp(){Intent i=getPackageManager().getLaunchIntentForPackage("com.whatsapp");if(i==null)i=getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b");if(i==null)toast("No se encontró WhatsApp instalado.");else safeStart(i);}
    void fillChats(LinearLayout list,List<Store.Chat> chats,String query){
        list.removeAllViews();int visible=0;Map<String,String> communities=new HashMap<>();for(Store.Chat c:chats)if(c.community)communities.put(c.jid,c.title);
        Collections.sort(chats,(a,b)->{if(a.selected!=b.selected)return a.selected?-1:1;String pa=a.community?a.title:communities.getOrDefault(a.parent,"~"),pb=b.community?b.title:communities.getOrDefault(b.parent,"~");int cmp=pa.compareToIgnoreCase(pb);if(cmp!=0)return cmp;if(a.community!=b.community)return a.community?-1:1;return a.title.compareToIgnoreCase(b.title);});
        for(Store.Chat chat:chats){if(!chat.title.toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT))&&!communities.getOrDefault(chat.parent,"").toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT)))continue;if(communitiesOnly&&!chat.community&&chat.parent.isEmpty())continue;if(visible++>=chatLimit)continue;
            LinearLayout c=card(list);c.setTag("chat:"+chat.key);c.setBackground(outlined(chat.selected?0xfff0f5ff:0xffffffff,18,chat.selected?0xffbed2ff:STROKE));c.setPadding(dp(15),dp(14),dp(15),dp(14));
            LinearLayout title=row();TextView mark=text(chat.community?"›":chat.selected?"✓":"○",24,chat.selected?GREEN:MUTED,true);title.addView(mark,new LinearLayout.LayoutParams(dp(35),dp(38)));title.addView(text(chat.title,17,INK,true),new LinearLayout.LayoutParams(0,-2,1));c.addView(title);
            String category=chat.community?"COMUNIDAD · VER GRUPOS":chat.parent.isEmpty()?"GRUPO":communities.getOrDefault(chat.parent,"Comunidad")+" · Grupo";c.addView(text(category,10,GREEN,true));gap(c,5);c.addView(text(chat.community?"Selecciona los grupos de esta comunidad":chat.selected?"Lectura autorizada":chat.joined?"Toca para autorizar lectura":"Subgrupo visible · acceso no confirmado",12,MUTED,false));
            c.setContentDescription(chat.title+(chat.selected?", seleccionado":", no seleccionado"));title.setOnClickListener(v->chooseGroup(chat));c.setOnClickListener(v->chooseGroup(chat));
            if(chat.selected){
                if(!chat.scanState.isEmpty()){gap(c,6);c.addView(text(chat.scanState,12,MUTED,false));}
                gap(c,8);c.addView(primaryButton("◷  Revisar historial",()->session("history",chat.jid)));
                LinearLayout moreActions=row();
                Button more=button("☷  Mensajes · "+HistoryPageOptions.saved(Prefs.get(this).getInt("wa_history_count",50)),()->chooseHistoryCount(chat));more.setTag("history_more:"+chat.key);
                more.setTextSize(11);moreActions.addView(more,new LinearLayout.LayoutParams(0,-2,1));
                View space=new View(this);moreActions.addView(space,new LinearLayout.LayoutParams(dp(6),1));
                Button importBtn=button("⇧  Importar .txt",()->importHistory(chat));importBtn.setTextSize(11);moreActions.addView(importBtn,new LinearLayout.LayoutParams(0,-2,1));
                c.addView(moreActions);
                c.setOnLongClickListener(v->{chooseHistoryCount(chat);return true;});
            }
        }
        if(visible>chatLimit)list.addView(button("Ver más grupos",()->{chatLimit+=40;fillChats(list,chats,query);}));
        if(visible==0){LinearLayout c=card(list);c.addView(text(chats.isEmpty()?"Tus comunidades aparecerán aquí":"Sin coincidencias",19,INK,true));gap(c,7);c.addView(text(chats.isEmpty()?"Vincula tu cuenta para consultar la lista de grupos. No hace falta recibir un mensaje nuevo.":"Prueba con otro nombre o muestra todos los grupos.",14,MUTED,false));}
    }
    void importHistory(Store.Chat chat){
        if(!Prefs.get(this).getBoolean("wa_reading",false)){toast("Activa la lectura antes de interpretar un archivo de este grupo.");return;}
        dialogBuilder().setTitle("Importar historial de "+chat.title).setMessage("En WhatsApp exporta este chat sin archivos multimedia y elige su archivo .txt. Se conservarán las fechas originales. Se usa día/mes/año y la zona horaria de este teléfono. Se revisan hasta 4.000 mensajes dentro del periodo elegido. No se puede verificar que el archivo corresponda al grupo: elígelo con cuidado.").setNegativeButton("Volver",null).setPositiveButton("Elegir archivo",(d,w)->{pendingHistoryChat=chat.key;Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(pick,540);}).show();
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(request!=540||result!=RESULT_OK||data==null||data.getData()==null)return;
        final String key=pendingHistoryChat;pendingHistoryChat="";final Uri uri=data.getData();Store.Chat chat=Store.get(this).getChat(key);
        if(chat==null||!chat.selected||!Prefs.get(this).getBoolean("wa_reading",false)){toast("El grupo ya no tiene permiso de lectura.");return;}
        toast("Revisando el archivo del grupo…");new Thread(()->{
            try(java.io.InputStream stream=getContentResolver().openInputStream(uri)){
                if(stream==null)throw new java.io.IOException("No se pudo abrir el archivo.");
                List<ConversationAnalyzer.Message> messages=HistoryTextParser.parse(stream,ZoneId.systemDefault());int stored=0;long cutoff=System.currentTimeMillis()-Prefs.get(this).getInt("wa_history_days",90)*86400000L;
                for(ConversationAnalyzer.Message m:messages)if(m.time>=cutoff&&m.time<=System.currentTimeMillis()+60000L&&Store.get(this).recordMessage(key,m))stored++;
                int count=ReviewFlow.analyzeLinked(this,key,true,"");Store.get(this).scanState(key,stored+" mensajes del archivo · "+count+" propuestas nuevas");runOnUiThread(()->{toast(count+" propuestas nuevas. Revisa el contenido y las fechas.");render();});
            }catch(Exception e){runOnUiThread(()->toast(e.getMessage()==null?"No se pudo interpretar este archivo.":e.getMessage()));}
        },"import-group-history").start();
    }
    void calendarSettings(){
        LinearLayout info=card(body);info.addView(text("Google Calendar",20,INK,true));gap(info,8);info.addView(text("Usa los calendarios de tus cuentas sincronizadas en Android. Toca para elegir cuáles consultar y elige uno editable para tus nuevas tareas.",14,MUTED,false));
        info.addView(text(CalendarBridge.allowed(this)?"● Permisos concedidos":"○ Pendiente de permisos",13,GREEN,true));info.addView(button(CalendarBridge.allowed(this)?"Actualizar calendarios":"Conectar calendario",this::chooseCalendar));
        if(CalendarBridge.allowed(this))try{
            List<CalendarBridge.CalendarInfo> all=CalendarBridge.calendars(this);Set<String> selected=Prefs.calendars(this);
            if(all.isEmpty()){LinearLayout c=card(body);c.addView(text("Sin calendarios disponibles",17,INK,true));c.addView(text("Añade tu cuenta Google en Ajustes de Android, activa Calendario en la sincronización y vuelve aquí.",14,MUTED,false));c.addView(button("Abrir cuentas de Android",()->safeStart(new Intent(Settings.ACTION_SYNC_SETTINGS))));}
            for(CalendarBridge.CalendarInfo k:all){
                boolean active=selected.contains(""+k.id);LinearLayout c=card(body);c.setTag("calendar:"+k.id);c.setBackground(rounded(active?PALE:0xffffffff,18));
                c.addView(text((active?"✓  ":"○  ")+k.name,17,INK,true));gap(c,5);c.addView(text(k.account+(k.google?" · Google":" · Calendario Android")+(k.writable?"":" · Solo lectura"),12,MUTED,false));
                c.setOnClickListener(v->{Prefs.selectCalendar(this,k.id,!active);render();});
                if(k.writable)c.addView(button(Prefs.calendar(this)==k.id?"✓ Destino de nuevas tareas":"Usar para nuevas tareas",()->{Prefs.get(this).edit().putLong("calendar",k.id).putString("calendar_name",k.name+" · "+k.account).apply();Prefs.selectCalendar(this,k.id,true);render();}));
            }
            info.addView(text("Destino: "+Prefs.get(this).getString("calendar_name","Sin elegir"),13,GREEN,true));
        }catch(Exception e){info.addView(text("No se pudieron leer los calendarios. Revisa los permisos e inténtalo otra vez.",13,RED,false));}
        LinearLayout actions=card(body);actions.addView(button("Revisar eventos de calendarios elegidos",this::pickEvents));actions.addView(button("Enviar tareas vinculadas",()->background(()->CalendarBridge.sendAll(this))));
        actions.addView(text("Los eventos se añaden primero a Mensajes para revisarlos. La tarea solo se guarda con tu confirmación. El envío actualiza los eventos vinculados a la app; la sincronización con Google depende de Android.",13,MUTED,false));
    }
    void notificationsPermission(){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},31);
        else safeStart(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));
    }
    void safeStart(Intent i){try{startActivity(i);}catch(ActivityNotFoundException|SecurityException e){toast("Este ajuste no está disponible. Revísalo en Ajustes de Android.");}}
    interface Work{String run();}
    void background(Work work){toast("Procesando…");new Thread(()->{String result;try{result=work.run();}catch(Exception e){result="No se pudo completar la operación. Revisa los permisos y la cuenta del teléfono.";}final String value=result;runOnUiThread(()->{if(isFinishing())return;toast(value);render();});},"calendar-operation").start();}
    void chooseCalendar(){
        connectionTab=1;page=3;
        if(!CalendarBridge.allowed(this)){requestPermissions(new String[]{Manifest.permission.READ_CALENDAR,Manifest.permission.WRITE_CALENDAR},41);return;}render();
    }
    void pickEvents(){
        if(!CalendarBridge.allowed(this)){chooseCalendar();return;}
        if(Prefs.calendars(this).isEmpty()){toast("Selecciona al menos un calendario para consultar.");return;}
        new Thread(()->{
            try{List<CalendarBridge.Event> events=CalendarBridge.selectedEvents(this);runOnUiThread(()->{
                if(isFinishing())return;if(events.isEmpty()){toast("No hay eventos próximos en los calendarios elegidos.");return;}
                String[] labels=new String[events.size()];boolean[] selected=new boolean[events.size()];for(int j=0;j<labels.length;j++)labels[j]=events.get(j).toString();
                dialogBuilder().setTitle("Eventos para revisar").setMultiChoiceItems(labels,selected,(d,w,checked)->selected[w]=checked).setNegativeButton("Volver",null).setPositiveButton("Enviar a revisión",(d,w)->{
                    int count=0;for(int j=0;j<selected.length;j++)if(selected[j]){CalendarBridge.Event e=events.get(j);MessageParser.Proposal p=new MessageParser.Proposal();p.title=e.title;p.original=e.notes.isEmpty()?e.title:e.title+"\n"+e.notes;p.due=e.start;p.dateKnown=true;p.timeKnown=!e.allDay;p.reason=e.allDay?"Evento de día completo: elige la hora o fin del día.":"Confirma fecha y hora del evento antes de guardar.";
                        if(e.allDay)p.due=Instant.ofEpochMilli(e.start).atZone(ZoneOffset.UTC).toLocalDate().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
                        long id=Store.get(this).offerProposal(p,"Calendar · "+e.calendarName,System.currentTimeMillis(),"calendar:"+e.calendarId+":"+e.id+":"+e.start);if(id>0)count++;
                    }page=2;render();toast(count+" propuesta(s) nuevas para revisar.");
                }).show();
            });}catch(Exception e){runOnUiThread(()->toast("No se pudieron leer los eventos."));}
        },"calendar-events").start();
    }
    void pinWidget(Class<?> type){
        AppWidgetManager wm=AppWidgetManager.getInstance(this);
        if(Build.VERSION.SDK_INT>=26&&wm.isRequestPinAppWidgetSupported())wm.requestPinAppWidget(new ComponentName(this,type),null,null);
        else toast("Mantén pulsado el inicio → Widgets → Agenda Clara.");
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(request,permissions,grants);
        if(request==32)safeStart(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        if(request==41&&CalendarBridge.allowed(this))chooseCalendar();else if(request==41)toast("Puedes usar las tareas sin conectar el calendario.");
        if(root!=null)render();
    }
    void shareTask(Task t){
        String msg=t.title+(t.due>0?"\n"+TaskLogic.when(t.due):"")+(t.notes.isEmpty()?"":"\n"+t.notes);
        dialogBuilder().setTitle("Compartir tarea").setItems(new String[]{"WhatsApp","WhatsApp Business","Otras aplicaciones"},(d,n)->{
            Intent i=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,msg);
            if(n<2)i.setPackage(n==0?"com.whatsapp":"com.whatsapp.w4b");
            try{startActivity(n<2?i:Intent.createChooser(i,"Compartir tarea"));}catch(ActivityNotFoundException e){toast("Esa aplicación no está instalada.");}
        }).show();
    }
    void openEditor(long taskId,Store.Inbox proposal,Bundle draft){
        if(editor!=null&&editor.isShowing())return;
        Task existing=taskId>0?Store.get(this).find(taskId):null;
        if(taskId>0&&existing==null){toast("Esta tarea ya no está disponible.");return;}
        Task t=existing!=null?existing:new Task();
        if(proposal!=null){t.title=proposal.title;t.source=proposal.source;t.originKey=proposal.key;t.due=proposal.due;}
        if(draft!=null){t.title=draft.getString("title","");t.notes=draft.getString("notes","");t.source=draft.getString("source","");t.originKey=draft.getString("origin","");}
        LinearLayout box=column();box.setPadding(dp(18),dp(4),dp(18),dp(10));ScrollView scroll=new WindowLayout.DialogScroll(this);scroll.addView(box);
        EditText title=input("Nombre de la tarea",t.title,android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);title.setSingleLine(false);title.setMaxLines(3);box.addView(title);
        EditText notes=input("Notas (opcional)",t.notes,android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);notes.setMinLines(2);
        if(proposal!=null){box.addView(text(proposal.reason,12,MUTED,false));TextView original=text(proposal.original,13,MUTED,false);original.setVisibility(View.GONE);box.addView(button("Ver mensaje original",()->original.setVisibility(original.getVisibility()==View.GONE?View.VISIBLE:View.GONE)));box.addView(original);}
        CheckBox schedule=new CheckBox(this);schedule.setText("Con fecha y hora");schedule.setMinHeight(dp(48));schedule.setChecked(t.due>0||existing==null);box.addView(schedule);
        ZonedDateTime def=ZonedDateTime.now().plusHours(1).withSecond(0).withNano(0);
        if(page==1&&existing==null&&proposal==null)def=selectedDay.atTime(def.toLocalTime()).atZone(ZoneId.systemDefault());
        if(t.due>0)def=Instant.ofEpochMilli(t.due).atZone(ZoneId.systemDefault());
        final LocalDate[] date={def.toLocalDate()};final LocalTime[] time={def.toLocalTime()};
        final boolean[] dateSet={proposal==null||proposal.dateKnown},timeSet={proposal==null||proposal.timeKnown};
        if(draft!=null){date[0]=LocalDate.parse(draft.getString("date",date[0].toString()));time[0]=LocalTime.parse(draft.getString("time",time[0].toString()));dateSet[0]=draft.getBoolean("date_set");timeSet[0]=draft.getBoolean("time_set");schedule.setChecked(draft.getBoolean("schedule"));}
        LinearLayout dateSection=column();box.addView(dateSection);
        TextView dateSummary=text("",16,INK,true);dateSummary.setTag("date_summary");dateSection.addView(dateSummary);gap(dateSection,6);
        Button dateBtn=button("Otra fecha",()->{}),timeBtn=button("",()->{});timeBtn.setTag("choose_time");LinearLayout quick=row();dateSection.addView(quick);
        Button today=button("Hoy",()->{}),tomorrow=button("Mañana",()->{});
        for(Button b:new Button[]{today,tomorrow,dateBtn}){b.setMinWidth(0);b.setPadding(dp(5),0,dp(5),0);quick.addView(b,new LinearLayout.LayoutParams(0,-2,1));}
        dateSection.addView(timeBtn);
        Runnable refresh=()->{dateSummary.setText(dateSet[0]?date[0].format(DateTimeFormatter.ofPattern("EEEE d MMM yyyy",new Locale("es","PE"))):"Elige un día");dateSection.setVisibility(schedule.isChecked()?View.VISIBLE:View.GONE);timeBtn.setText(timeSet[0]?"Hora · "+time[0].format(DateTimeFormatter.ofPattern("h:mm a",new Locale("es","PE"))):"Elegir hora · reloj de 12 h");dateBtn.setEnabled(schedule.isChecked());timeBtn.setEnabled(schedule.isChecked());};
        today.setOnClickListener(v->{date[0]=LocalDate.now();dateSet[0]=true;refresh.run();});tomorrow.setOnClickListener(v->{date[0]=LocalDate.now().plusDays(1);dateSet[0]=true;refresh.run();});
        dateBtn.setOnClickListener(v->{DatePickerDialog picker=new DatePickerDialog(this,(p,y,m,d)->{date[0]=LocalDate.of(y,m+1,d);dateSet[0]=true;refresh.run();},date[0].getYear(),date[0].getMonthValue()-1,date[0].getDayOfMonth());picker.getDatePicker().setFirstDayOfWeek(Calendar.MONDAY);trackDialog(picker);picker.show();});
        timeBtn.setOnClickListener(v->{TimePickerDialog picker=new TimePickerDialog(this,android.R.style.Theme_Material_Light_Dialog_Alert,(p,h,m)->{time[0]=LocalTime.of(h,m);timeSet[0]=true;refresh.run();},time[0].getHour(),time[0].getMinute(),false);picker.setTitle("Hora · 12 horas");trackDialog(picker);picker.show();});
        dateSection.addView(button("Fin del día · 11:59 p. m.",()->{time[0]=LocalTime.of(23,59);timeSet[0]=true;refresh.run();}));
        schedule.setOnCheckedChangeListener((v,checked)->refresh.run());refresh.run();
        CheckBox urgent=new CheckBox(this);urgent.setText("Marcar urgente manualmente");urgent.setMinHeight(dp(48));urgent.setChecked(draft!=null?draft.getBoolean("urgent"):t.urgent);
        CheckBox done=new CheckBox(this);done.setText("Tarea completada");done.setMinHeight(dp(48));done.setChecked(draft!=null?draft.getBoolean("done"):t.done);
        subtitle(box,"Avisarme antes");
        final SortedSet<Integer> offsets=new TreeSet<>(Collections.reverseOrder());offsets.addAll(TaskLogic.offsets(draft!=null?draft.getString("offsets",t.offsets):t.offsets));
        LinearLayout chosen=column();box.addView(chosen);
        Button reminderButton=button("",()->{});box.addView(reminderButton);
        Runnable redraw=()->{List<String> labels=new ArrayList<>();for(int n:offsets)labels.add(TaskLogic.offsetName(n));reminderButton.setText(labels.isEmpty()?"Sin recordatorios · cambiar":android.text.TextUtils.join(" · ",labels)+" · cambiar");};redraw.run();
        reminderButton.setOnClickListener(v->{
            int[] values={0,15,30,60,180,720,1440,2880,4320,10080,20160,43200};String[] labels=new String[values.length];boolean[] selected=new boolean[values.length];SortedSet<Integer> pending=new TreeSet<>(offsets);
            for(int j=0;j<values.length;j++){labels[j]=TaskLogic.offsetName(values[j]);selected[j]=pending.contains(values[j]);}
            dialogBuilder().setTitle("¿Cuándo te aviso?").setMultiChoiceItems(labels,selected,(d,w,on)->{if(on)pending.add(values[w]);else pending.remove(values[w]);}).setNegativeButton("Volver",null).setPositiveButton("Listo",(d,w)->{offsets.clear();offsets.addAll(pending);redraw.run();})
            .setNeutralButton("Personalizar",(d,w)->{
                LinearLayout wrap=column();wrap.setPadding(dp(18),0,dp(18),0);EditText amount=input("Cantidad","3",android.text.InputType.TYPE_CLASS_NUMBER);wrap.addView(amount);Spinner unit=new Spinner(this);unit.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Minutos","Horas","Días","Semanas"}));unit.setSelection(2);wrap.addView(unit);
                AlertDialog custom=dialogBuilder().setTitle("Aviso personalizado").setView(wrap).setNegativeButton("Volver",null).setPositiveButton("Añadir",null).create();custom.setOnShowListener(a->custom.getButton(-1).setOnClickListener(b->{try{long n=Long.parseLong(amount.getText().toString())*new int[]{1,60,1440,10080}[unit.getSelectedItemPosition()];if(n<0||n>5256000)throw new NumberFormatException();offsets.add((int)n);redraw.run();custom.dismiss();}catch(NumberFormatException e){amount.setError("Usa una anticipación de hasta 10 años.");}}));custom.show();
            }).show();
        });
        LinearLayout advanced=column();advanced.setVisibility(View.GONE);
        box.addView(button("Más opciones · notas, prioridad y repetición",()->advanced.setVisibility(advanced.getVisibility()==View.GONE?View.VISIBLE:View.GONE)));box.addView(advanced);
        advanced.addView(notes);advanced.addView(urgent);if(existing!=null)advanced.addView(done);
        subtitle(advanced,"Repetir el aviso");
        Spinner repeat=new Spinner(this);String[] repetitions={"Solo en los avisos elegidos","Cada 30 minutos","Cada hora","Cada 3 horas","Cada 6 horas","Cada 12 horas","Cada día","Cada 2 días","Cada semana"};int[] intervals={0,30,60,180,360,720,1440,2880,10080};repeat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,repetitions));int rv=draft!=null?draft.getInt("repeat"):t.repeatMinutes;for(int j=0;j<intervals.length;j++)if(intervals[j]==rv)repeat.setSelection(j);advanced.addView(repeat);
        advanced.addView(text("Desde la mayor anticipación seleccionada hasta el vencimiento. Completar la tarea detiene los avisos.",12,MUTED,false));
        subtitle(advanced,"Duración del evento");
        EditText duration=input("Duración en minutos",""+(draft!=null?draft.getInt("duration",60):t.duration),android.text.InputType.TYPE_CLASS_NUMBER);advanced.addView(duration);
        CheckBox google=new CheckBox(this);google.setMinHeight(dp(48));google.setText("Vincular al calendario elegido");boolean available=CalendarBridge.allowed(this)&&Prefs.calendar(this)>0;google.setEnabled(available);google.setChecked(available&&(draft!=null?draft.getBoolean("google"):t.calendarEnabled));box.addView(google);
        if(!available)box.addView(text("Elige tu calendario en Conexiones para activar esta opción.",12,MUTED,false));
        editor=dialogBuilder().setTitle(existing==null?"Nueva tarea":"Editar tarea").setView(scroll).setNegativeButton("Volver",null).setPositiveButton("Guardar",null).create();
        if(existing!=null)editor.setButton(DialogInterface.BUTTON_NEUTRAL,"Borrar",(DialogInterface.OnClickListener)null);
        final long inboxId=proposal!=null?proposal.id:draft!=null?draft.getLong("inbox_id",-1):-1;
        captureDraft=()->{
            Bundle b=new Bundle();b.putLong("task_id",t.id);b.putLong("inbox_id",inboxId);b.putString("title",title.getText().toString());b.putString("notes",notes.getText().toString());b.putString("source",t.source);b.putString("origin",t.originKey);b.putBoolean("schedule",schedule.isChecked());b.putBoolean("date_set",dateSet[0]);b.putBoolean("time_set",timeSet[0]);b.putString("date",date[0].toString());b.putString("time",time[0].toString());b.putBoolean("urgent",urgent.isChecked());b.putBoolean("done",done.isChecked());b.putString("offsets",join(offsets));b.putInt("repeat",intervals[repeat.getSelectedItemPosition()]);b.putBoolean("google",google.isChecked());try{b.putInt("duration",Integer.parseInt(duration.getText().toString()));}catch(NumberFormatException e){b.putInt("duration",60);}restoreDraft=b;
        };
        editor.setOnDismissListener(d->{captureDraft=null;restoreDraft=null;editor=null;});
        editor.setOnShowListener(d->{
            editor.getButton(-1).setTag("task_save");editor.getButton(-2).setTag("task_cancel");title.setTag("task_title");
            if(existing!=null)editor.getButton(-3).setOnClickListener(v->dialogBuilder().setTitle("Borrar tarea").setMessage("Se borrará la tarea y se cancelarán sus avisos. Si tiene un evento de calendario, este se conservará.").setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(confirm,w)->{Reminders.cancel(this,t.id);Store.get(this).delete(t.id);TaskWidget.refresh(this);editor.dismiss();render();}).show());
            editor.getButton(-1).setOnClickListener(v->{
                String value=title.getText().toString().trim();if(value.isEmpty()){title.setError("Escribe un nombre.");return;}
                if(schedule.isChecked()&&(!dateSet[0]||!timeSet[0])){toast("Elige la fecha y la hora, o desactiva la programación.");return;}
                int minutes;try{minutes=Integer.parseInt(duration.getText().toString());if(minutes<5||minutes>1440)throw new NumberFormatException();}catch(NumberFormatException e){duration.setError("Entre 5 y 1440 minutos.");return;}
                t.title=value;t.notes=notes.getText().toString().trim();t.due=schedule.isChecked()?date[0].atTime(time[0]).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli():0;t.urgent=urgent.isChecked();t.done=done.isChecked();t.offsets=join(offsets);t.repeatMinutes=intervals[repeat.getSelectedItemPosition()];t.duration=minutes;t.calendarEnabled=google.isChecked()&&schedule.isChecked();
                if(t.calendarEnabled&&t.calendarId<0)t.calendarId=Prefs.calendar(this);
                try{if(inboxId>0){if(!Store.get(this).acceptProposal(t,inboxId)){toast("Esta propuesta ya fue atendida.");return;}}else Store.get(this).save(t);}catch(android.database.sqlite.SQLiteConstraintException e){toast("Esta propuesta ya fue convertida en tarea.");return;}
                if(inboxId>0)Reminders.cancelProposal(this,inboxId);if(t.done)Reminders.cancel(this,t.id);else Reminders.schedule(this,t);TaskWidget.refresh(this);editor.dismiss();render();
                if(t.calendarEnabled)background(()->{String result=CalendarBridge.upsert(this,t);return result.isEmpty()?"Tarea guardada y evento escrito en el calendario del teléfono.":result;});
                else toast(t.due>0&&t.due<System.currentTimeMillis()?"Tarea guardada con fecha vencida.":"Tarea guardada.");
            });
        });editor.show();editor.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }
    String join(Collection<Integer> offsets){StringBuilder b=new StringBuilder();for(int n:offsets){if(b.length()>0)b.append(',');b.append(n);}return b.toString();}
}
