package pe.agendaclara.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.TextRecognizer;
import java.io.File;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;

/** Standalone schedule UI preserving Agenda Clara 2.5's white/blue native visual language. */
public final class ScheduleActivity extends Activity {
    private static final int BG=UiDesign.BG,INK=UiDesign.INK,BLUE=UiDesign.BLUE,MUTED=UiDesign.MUTED,PALE=UiDesign.PALE,LINE=UiDesign.BORDER,RED=UiDesign.ERROR;
    private static final int CHOOSE_IMAGE=930,CAMERA=931,PERMISSION=932,EXPORT_ARCHIVE=933,IMPORT_ARCHIVE=934;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private LinearLayout root,body;private TextView title;private int page=0,dayFilter=1;
    private boolean displayList=false,displayGrid=true,recognizing=false;private char[] archivePassword;
    private Uri cameraImage;
    private ScheduleParser.Result detected;
    private boolean pendingNewPhotoSchedule=false;
    private String photoScheduleName="";
    private final ArrayList<Boolean> chosen=new ArrayList<>();
    private final String[] days={"Lun","Mar","Mié","Jue","Vie","Sáb","Dom"};
    private final int[] offsets={0,5,10,15,30,60};

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ScheduleDatabase db=ScheduleDatabase.get(this);db.ensureCategories();
        long requested=getIntent().getLongExtra("schedule_id",0);
        if(requested>0&&db.schedule(requested)!=null)db.setActive(requested);
        pendingNewPhotoSchedule=getIntent().getBooleanExtra("new_schedule_photo",false);
        show(pendingNewPhotoSchedule?1:0);
        if(getIntent().getBooleanExtra("open_new_schedule",false))
            root.post(()->promptScheduleName("",id->{show(0);editor(null,null);}));
    }
    @Override protected void onResume(){super.onResume();if(page==2||page==3)show(page);}
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
    private int dp(float px){return Math.round(getResources().getDisplayMetrics().density*px);}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private GradientDrawable outline(int color,int radius){GradientDrawable d=bg(color,radius);d.setStroke(dp(1),LINE);return d;}
    private LinearLayout col(){LinearLayout p=new LinearLayout(this);p.setOrientation(1);return p;}
    private LinearLayout row(){LinearLayout p=new LinearLayout(this);p.setOrientation(0);p.setGravity(Gravity.CENTER_VERTICAL);return p;}
    private void space(LinearLayout parent,int height){View s=new View(this);parent.addView(s,new LinearLayout.LayoutParams(1,dp(Math.max(8,height))));}
    private TextView txt(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(UiPreferences.scaled(this,size));t.setGravity(Gravity.CENTER_VERTICAL);UiDesign.text(t,bold);return t;}
    private Button btn(String caption,Runnable action,boolean primary){Button b=new Button(this);b.setAllCaps(false);b.setText(caption);b.setTextSize(UiPreferences.scaled(this,13));b.setTextColor(primary?0xffffffff:BLUE);UiDesign.button(b,primary);UiDesign.actionIcon(b,caption);b.setOnClickListener(v->action.run());return b;}
    private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(20),dp(20),dp(20),dp(20));UiDesign.card(c);LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);params.bottomMargin=dp(20);body.addView(c,params);return c;}
    private AlertDialog.Builder scheduleDialog(){
        return new AlertDialog.Builder(this,R.style.DialogTheme){
            @Override public AlertDialog.Builder setView(View view){
                if(view instanceof ScrollView)return super.setView(view);
                if(view.getParent()!=null)return super.setView(view);
                WindowLayout.DialogScroll wrapper=new WindowLayout.DialogScroll(ScheduleActivity.this);
                wrapper.addView(view);return super.setView(wrapper);
            }
            @Override public AlertDialog create(){
                AlertDialog dialog=super.create();
                dialog.getWindow().getDecorView().addOnAttachStateChangeListener(
                  new View.OnAttachStateChangeListener(){
                    public void onViewAttachedToWindow(View v){WindowLayout.boundDialog(ScheduleActivity.this,dialog);v.post(()->UiDesign.polishTree(v));}
                    public void onViewDetachedFromWindow(View v){}
                  });
                return dialog;
            }
        };
    }
    private void show(int screen){page=screen;root=col();root.setBackgroundColor(BG);
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        setContentView(root);applyScheduleInsets(root);root.post(()->UiDesign.polishTree(root));
        LinearLayout bar=row();bar.setPadding(dp(18),dp(14),dp(18),dp(14));bar.setBackgroundColor(BG);Button back=btn("‹",()->{if(page==0)finish();else show(0);},false);back.setText("");back.setContentDescription("Volver");
        android.graphics.drawable.Drawable backIcon=ApprovedPng.drawable(this,"back");
        backIcon.setBounds(0,0,dp(23),dp(23));
        back.setCompoundDrawables(null,backIcon,null,null);
        back.setGravity(Gravity.CENTER);
        bar.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));
        String[] titles={"Horario","Crear desde foto","Mi horario","Mis cursos","Recordatorios de clase","Horario detectado"};
        title=txt(titles[Math.max(0,Math.min(titles.length-1,screen))],21,INK,true);title.setGravity(Gravity.CENTER);bar.addView(title,new LinearLayout.LayoutParams(0,dp(50),1));
        Button help=btn("?",()->scheduleDialog().setTitle("Horario académico").setMessage("Crea clases manualmente o importa una foto. El reconocimiento se ejecuta en tu dispositivo y siempre revisas los datos antes de guardarlos.").setPositiveButton("Entendido",null).show(),false);help.setText("");help.setContentDescription("Ayuda del horario");
        android.graphics.drawable.Drawable helpIcon=ApprovedPng.drawable(this,"help");
        helpIcon.setBounds(0,0,dp(23),dp(23));
        help.setCompoundDrawables(null,helpIcon,null,null);
        help.setGravity(Gravity.CENTER);
        bar.addView(help,new LinearLayout.LayoutParams(dp(46),dp(48)));root.addView(bar);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(true);scroll.setVerticalFadingEdgeEnabled(true);scroll.setFadingEdgeLength(dp(18));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body=col();body.setPadding(dp(18),dp(16),dp(18),dp(38));scroll.addView(body);
        if(screen==0)home();else if(screen==1)photo();else if(screen==2)week();else if(screen==3)courseList();else if(screen==4)settings();else if(screen==5)review();
    }
    private void head(LinearLayout parent,String heading,String description){
        LinearLayout titleRow=row();
        String icon=heading.contains("foto")?"photo":
                    heading.contains("manual")?"manual":
                    heading.contains("recordatorio")?"bell":
                    heading.contains("curso")?"notes":"date";
        titleRow.addView(ModernGlyph.view(this,icon,ModernGlyph.BLUE,28),
            new LinearLayout.LayoutParams(dp(29),dp(29)));
        TextView headingText=txt(heading.replace("▣  ","").replace("✎  ",""),18,INK,true);
        LinearLayout.LayoutParams textParams=new LinearLayout.LayoutParams(0,-2,1);
        textParams.leftMargin=dp(10);titleRow.addView(headingText,textParams);
        parent.addView(titleRow);space(parent,10);
        parent.addView(txt(description,13,MUTED,false));
    }
    private void promptScheduleName(String suggestion,java.util.function.LongConsumer onCreated){
        ScheduleDatabase database=ScheduleDatabase.get(this);
        if(database.schedules().size()>=ScheduleDatabase.MAX_SCHEDULES){
            scheduleDialog().setTitle("Límite de horarios")
                .setMessage("Puedes tener un máximo de 10 horarios diferentes. Revisa los existentes antes de crear otro.")
                .setPositiveButton("Entendido",null).show();return;
        }
        LinearLayout panel=col();panel.setPadding(dp(17),dp(9),dp(17),dp(7));
        panel.addView(txt(suggestion.isEmpty()?"Escribe el nombre del nuevo horario.":
            "Nombre sugerido a partir de la foto. Confirma o edita antes de crear la categoría.",13,MUTED,false));
        space(panel,8);
        EditText name=field("Nombre del horario",suggestion,panel,false);
        AlertDialog dlg=scheduleDialog().setTitle("Confirmar nombre del horario")
            .setView(panel).setNegativeButton("Cancelar",null).setPositiveButton("Confirmar",null).create();
        dlg.setOnShowListener(v->dlg.getButton(-1).setOnClickListener(w->{
            String value=name.getText().toString().trim();
            if(value.length()<3||value.length()>28){name.setError("Utiliza entre 3 y 28 caracteres");return;}
            long id=database.create(value);
            if(id<1){name.setError("Ya existe una categoría u horario con ese nombre, o se alcanzó el límite.");return;}
            dlg.dismiss();toast("Horario y categoría creados: "+value);onCreated.accept(id);
        }));dlg.show();
    }
    private void renameCurrent(){
        ScheduleDatabase database=ScheduleDatabase.get(this);
        ScheduleDatabase.Timetable selected=database.schedule(database.activeId());
        if(selected==null)return;
        LinearLayout panel=col();panel.setPadding(dp(17),dp(9),dp(17),dp(7));
        EditText name=field("Nombre del horario y su categoría",selected.name,panel,false);
        AlertDialog dialog=scheduleDialog().setTitle("Cambiar nombre del horario")
            .setView(panel).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",null).create();
        dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(w->{
            if(!database.rename(selected.id,name.getText().toString())){
                name.setError("Nombre no válido o ya utilizado.");return;
            }
            dialog.dismiss();show(0);
        }));dialog.show();
    }
    private void deleteCurrent(){
        ScheduleDatabase db=ScheduleDatabase.get(this);
        ScheduleDatabase.Timetable selected=db.schedule(db.activeId());
        if(selected==null)return;
        if(db.schedules().size()<=1){toast("Debes conservar al menos un horario.");return;}
        int number=db.forSchedule(selected.id).size();
        scheduleDialog().setTitle("Eliminar horario y categoría")
            .setMessage("Se eliminará «"+selected.name+"» y sus "+number+
                " clases y avisos. Las tareas asociadas a la categoría pasarán a General sin ser borradas. Esta acción no se puede deshacer.")
            .setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(d,w)->{
                for(ScheduleEntry entry:db.forSchedule(selected.id))ScheduleReminders.cancel(this,entry.id);
                if(db.deleteSchedule(selected.id)){db.setActive(db.schedules().get(0).id);show(0);}
            }).show();
    }
    private void home(){
        ScheduleDatabase db=ScheduleDatabase.get(this);
        List<ScheduleDatabase.Timetable> all=db.schedules();
        ScheduleDatabase.Timetable active=db.schedule(db.activeId());
        LinearLayout overview=card();
        head(overview,"Tus horarios",all.size()+" de "+ScheduleDatabase.MAX_SCHEDULES+" horarios disponibles");
        space(overview,7);
        for(ScheduleDatabase.Timetable item:all){
            int count=db.forSchedule(item.id).size();
            overview.addView(btn((item.id==db.activeId()?"✓  ":"▣  ")+item.name+
                " · "+db.courses(item.id).size()+" cursos · "+count+" clases",()->{
                db.setActive(item.id);show(0);
            },item.id==db.activeId()));space(overview,7);
        }
        Button create=btn("＋  Nuevo horario",()->promptScheduleName("",id->show(0)),true);
        create.setEnabled(all.size()<ScheduleDatabase.MAX_SCHEDULES);overview.addView(create);
        space(overview,8);
        overview.addView(btn("Importar horario nuevo desde foto",()->{
            if(db.schedules().size()>=ScheduleDatabase.MAX_SCHEDULES){
                promptScheduleName("",id->show(0));return;
            }
            pendingNewPhotoSchedule=true;photoScheduleName="";show(1);
        },false));
        if(active==null)return;
        LinearLayout current=card();
        head(current,active.name,"Categoría académica: "+active.name);
        current.addView(txt("Los cursos de este horario están separados de los demás.",12,MUTED,false));space(current,9);
        for(ScheduleDatabase.Course course:db.courses(active.id)){
            current.addView(txt("• "+course.name,14,INK,true));space(current,5);
        }
        current.addView(btn("Ver horario completo",()->show(2),true));space(current,8);
        current.addView(btn("Añadir clase manualmente",()->editor(null,null),false));space(current,8);
        current.addView(btn("Importar clases desde foto a este horario",()->{
            pendingNewPhotoSchedule=false;photoScheduleName="";show(1);
        },false));space(current,8);
        current.addView(btn("Editar nombre del horario",this::renameCurrent,false));space(current,8);
        current.addView(btn("Mis cursos",()->show(3),false));
        body.addView(btn("⚑  Recordatorios de clase",()->show(4),false));
        space(body,8);body.addView(btn("Eliminar este horario",this::deleteCurrent,false));
    }
    private void photo(){
        LinearLayout c=card();head(c,"Selecciona o toma una foto","Admite imágenes y capturas de horarios impresos o digitales. No se envían a un servidor.");space(c,14);
        c.addView(txt("ETAPA 1 · Vista general  →  ETAPA 2 · Cursos  →  ETAPA 3 · Corroboración",12,BLUE,true));
        space(c,10);
        TextView symbol=txt("▧  Imagen del horario",20,BLUE,true);symbol.setGravity(Gravity.CENTER);symbol.setPadding(dp(14),dp(45),dp(14),dp(45));symbol.setBackground(outline(PALE,18));c.addView(symbol);space(c,14);
        c.addView(btn("▣  Elegir desde galería",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");startActivityForResult(i,CHOOSE_IMAGE);},true));space(c,9);
        c.addView(btn("◎  Tomar foto",this::takePhoto,false));
        LinearLayout tip=card();head(tip,"Para obtener mejores resultados","✓ Fotografía completa y bien iluminada\n✓ Días y horas claramente visibles\n✓ Si hay columnas complejas, revisa cada clase detectada\n✓ Nunca se guarda una clase sin tu confirmación");
    }
    private void takePhoto(){try{
        File folder=new File(getCacheDir(),"schedule_images");if(!folder.exists()&&!folder.mkdirs())throw new IllegalStateException("Carpeta no disponible");
        File file=new File(folder,"schedule_"+System.currentTimeMillis()+".jpg");cameraImage=FileProvider.getUriForFile(this,getPackageName()+".schedule_provider",file);
        Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT,cameraImage).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.setClipData(ClipData.newRawUri("foto de horario",cameraImage));
        if(intent.resolveActivity(getPackageManager())==null){toast("No hay una aplicación de cámara disponible.");return;}startActivityForResult(intent,CAMERA);
    }catch(Exception e){toast("No se pudo iniciar la cámara.");}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==EXPORT_ARCHIVE||request==IMPORT_ARCHIVE){
            final char[] pw=archivePassword;archivePassword=null;
            if(result==RESULT_OK&&data!=null&&data.getData()!=null&&pw!=null){Uri target=data.getData();io.execute(()->{
                try{int count=request==EXPORT_ARCHIVE?ScheduleBackup.exportEncrypted(this,target,pw):ScheduleBackup.importEncrypted(this,target,pw);
                    if(request==IMPORT_ARCHIVE)ScheduleReminders.rebuild(this);
                    runOnUiThread(()->{toast(request==EXPORT_ARCHIVE?"Clases respaldadas: "+count:"Clases restauradas: "+count);show(0);});
                }catch(Exception error){runOnUiThread(()->scheduleDialog().setTitle("No se pudo procesar la copia").setMessage("Comprueba la contraseña, el formato y la integridad del archivo.").setPositiveButton("Entendido",null).show());}
                finally{Arrays.fill(pw,'\0');}
            });}else if(pw!=null)Arrays.fill(pw,'\0');return;
        }
        if(result!=RESULT_OK)return;
        if(request==CHOOSE_IMAGE&&data!=null&&data.getData()!=null)recognize(data.getData());
        else if(request==CAMERA&&cameraImage!=null)recognize(cameraImage);
    }
    private void recognize(Uri uri){if(recognizing)return;recognizing=true;
        show(1);LinearLayout status=card();head(status,"Analizando tu horario…","Leyendo texto de la foto para encontrar días, cursos, horas y lugares.");space(status,16);
        ProgressBar progress=new ProgressBar(this);status.addView(progress);space(status,8);status.addView(txt("El reconocimiento se procesa en el teléfono; después revisarás cada resultado.",12,MUTED,false));
        io.execute(()->{
            try{
                SchedulePhotoLoader.Photo photo=SchedulePhotoLoader.readForLayout(this,uri);
                List<ScheduleGridInterpreter.Tile> rectangles=ScheduleImageBlocks.detect(photo.bitmap);
                int imageWidth=photo.bitmap.getWidth(),imageHeight=photo.bitmap.getHeight();
                runOnUiThread(()->{
                    if(isFinishing()||isDestroyed()){photo.bitmap.recycle();recognizing=false;return;}
                    TextRecognizer scanner=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                    scanner.process(photo.image).addOnSuccessListener(text->{
                        scanner.close();recognizing=false;
                        try{detected=ScheduleOcr.analyze(text,rectangles,imageWidth,imageHeight);
                            photoScheduleName=ScheduleNameDetector.suggest(text.getText());}
                        finally{if(!photo.bitmap.isRecycled())photo.bitmap.recycle();}
                        ScheduleCourseColors.align(detected.candidates,pendingNewPhotoSchedule?Collections.emptyList():ScheduleDatabase.get(this).forSchedule(ScheduleDatabase.get(this).activeId()));chosen.clear();for(int n=0;n<detected.candidates.size();n++)chosen.add(true);show(5);
                    }).addOnFailureListener(ex->{scanner.close();recognizing=false;if(!photo.bitmap.isRecycled())photo.bitmap.recycle();toast("No se pudo leer la imagen. Prueba con otra foto.");show(1);});
                });
            }catch(Exception e){runOnUiThread(()->{recognizing=false;toast("No se pudo abrir o procesar la imagen.");show(1);});}
        });
    }
    private void review(){LinearLayout top=card();
        head(top,"3/3 · Corroborar cursos","Las sesiones semanales no son cursos diferentes. Una misma materia puede aparecer varios días, con horas distintas.");
        if(detected!=null){
            top.addView(txt("Etapa 1 ✓ Vista general  ·  Etapa 2 ✓ Cursos por bloque  ·  Etapa 3 ◉ Confirmación",12,BLUE,true));
            space(top,8);
            top.addView(txt("Bloques: "+detected.candidates.size()+
                "  •  Nombres OCR: "+SchedulePhotoReview.courseEstimate(detected.candidates)+
                "  •  Cursos posibles: "+SchedulePhotoReview.provisionalEstimate(detected.candidates)+
                "  •  Confirma nombres repetidos antes de importar.",13,INK,true));
        }
        if(detected==null){top.addView(btn("Elegir imagen",()->show(1),true));return;}
        if(detected.candidates.isEmpty())top.addView(txt("No se han detectado clases completas. Puedes crearlas manualmente.",14,RED,false));
        Map<String,List<ScheduleEntry>> related=ScheduleCourseColors.groups(detected.candidates);
        for(int i=0;i<detected.candidates.size();i++){
            ScheduleEntry s=detected.candidates.get(i);final int index=i;LinearLayout c=card();
            int relatedCount=related.get(ScheduleCourseColors.identity(s.course)).size();
            if(relatedCount>1){TextView group=txt("▣  Mismo curso · "+relatedCount+" días/sesiones · color compartido",12,BLUE,true);c.addView(group);}
            View accent=new View(this);accent.setBackground(bg(s.color,8));c.addView(accent,new LinearLayout.LayoutParams(-1,dp(7)));space(c,6);

            CheckBox ok=new CheckBox(this);ok.setText(s.course);ok.setTextColor(INK);ok.setTextSize(16);ok.setChecked(chosen.get(i));ok.setButtonTintList(ColorStateList.valueOf(BLUE));ok.setOnCheckedChangeListener((b,checked)->chosen.set(index,checked));c.addView(ok);
            c.addView(txt(ScheduleEntry.dayName(s.day)+" · "+ScheduleEntry.clock(s.start)+"–"+ScheduleEntry.clock(s.end)+(s.room.isEmpty()?"":" · "+s.room),13,MUTED,false));
            c.addView(btn("✎  Editar día y hora de este bloque",()->editor(s,()->show(5)),false));
        }
        if(!detected.uncertain.isEmpty()){LinearLayout warning=card();head(warning,"Datos no confirmados","No se importaron "+detected.uncertain.size()+" líneas porque les faltaba información clara.");for(int i=0;i<Math.min(8,detected.uncertain.size());i++){space(warning,6);warning.addView(txt("• "+detected.uncertain.get(i),12,RED,false));}}
        body.addView(btn("Guardar clases seleccionadas",()->{
            ArrayList<ScheduleEntry> approved=new ArrayList<>();
            for(int i=0;i<detected.candidates.size();i++)if(chosen.get(i))
                approved.add(detected.candidates.get(i).copy());
            if(approved.isEmpty()){toast("Selecciona alguna clase o usa la creación manual.");return;}
            // 3. Corroboration requires explicit yes/no even for identical OCR course labels.
            confirmPhotoPairs(approved,new HashSet<Integer>(),()->{
                // Confirmed duplicate OCR rectangles are ONE session, but weekly
                // occurrences on different days remain separate sessions.
                List<ScheduleEntry> unique=SchedulePhotoReview.uniqueBlocks(approved);
                approved.clear();approved.addAll(unique);
                confirmConflicts(approved,()->{
                    Runnable save=()->{
                        ScheduleDatabase db=ScheduleDatabase.get(this);
                        for(ScheduleEntry entry:approved){entry.id=0;entry.scheduleId=db.activeId();}
                        ScheduleCourseColors.align(approved,db.forSchedule(db.activeId()));
                        int added=db.importReviewed(approved);
                        ScheduleReminders.rebuild(this);
                        toast("Bloques guardados: "+added+" · cursos: "+SchedulePhotoReview.courseEstimate(approved));
                        detected=null;pendingNewPhotoSchedule=false;photoScheduleName="";show(2);
                    };
                    if(pendingNewPhotoSchedule)promptScheduleName(photoScheduleName,id->save.run());
                    else save.run();
                });
            });
        },true));space(body,10);body.addView(btn("Agregar una clase manualmente",()->editor(null,null),false));
    }
    /** A quick yes/no confirmation for similar, truncated, or repeated OCR names. */
    private void confirmPhotoPairs(ArrayList<ScheduleEntry> approved,
                                    Set<Integer> confirmed,Runnable onComplete){
        SchedulePhotoReview.Pair pair=SchedulePhotoReview.nextPair(approved,confirmed);
        if(pair==null){onComplete.run();return;}
        ScheduleEntry first=approved.get(pair.earlier),second=approved.get(pair.later);
        String reason=pair.exact?"El nombre aparece más de una vez.":
            pair.relation==ScheduleCourseRecognition.Relation.TRUNCATED?
            "Una lectura parece ser una versión incompleta del otro nombre.":
            "Se detectó una posible diferencia de lectura (OCR).";
        LinearLayout panel=col();panel.setPadding(dp(16),dp(10),dp(16),dp(12));
        panel.addView(txt("¿Son el mismo curso?",18,INK,true));space(panel,8);
        panel.addView(txt(reason,13,MUTED,true));space(panel,12);
        panel.addView(txt("1. "+first.course+" · "+ScheduleEntry.dayName(first.day)+
            " "+ScheduleEntry.clock(first.start)+"–"+ScheduleEntry.clock(first.end),14,INK,true));
        space(panel,8);
        panel.addView(txt("2. "+second.course+" · "+ScheduleEntry.dayName(second.day)+
            " "+ScheduleEntry.clock(second.start)+"–"+ScheduleEntry.clock(second.end),14,INK,true));
        space(panel,12);
        panel.addView(txt("Sí: un curso con sus sesiones.  No: dos cursos distintos. "+
            "No se borra ninguna clase ni se cambian sus días u horas.",12,MUTED,true));
        space(panel,14);
        LinearLayout decisions=row();
        Button separate=btn("No · separados",()->{},false);
        Button together=btn("Sí · mismo curso",()->{},false);
        separate.setTextColor(0xffb52c48);together.setTextColor(0xff16784d);
        GradientDrawable red=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xffffe6ed,0xfffff7f9});red.setCornerRadius(dp(16));red.setStroke(dp(1),0xfff3aec0);
        GradientDrawable green=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xffddf9e8,0xfff2fff6});green.setCornerRadius(dp(16));green.setStroke(dp(1),0xffa6e5bd);
        separate.setBackground(red);together.setBackground(green);
        separate.setAllCaps(false);together.setAllCaps(false);
        separate.setTextSize(UiPreferences.scaled(this,12));
        together.setTextSize(UiPreferences.scaled(this,12));
        separate.setCompoundDrawablePadding(dp(6));together.setCompoundDrawablePadding(dp(6));
        android.graphics.drawable.Drawable remove=getDrawable(R.drawable.ic_course_separate);
        android.graphics.drawable.Drawable check=getDrawable(R.drawable.ic_course_merge);
        if(remove!=null){remove.setBounds(0,0,dp(24),dp(24));separate.setCompoundDrawablesRelative(remove,null,null,null);}
        if(check!=null){check.setBounds(0,0,dp(24),dp(24));together.setCompoundDrawablesRelative(check,null,null,null);}
        separate.setContentDescription("No, conservar como dos cursos distintos");
        together.setContentDescription("Sí, unir nombres en un curso sin cambiar las sesiones");
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(62),1);
        half.rightMargin=dp(8);decisions.addView(separate,half);
        decisions.addView(together,new LinearLayout.LayoutParams(0,dp(62),1));
        panel.addView(decisions);
        AlertDialog popup=scheduleDialog().setTitle("Corroboración de horarios")
            .setView(panel).setNegativeButton("Cancelar importación",null).create();
        separate.setOnClickListener(v->{
            SchedulePhotoReview.reject(approved,pair);
            confirmed.add(pair.later);popup.dismiss();
            confirmPhotoPairs(approved,confirmed,onComplete);
        });
        together.setOnClickListener(v->{
            SchedulePhotoReview.accept(approved,pair);
            confirmed.add(pair.later);popup.dismiss();
            confirmPhotoPairs(approved,confirmed,onComplete);
        });
        popup.show();
    }
    private void courseList(){List<ScheduleEntry> classes=ScheduleDatabase.get(this).forSchedule(ScheduleDatabase.get(this).activeId());LinearLayout bar=card();head(bar,"Mis cursos",classes.size()+" sesiones semanales");space(bar,10);bar.addView(btn("+ Agregar clase",()->editor(null,null),true));
        if(classes.isEmpty())return;
        for(Map.Entry<String,List<ScheduleEntry>> courseGroup:ScheduleCourseColors.groups(classes).entrySet()){
            List<ScheduleEntry> sessions=courseGroup.getValue();ScheduleEntry primary=sessions.get(0);
            LinearLayout banner=card();banner.setBackground(UiDesign.tintedBackground(this,primary.color,20,14));View colorBand=new View(this);colorBand.setBackground(bg(primary.color,9));banner.addView(colorBand,new LinearLayout.LayoutParams(-1,dp(7)));
            space(banner,8);banner.addView(txt(primary.course+" · "+sessions.size()+" "+(sessions.size()==1?"sesión":"sesiones"),16,INK,true));
            for(ScheduleEntry s:sessions){LinearLayout c=card();c.setPadding(dp(12),dp(14),dp(12),dp(14));
            c.setBackground(UiDesign.tintedBackground(this,s.color,20,14));LinearLayout r=row();View indicator=new View(this);indicator.setBackground(bg(s.color,6));r.addView(indicator,new LinearLayout.LayoutParams(dp(5),dp(66)));
            LinearLayout details=col();details.setPadding(dp(10),0,0,0);details.addView(txt(s.course,17,UiDesign.accentInk(s.color),true));details.addView(txt(ScheduleEntry.dayName(s.day)+" · "+ScheduleEntry.clock(s.start)+"–"+ScheduleEntry.clock(s.end)+(s.room.isEmpty()?"":" · "+s.room),12,MUTED,false));r.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            r.addView(btn("✎",()->editor(s,null),false),new LinearLayout.LayoutParams(dp(48),dp(48)));c.addView(r);
        }}
    }
    private void week(){List<ScheduleEntry> all=ScheduleDatabase.get(this).forSchedule(ScheduleDatabase.get(this).activeId());LinearLayout header=card();head(header,"Mi horario","Clases recurrentes · "+all.size()+" sesiones semanales");space(header,10);
        LinearLayout tabs=row();tabs.addView(btn("Cuadrícula",()->{displayGrid=true;displayList=false;show(2);},displayGrid),new LinearLayout.LayoutParams(0,dp(48),1));tabs.addView(btn("Día",()->{displayGrid=false;displayList=false;show(2);},!displayList&&!displayGrid),new LinearLayout.LayoutParams(0,dp(48),1));tabs.addView(btn("Lista",()->{displayList=true;displayGrid=false;show(2);},displayList),new LinearLayout.LayoutParams(0,dp(48),1));header.addView(tabs);
        if(displayGrid){showWeeklyGrid(all);body.addView(btn("+ Agregar clase",()->editor(null,null),true));return;}
        if(!displayList){space(header,12);LinearLayout daysRow=row();for(int i=1;i<=7;i++){final int d=i;Button item=btn(days[i-1],()->{dayFilter=d;show(2);},dayFilter==i);item.setTextSize(11);daysRow.addView(item,new LinearLayout.LayoutParams(0,dp(48),1));}header.addView(daysRow);}
        boolean any=false;
        for(ScheduleEntry s:all){if(!displayList&&s.day!=dayFilter)continue;any=true;LinearLayout item=card();item.setBackground(UiDesign.tintedBackground(this,s.color,20,16));LinearLayout r=row();View strip=new View(this);strip.setBackground(bg(s.color,5));r.addView(strip,new LinearLayout.LayoutParams(dp(6),dp(76)));LinearLayout content=col();content.setPadding(dp(12),0,0,0);content.addView(txt(s.course,18,UiDesign.accentInk(s.color),true));content.addView(txt((displayList?ScheduleEntry.dayName(s.day)+" · ":"")+ScheduleEntry.clock(s.start)+" – "+ScheduleEntry.clock(s.end),13,BLUE,true));content.addView(txt(s.room.isEmpty()?"Lugar no especificado":s.room,12,MUTED,false));r.addView(content,new LinearLayout.LayoutParams(0,-2,1));r.addView(btn("✎",()->editor(s,null),false),new LinearLayout.LayoutParams(dp(48),dp(48)));item.addView(r);}
        if(!any){LinearLayout empty=card();head(empty,displayList?"Sin clases todavía":"Día sin clases","Agrega una clase o importa una fotografía para empezar.");}
        body.addView(btn("+ Agregar clase",()->editor(null,null),true));space(body,10);body.addView(btn("⚑  Recordatorios",()->show(4),false));
    }
    private void settings(){LinearLayout c=card();head(c,"Recordatorios de clases","Avisos semanales antes de cada curso. Funcionan con el sistema de notificaciones de Android.");space(c,10);
        Switch enabled=new Switch(this);enabled.setText("Activar notificaciones del horario");enabled.setChecked(ScheduleReminders.active(this));enabled.setTextColor(INK);c.addView(enabled);
        enabled.setOnCheckedChangeListener((v,checked)->{getSharedPreferences("schedule_settings",0).edit().putBoolean("notifications",checked).apply();ScheduleReminders.rebuild(this);if(checked)notificationPermission();});
        space(c,15);c.addView(txt("Anticipación de cada clase",16,INK,true));space(c,5);c.addView(txt("Al crear o editar una clase puedes elegir 0, 5, 10, 15, 30 o 60 minutos antes de que comience.",13,MUTED,false));
        space(c,12);c.addView(txt("Sonido y vibración",16,INK,true));space(c,5);c.addView(txt("Para modificar el sonido o la vibración abre Ajustes de Android → Notificaciones → Agenda Clara → Horario.",13,MUTED,false));
        space(c,12);c.addView(btn("Abrir ajustes del canal",()->{Intent i=new Intent("android.settings.CHANNEL_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE",getPackageName()).putExtra("android.provider.extra.CHANNEL_ID","schedule_classes_v1");try{startActivity(i);}catch(Exception ignored){toast("Revisa los ajustes de notificaciones de Android.");}},false));
        LinearLayout tip=card();head(tip,"Avisos precisos","En algunos dispositivos Android, para recordar exactamente a la hora elegida deberás permitir alarmas exactas. Si no están autorizadas se utilizarán avisos aproximados.");space(tip,12);tip.addView(btn("Solicitar permiso de notificación",this::notificationPermission,false));
        LinearLayout check=card();head(check,"Diagnóstico de avisos",ScheduleReminders.diagnostic(this));space(check,12);
        check.addView(btn("Enviar notificación de prueba",()->toast(ScheduleReminders.showTest(this)?"Aviso de prueba enviado":"Activa el permiso de notificaciones y vuelve a intentarlo."),true));
        space(check,8);check.addView(btn("Actualizar diagnóstico",()->show(4),false));
        LinearLayout dates=card();head(dates,"Periodo académico","Puedes limitar los avisos a un semestre. Sin fechas, el horario se repite cada semana.");space(dates,12);
        android.content.SharedPreferences prefs=getSharedPreferences("schedule_settings",0);
        EditText semesterStart=field("Inicio (AAAA-MM-DD, opcional)",prefs.getString("semester_start",""),dates,false);
        EditText semesterEnd=field("Fin (AAAA-MM-DD, opcional)",prefs.getString("semester_end",""),dates,false);
        dates.addView(btn("Guardar período",()->{
            try{String a=semesterStart.getText().toString().trim(),b=semesterEnd.getText().toString().trim();
                LocalDate first=a.isEmpty()?null:LocalDate.parse(a),last=b.isEmpty()?null:LocalDate.parse(b);
                if(first!=null&&last!=null&&first.isAfter(last)){semesterEnd.setError("El fin debe ser posterior al inicio");return;}
                prefs.edit().putString("semester_start",a).putString("semester_end",b).apply();ScheduleReminders.rebuild(this);toast("Período guardado");show(4);
            }catch(Exception e){semesterStart.setError("Usa fechas AAAA-MM-DD válidas");}
        },true));
        LinearLayout backup=card();head(backup,"Copia de seguridad del horario","Archivo cifrado con contraseña. Incluye cursos, horas, aulas, docentes, recordatorios y período académico.");space(backup,12);
        backup.addView(btn("Exportar horario cifrado (.acbak)",()->archiveDialog(true),true));space(backup,8);
        backup.addView(btn("Restaurar horario cifrado (.acbak)",()->archiveDialog(false),false));
    }
    private void notificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},PERMISSION);}
    private EditText field(String label,String initial,LinearLayout parent,boolean multi){parent.addView(txt(label,13,INK,true));space(parent,5);EditText e=new EditText(this);e.setText(initial);e.setSingleLine(!multi);e.setTextSize(14);e.setPadding(dp(13),dp(11),dp(13),dp(11));e.setTextColor(INK);UiDesign.input(e);parent.addView(e,new LinearLayout.LayoutParams(-1,-2));space(parent,11);return e;}
    private void editor(ScheduleEntry previous,Runnable onDone){
        boolean importing=previous!=null&&previous.id==0;
        ScheduleEntry current=importing?previous:previous==null?new ScheduleEntry():previous.copy();
        if(!importing&&previous==null)current.scheduleId=ScheduleDatabase.get(this).activeId();
        LinearLayout form=col();form.setPadding(dp(18),dp(12),dp(18),dp(8));
        EditText course=field("Nombre del curso",current.course,form,false);
        form.addView(txt("Color del curso · 72 tonos rápidos + 360 tonos en catálogo",13,INK,true));space(form,7);
        final int[] color={current.color};final boolean[] manuallyColored={false};
        View colorPreview=new View(this);colorPreview.setBackground(bg(color[0],13));
        form.addView(colorPreview,new LinearLayout.LayoutParams(-1,dp(28)));space(form,8);
        android.widget.GridLayout palette=new android.widget.GridLayout(this);palette.setColumnCount(8);
        for(int shade:ScheduleCourseColors.palette()){
            View swatch=new View(this);GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(shade);
            circle.setStroke(dp(2),UiDesign.accentInk(shade));swatch.setBackground(circle);
            android.widget.GridLayout.LayoutParams params=new android.widget.GridLayout.LayoutParams();params.width=dp(29);params.height=dp(29);params.setMargins(dp(3),dp(3),dp(3),dp(3));palette.addView(swatch,params);
            swatch.setContentDescription("Usar color #"+String.format(Locale.ROOT,"%06X",shade&0xffffff));
            swatch.setOnClickListener(v->{color[0]=shade;manuallyColored[0]=true;colorPreview.setBackground(bg(shade,13));});
        }
        form.addView(palette);space(form,9);
        course.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){
                if(manuallyColored[0])return;
                Integer savedColor=ScheduleCourseColors.existingColor(s.toString(),ScheduleDatabase.get(ScheduleActivity.this).forSchedule(ScheduleDatabase.get(ScheduleActivity.this).activeId()));
                color[0]=savedColor!=null?savedColor:ScheduleCourseColors.deterministic(s.toString());
                colorPreview.setBackground(bg(color[0],13));
            }
            public void afterTextChanged(android.text.Editable e){}
        });
        form.addView(btn("Más colores · Mezclador HSV",()->colorMixer(color,manuallyColored,colorPreview),false));
        space(form,7);form.addView(btn("Explorar 360 colores · Pasteles, vivos, profundos y suaves",()->colorCatalog(color,manuallyColored,colorPreview),false));
        space(form,6);form.addView(txt("El mismo curso conservará este color en todos sus días.",12,MUTED,false));
        space(form,12);
        form.addView(txt("Días y horarios",16,INK,true));space(form,7);
        form.addView(txt("Cada día de este curso puede tener una hora distinta. Selecciona AM o PM en el inicio y el fin.",12,MUTED,true));
        space(form,9);
        final TreeMap<Integer,ScheduleDayClock.Slot> sessions=new TreeMap<>();
        final TreeMap<Integer,ScheduleDayClock.Slot> initial=new TreeMap<>();
        // Load ALL sessions of the chosen saved course, not merely this one day.
        // For a course with two blocks on a single day, only the clicked block is
        // editable here; the other record is never overwritten or deleted.
        if(current.id>0){
            for(ScheduleEntry existing:ScheduleDatabase.get(this).forSchedule(current.scheduleId)){
                if(ScheduleCourseColors.same(current.course,existing.course)){
                    ScheduleDayClock.Slot slot=new ScheduleDayClock.Slot(existing.day,existing.start,existing.end,existing.id);
                    if(!sessions.containsKey(existing.day)||existing.id==current.id)sessions.put(existing.day,slot);
                }
            }
        }
        sessions.put(current.day,new ScheduleDayClock.Slot(current.day,current.start,current.end,current.id));
        for(ScheduleDayClock.Slot slot:sessions.values())
            initial.put(slot.day,new ScheduleDayClock.Slot(slot.day,slot.start,slot.end,slot.id));
        LinearLayout dayRow=row(), dayCards=col();
        final Runnable[] redraw=new Runnable[1];
        redraw[0]=()->{
            dayRow.removeAllViews();dayCards.removeAllViews();
            String[] shortDays={"Lu","Mar","Mi","Ju","Vi","Sá","Do"};
            for(int i=1;i<=7;i++){
                final int d=i;
                TextView button=txt(shortDays[i-1],11,sessions.containsKey(i)?0xffffffff:BLUE,true);
                button.setGravity(Gravity.CENTER);button.setSingleLine(true);
                button.setBackground(sessions.containsKey(i)?bg(BLUE,12):outline(PALE,12));
                button.setContentDescription(ScheduleEntry.dayName(i)+(sessions.containsKey(i)?", seleccionado":", agregar día"));
                LinearLayout.LayoutParams dayChip=new LinearLayout.LayoutParams(0,dp(44),1);
                dayChip.setMargins(dp(2),0,dp(2),0);
                dayRow.addView(button,dayChip);
                button.setOnClickListener(v->{
                    if(!sessions.containsKey(d)){
                        sessions.put(d,new ScheduleDayClock.Slot(d,current.start,current.end,0));
                        redraw[0].run();
                    }else{
                        Toast.makeText(this,"Edita las horas de "+ScheduleEntry.dayName(d)+" debajo",Toast.LENGTH_SHORT).show();
                    }
                });
            }
            for(ScheduleDayClock.Slot slot:sessions.values()){
                LinearLayout card=col();card.setPadding(dp(12),dp(10),dp(12),dp(11));
                card.setBackground(outline(0xfff1f5ff,15));
                LinearLayout head=row();
                TextView dayLabel=txt(ScheduleEntry.dayName(slot.day),15,INK,true);
                head.addView(dayLabel,new LinearLayout.LayoutParams(0,dp(44),1));
                ImageButton remove=new ImageButton(this);
                remove.setImageResource(android.R.drawable.ic_menu_delete);
                remove.setImageTintList(ColorStateList.valueOf(RED));
                remove.setBackground(bg(0xfffceaf0,11));
                remove.setContentDescription("Quitar "+ScheduleEntry.dayName(slot.day));
                head.addView(remove,new LinearLayout.LayoutParams(dp(44),dp(44)));
                remove.setOnClickListener(v->{
                    if(sessions.size()<=1){toast("Añade otro día antes de quitar este.");return;}
                    sessions.remove(slot.day);redraw[0].run();
                });
                card.addView(head);
                float scale=getResources().getConfiguration().fontScale;
                boolean sideBySide=getResources().getDisplayMetrics().widthPixels/
                     getResources().getDisplayMetrics().density>=460&&scale<=1.15f;
                LinearLayout clocks=sideBySide?row():col();
                LinearLayout begin=timeChoice(slot,true,redraw[0]);
                LinearLayout finish=timeChoice(slot,false,redraw[0]);
                if(sideBySide){
                    LinearLayout.LayoutParams first=new LinearLayout.LayoutParams(0,-2,1);
                    first.rightMargin=dp(6);clocks.addView(begin,first);
                    clocks.addView(finish,new LinearLayout.LayoutParams(0,-2,1));
                }else{
                    clocks.addView(begin,new LinearLayout.LayoutParams(-1,-2));
                    clocks.addView(finish,new LinearLayout.LayoutParams(-1,-2));
                }
                card.addView(clocks);
                LinearLayout.LayoutParams cardSpace=new LinearLayout.LayoutParams(-1,-2);
                cardSpace.bottomMargin=dp(10);
                dayCards.addView(card,cardSpace);
            }
        };
        form.addView(dayRow);space(form,9);
        form.addView(dayCards);
        Button addDay=btn("＋  Agregar otro día",()->{
            ArrayList<String> labels=new ArrayList<>();ArrayList<Integer> indices=new ArrayList<>();
            for(int day=1;day<=7;day++)if(!sessions.containsKey(day)){
                labels.add(ScheduleEntry.dayName(day));indices.add(day);
            }
            if(labels.isEmpty()){toast("Ya están seleccionados los siete días.");return;}
            scheduleDialog().setTitle("Agregar día al curso")
                .setItems(labels.toArray(new String[0]),(which,n)->{
                    int day=indices.get(n);sessions.put(day,new ScheduleDayClock.Slot(day,current.start,current.end,0));
                    redraw[0].run();
                }).setNegativeButton("Cancelar",null).show();
        },false);
        form.addView(addDay,new LinearLayout.LayoutParams(-1,dp(52)));
        redraw[0].run();space(form,10);
        EditText room=field("Lugar / aula",current.room,form,false),teacher=field("Profesor (opcional)",current.teacher,form,false),notes=field("Notas (opcional)",current.notes,form,true);
        form.addView(txt("Avisar antes de la clase",13,INK,true));space(form,4);Spinner remind=new Spinner(this);String[] names={"Al comenzar","5 minutos antes","10 minutos antes","15 minutos antes","30 minutos antes","1 hora antes"};remind.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));int selectedReminder=2;for(int n=0;n<offsets.length;n++)if(offsets[n]==current.reminder)selectedReminder=n;remind.setSelection(selectedReminder);form.addView(remind);
        ScrollView scroll=new ScrollView(this);scroll.addView(form);
        AlertDialog dialog=scheduleDialog().setTitle(current.id>0?"Editar clase":importing?"Corregir clase reconocida":"Agregar clase")
          .setView(scroll).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",null).setNeutralButton(current.id>0?"Eliminar":"",null).create();
        dialog.setOnShowListener(ignored->{dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);dialog.getButton(-1).setOnClickListener(v->{
            if(course.getText().toString().trim().length()<3){course.setError("Indica el nombre del curso");return;}
            if(sessions.isEmpty()){toast("Selecciona al menos un día.");return;}
            ArrayList<ScheduleEntry> additions=new ArrayList<>();
            for(ScheduleDayClock.Slot slot:sessions.values()){
                if(!ScheduleDayClock.validInterval(slot.start,slot.end)){
                    toast("Revisa inicio y fin de "+ScheduleEntry.dayName(slot.day)+". El fin debe ser posterior al inicio, máximo 12 horas.");
                    return;
                }
                ScheduleEntry s=current.copy();s.id=slot.id;s.day=slot.day;
                s.start=slot.start;s.end=slot.end;
                s.scheduleId=ScheduleDatabase.get(this).activeId();
                s.course=course.getText().toString().trim();
                s.room=room.getText().toString().trim();
                s.teacher=teacher.getText().toString().trim();
                s.notes=notes.getText().toString().trim();
                s.color=color[0];s.reminder=offsets[remind.getSelectedItemPosition()];
                if(!ScheduleEntry.valid(s)){toast("Revisa los campos de "+ScheduleEntry.dayName(slot.day));return;}
                additions.add(s);
            }
            if(importing){
                if(detected!=null){
                    int index=detected.candidates.indexOf(previous);
                    if(index<0)index=detected.candidates.indexOf(current);
                    boolean checked=index>=0&&index<chosen.size()?chosen.get(index):true;
                    if(index>=0){detected.candidates.remove(index);if(index<chosen.size())chosen.remove(index);}
                    else index=detected.candidates.size();
                    for(ScheduleEntry s:additions){
                        s.id=0;
                        boolean duplicate=false;
                        for(ScheduleEntry other:detected.candidates)
                            if(other.day==s.day&&other.start==s.start&&other.end==s.end&&
                               ScheduleCourseColors.same(other.course,s.course)){duplicate=true;break;}
                        if(!duplicate){
                            detected.candidates.add(Math.min(index,detected.candidates.size()),s);
                            chosen.add(Math.min(index,chosen.size()),checked);index++;
                        }
                    }
                    ScheduleCourseColors.align(detected.candidates,ScheduleDatabase.get(this).forSchedule(ScheduleDatabase.get(this).activeId()));
                }else{
                    ScheduleEntry first=additions.get(0);
                    current.day=first.day;current.start=first.start;current.end=first.end;
                    current.course=first.course;current.room=first.room;
                    current.teacher=first.teacher;current.notes=first.notes;
                    current.color=first.color;current.reminder=first.reminder;
                }
                dialog.dismiss();if(onDone!=null)onDone.run();return;
            }
            HashSet<Long> removedIds=new HashSet<>();
            HashSet<Long> retainedIds=new HashSet<>();
            for(ScheduleEntry s:additions)if(s.id>0)retainedIds.add(s.id);
            for(ScheduleDayClock.Slot old:initial.values())
                if(old.id>0&&!retainedIds.contains(old.id))removedIds.add(old.id);
            ArrayList<ScheduleEntry> others=new ArrayList<>();
            for(ScheduleEntry old:ScheduleDatabase.get(this).forSchedule(current.scheduleId))
                if(!retainedIds.contains(old.id)&&!removedIds.contains(old.id))others.add(old);
            List<String> overlaps=ScheduleConflict.describe(additions,others);
            Runnable commit=()->{
                ScheduleDatabase db=ScheduleDatabase.get(this);
                for(long id:removedIds){ScheduleReminders.cancel(this,id);db.delete(id);}
                for(ScheduleEntry s:additions){
                    if(db.save(s))ScheduleReminders.schedule(this,s);
                    db.recolorSameCourse(s.course,s.color,s.scheduleId);
                }
                dialog.dismiss();notificationPermission();toast("Horarios del curso guardados");
                if(onDone!=null)onDone.run();else show(2);
            };
            Runnable confirmDeletions=()->{
                if(removedIds.isEmpty()){commit.run();return;}
                scheduleDialog().setTitle("Quitar días del curso")
                    .setMessage("Se eliminarán "+removedIds.size()+" sesión(es) semanal(es) y sus avisos. ¿Continuar?")
                    .setNegativeButton("Volver",null)
                    .setPositiveButton("Confirmar",(x,y)->commit.run()).show();
            };
            if(overlaps.isEmpty())confirmDeletions.run();
            else scheduleDialog().setTitle("Las clases se superponen")
                .setMessage(android.text.TextUtils.join("\n",overlaps.subList(0,Math.min(6,overlaps.size())))+
                            "\n\n¿Guardar de todas formas?")
                .setNegativeButton("Revisar",null)
                .setPositiveButton("Guardar igualmente",(x,y)->confirmDeletions.run()).show();
        });});dialog.show();
        if(current.id>0){dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->scheduleDialog().setTitle("Eliminar clase").setMessage("Se eliminará esta sesión semanal y su recordatorio.").setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(a,b)->{ScheduleReminders.cancel(this,current.id);ScheduleDatabase.get(this).delete(current.id);dialog.dismiss();show(3);}).show());}
    }
    /** One start/end field has its own time and independent AM/PM controls. */
    private LinearLayout timeChoice(ScheduleDayClock.Slot slot,boolean beginning,Runnable repaint){
        LinearLayout outer=col();
        outer.addView(txt(beginning?"Inicio":"Fin",12,INK,true));
        LinearLayout bar=row();bar.setPadding(dp(8),dp(4),dp(6),dp(4));
        bar.setBackground(outline(0xffffffff,12));
        int clock=beginning?slot.start:slot.end;
        TextView time=txt(ScheduleDayClock.clock12(clock),15,INK,true);
        time.setSingleLine(true);time.setGravity(Gravity.CENTER_VERTICAL);
        time.setContentDescription((beginning?"Hora de inicio de ":"Hora de fin de ")+
           ScheduleEntry.dayName(slot.day)+": "+ScheduleDayClock.display(clock)+". Tocar para cambiar");
        bar.addView(time,new LinearLayout.LayoutParams(0,dp(44),1));
        time.setOnClickListener(v->{
            int initial=beginning?slot.start:slot.end;
            new TimePickerDialog(this,(dialog,h,m)->{
                if(beginning)slot.start=h*60+m;else slot.end=h*60+m;
                repaint.run();
            },(initial%1440)/60,initial%60,false).show();
        });
        for(boolean pm:new boolean[]{false,true}){
            final boolean selected=ScheduleDayClock.isPm(clock)==pm;
            TextView toggle=txt(pm?"PM":"AM",11,selected?0xffffffff:BLUE,true);
            toggle.setSingleLine(true);toggle.setGravity(Gravity.CENTER);
            toggle.setBackground(selected?bg(BLUE,9):outline(PALE,9));
            toggle.setContentDescription((beginning?"Inicio":"Fin")+" "+ScheduleEntry.dayName(slot.day)+" "+(pm?"tarde/noche PM":"mañana AM"));
            LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(dp(44),dp(44));
            size.leftMargin=dp(3);bar.addView(toggle,size);
            toggle.setOnClickListener(v->{
                int prev=beginning?slot.start:slot.end;
                int minutes=ScheduleDayClock.withMeridiem(prev,pm);
                if(beginning)slot.start=minutes;else slot.end=minutes;
                repaint.run();
            });
        }
        outer.addView(bar,new LinearLayout.LayoutParams(-1,-2));
        return outer;
    }
    private void colorCatalog(int[] color,boolean[] manuallyColored,View preview){
        LinearLayout panel=col();panel.setPadding(dp(14),dp(8),dp(14),dp(10));
        panel.addView(txt("Catálogo completo sin conexión · 360 combinaciones",14,INK,true));
        panel.addView(txt("Selecciona un tono o escribe el HEX exacto.",12,MUTED,false));
        space(panel,10);
        EditText hex=new EditText(this);hex.setSingleLine(true);
        hex.setText(String.format(Locale.ROOT,"#%06X",color[0]&0xffffff));
        hex.setHint("#RRGGBB");panel.addView(hex);
        TextView sample=txt("Vista previa",14,ScheduleCourseColors.accessibleText(color[0]),true);
        sample.setGravity(Gravity.CENTER);sample.setPadding(dp(10),dp(10),dp(10),dp(10));
        sample.setBackground(bg(color[0],11));panel.addView(sample);
        int[] selected={color[0]};
        android.widget.ScrollView scroll=new android.widget.ScrollView(this);
        LinearLayout content=col();int[] spectrum=ScheduleColorSpectrum.palette();
        for(int family=0;family<ScheduleColorSpectrum.FAMILY_COUNT;family++){
            space(content,10);
            content.addView(txt(ScheduleColorSpectrum.familyTitle(family),14,INK,true));
            android.widget.GridLayout swatches=new android.widget.GridLayout(this);swatches.setColumnCount(8);
            for(int ix=family*ScheduleColorSpectrum.PER_FAMILY;ix<(family+1)*ScheduleColorSpectrum.PER_FAMILY;ix++){
                final int swatchColor=spectrum[ix];
                View chip=new View(this);
                GradientDrawable oval=new GradientDrawable();
                oval.setShape(GradientDrawable.OVAL);oval.setColor(swatchColor);
                oval.setStroke(dp(1),LINE);chip.setBackground(oval);
                android.widget.GridLayout.LayoutParams lp=new android.widget.GridLayout.LayoutParams();
                lp.width=dp(27);lp.height=dp(27);
                lp.setMargins(dp(3),dp(3),dp(3),dp(3));swatches.addView(chip,lp);
                chip.setContentDescription(String.format(Locale.ROOT,"Seleccionar #%06X",swatchColor&0xffffff));
                chip.setOnClickListener(v->{
                    selected[0]=swatchColor;
                    hex.setText(String.format(Locale.ROOT,"#%06X",swatchColor&0xffffff));
                    sample.setBackground(bg(swatchColor,11));
                    sample.setTextColor(ScheduleCourseColors.accessibleText(swatchColor));
                    sample.setText(String.format(Locale.ROOT,"#%06X",swatchColor&0xffffff));
                });
            }
            content.addView(swatches);
        }
        scroll.addView(content);
        panel.addView(scroll,new LinearLayout.LayoutParams(-1,dp(310)));
        AlertDialog dialog=scheduleDialog()
            .setTitle("Colores del horario")
            .setView(panel).setNegativeButton("Cancelar",null)
            .setPositiveButton("Aplicar",null).create();
        dialog.setOnShowListener(unused->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try{selected[0]=ScheduleColorSpectrum.parseHex(hex.getText().toString());}
            catch(IllegalArgumentException ex){hex.setError("Usa #RRGGBB");return;}
            color[0]=selected[0];manuallyColored[0]=true;
            preview.setBackground(bg(color[0],13));dialog.dismiss();
        }));
        dialog.show();
    }
    /** Mantiene el contenido interactivo debajo de la barra de estado en Android 15/16. */
    private void applyScheduleInsets(android.view.View root){
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root,(view,insets)->{
            androidx.core.graphics.Insets bars=insets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.systemBars());
            // Se desplaza el contenido únicamente si la ventana dibuja detrás de barras.
            view.setPadding(view.getPaddingLeft(),bars.top,
                view.getPaddingRight(),bars.bottom);
            return insets;
        });
        androidx.core.view.ViewCompat.requestApplyInsets(root);
    }
    private void colorMixer(int[] color,boolean[] manuallyColored,View preview){
        LinearLayout panel=col();panel.setPadding(dp(20),dp(12),dp(20),dp(8));
        TextView sample=txt("Vista previa del color",15,0xff101d43,true);sample.setGravity(Gravity.CENTER);sample.setPadding(dp(8),dp(10),dp(8),dp(10));panel.addView(sample);
        SeekBar hue=new SeekBar(this),sat=new SeekBar(this),brightness=new SeekBar(this);
        hue.setMax(359);sat.setMax(100);brightness.setMax(100);
        float[] hsv=new float[3];android.graphics.Color.colorToHSV(color[0],hsv);
        hue.setProgress((int)hsv[0]);sat.setProgress(Math.round(hsv[1]*100));brightness.setProgress(Math.round(hsv[2]*100));
        panel.addView(txt("Tono · 0–359°",13,INK,true));panel.addView(hue);
        panel.addView(txt("Saturación",13,INK,true));panel.addView(sat);
        panel.addView(txt("Brillo",13,INK,true));panel.addView(brightness);
        final int[] selected={color[0]};
        Runnable refresh=()->{selected[0]=ScheduleCourseColors.hsv(hue.getProgress(),sat.getProgress()/100f,brightness.getProgress()/100f);sample.setBackground(bg(selected[0],15));sample.setTextColor(ScheduleCourseColors.accessibleText(selected[0]));sample.setText(String.format(Locale.ROOT,"COLOR #%06X",selected[0]&0xffffff));};
        SeekBar.OnSeekBarChangeListener listener=new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar v,int p,boolean fromUser){refresh.run();}
            public void onStartTrackingTouch(SeekBar v){}public void onStopTrackingTouch(SeekBar v){}
        };
        hue.setOnSeekBarChangeListener(listener);sat.setOnSeekBarChangeListener(listener);brightness.setOnSeekBarChangeListener(listener);refresh.run();
        scheduleDialog().setTitle("Personalizar color del curso").setView(panel)
            .setNegativeButton("Cancelar",null).setPositiveButton("Aplicar",(d,w)->{color[0]=selected[0];manuallyColored[0]=true;preview.setBackground(bg(selected[0],13));}).show();
    }
    private void confirmConflicts(List<ScheduleEntry> proposed,Runnable proceed){
        List<String> overlaps=ScheduleConflict.describe(proposed,pendingNewPhotoSchedule?Collections.emptyList():ScheduleDatabase.get(this).forSchedule(ScheduleDatabase.get(this).activeId()));
        if(overlaps.isEmpty()){proceed.run();return;}
        String message=android.text.TextUtils.join("\n",overlaps.subList(0,Math.min(6,overlaps.size())));
        scheduleDialog().setTitle("Las clases se superponen").setMessage(message+"\n\n¿Guardar de todas formas?")
            .setNegativeButton("Revisar",null).setPositiveButton("Guardar igualmente",(d,w)->proceed.run()).show();
    }
    private void archiveDialog(boolean export){
        LinearLayout panel=col();panel.setPadding(dp(20),0,dp(20),0);
        EditText pw=new EditText(this);pw.setHint("Contraseña de 10 o más caracteres");pw.setInputType(129);panel.addView(pw);
        EditText repeat=null;if(export){repeat=new EditText(this);repeat.setHint("Repetir contraseña");repeat.setInputType(129);panel.addView(repeat);}
        final EditText confirm=repeat;
        AlertDialog dialog=scheduleDialog().setTitle(export?"Proteger copia de horario":"Abrir copia cifrada")
            .setMessage("La contraseña no se guarda en el teléfono. Sin ella no podrás recuperar la copia.")
            .setView(panel).setNegativeButton("Cancelar",null).setPositiveButton("Continuar",null).create();
        dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(w->{String text=pw.getText().toString();
            if(text.length()<10||text.length()>256){pw.setError("Usa entre 10 y 256 caracteres");return;}
            if(confirm!=null&&!text.equals(confirm.getText().toString())){confirm.setError("Las contraseñas no coinciden");return;}
            archivePassword=text.toCharArray();pw.setText("");if(confirm!=null)confirm.setText("");dialog.dismiss();
            Intent i=new Intent(export?Intent.ACTION_CREATE_DOCUMENT:Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/octet-stream");
            if(export)i.putExtra(Intent.EXTRA_TITLE,"Agenda-Clara-Horario.acbak");
            try{startActivityForResult(i,export?EXPORT_ARCHIVE:IMPORT_ARCHIVE);}catch(Exception e){Arrays.fill(archivePassword,'\0');archivePassword=null;toast("No hay gestor de archivos compatible");}
        }));dialog.show();
    }
    private void showWeeklyGrid(List<ScheduleEntry> entries){
        LinearLayout surface=card();head(surface,"Semana completa","Desliza hacia los lados y pulsa una clase para editarla.");space(surface,10);
        int first=7,last=20;for(ScheduleEntry s:entries){first=Math.min(first,s.start/60);last=Math.max(last,(s.end+59)/60);}
        first=Math.max(0,first);last=Math.min(24,last);final int beginning=first;
        final int hourHeight=dp(47),fullHeight=hourHeight*(last-first);
        HorizontalScrollView horizontal=new HorizontalScrollView(this);horizontal.setHorizontalScrollBarEnabled(true);
        LinearLayout chart=row();chart.setGravity(Gravity.TOP);horizontal.addView(chart);
        LinearLayout ruler=col();TextView spacer=txt("Hora",11,MUTED,true);spacer.setGravity(Gravity.CENTER);ruler.addView(spacer,new LinearLayout.LayoutParams(dp(43),dp(39)));
        FrameLayout marks=new FrameLayout(this);ruler.addView(marks,new LinearLayout.LayoutParams(dp(43),fullHeight));
        for(int h=first;h<last;h++){TextView t=txt(String.format(Locale.ROOT,"%02d:00",h),10,MUTED,false);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,dp(25));lp.topMargin=(h-first)*hourHeight;marks.addView(t,lp);}
        chart.addView(ruler);
        for(int d=1;d<=7;d++){
            final int day=d;LinearLayout col=col();col.setPadding(dp(2),0,dp(2),0);
            TextView heading=txt(days[d-1],12,INK,true);heading.setGravity(Gravity.CENTER);heading.setBackground(bg(PALE,8));col.addView(heading,new LinearLayout.LayoutParams(dp(95),dp(44)));
            FrameLayout canvas=new FrameLayout(this);canvas.setBackground(outline(0xfffbfcff,10));col.addView(canvas,new LinearLayout.LayoutParams(dp(95),fullHeight));
            for(int h=first;h<last;h++){View line=new View(this);line.setBackgroundColor(LINE);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,dp(1));lp.topMargin=(h-first)*hourHeight;canvas.addView(line,lp);}
            for(ScheduleEntry s:entries)if(s.day==day){
                int top=Math.round((s.start-beginning*60)*hourHeight/60f),height=Math.max(dp(28),Math.round((s.end-s.start)*hourHeight/60f));
                LinearLayout tile=col();tile.setPadding(dp(5),dp(4),dp(2),0);tile.setBackground(bg(s.color,7));
                TextView name=txt(s.course,11,INK,true);name.setMaxLines(2);name.setTextColor(ScheduleCourseColors.accessibleText(s.color));tile.addView(name);
                tile.addView(txt(ScheduleEntry.clock(s.start),10,ScheduleCourseColors.accessibleText(s.color),false));
                if(!s.room.isEmpty()){TextView room=txt(s.room,9,INK,false);room.setMaxLines(1);room.setTextColor(ScheduleCourseColors.accessibleText(s.color));tile.addView(room);}
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,height);lp.topMargin=top;lp.leftMargin=dp(2);lp.rightMargin=dp(2);
                canvas.addView(tile,lp);tile.setOnClickListener(v->editor(s,null));
                tile.setContentDescription(s.course+" · "+ScheduleEntry.dayName(day)+" · "+ScheduleEntry.clock(s.start)+" a "+ScheduleEntry.clock(s.end));
            }
            chart.addView(col);
        }
        surface.addView(horizontal);
    }
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
}
