#!/usr/bin/env python3
"""Entrega A: Calendario/Plan de estudio, 10 horarios y categorías por horario.
Safe, re-runnable source staging. Execute AFTER phase70 and BEFORE Gradle build.
Does not delete user data or run any database operation during repository builds.
"""
from pathlib import Path
import hashlib
import shutil

STAGE=Path(__file__).resolve().parent / 'src'
BASE=Path('AgendaClara/app/src/main/java/pe/agendaclara/app')
GRADLE=Path('AgendaClara/app/build.gradle')
EXPECTED={
 'ScheduleDatabase.java':'325e81607399289c186f82d83fddf6e9799f7232a2c4a807ccf02f6d572b21ae',
 'ScheduleEntry.java':'73e42c65a455f5e7e767d0a8ee37ee55c20b0b519f5d2749062755fbabd1df17',
 'CategoryRegistry.java':'220d3ac0da773fdb2784118b3db67afc51e151c3a06018878afd700f7dfcf1bf',
 'ScheduleActivity.java':'31230d633beed1c1e089a242225ff4f3db6f49b82a1c2569ee913fed11dec921',
 'ScheduleBackup.java':'f45a3e2f4876ce8375adb1b65d9b7e2d8c3f29a4e740f7cfe1f243f3183a2295',
 'MainActivity.java':'127143bb2d2f9fc0e3d4266c630cf9e9eb3820ea5081e97c7dddecdd08746fe8',
}
NEW=('CalendarStudyHub.java','ScheduleNameDetector.java')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run():
    if not BASE.is_dir() or not GRADLE.is_file():
        raise RuntimeError('Reconstruye el código Android 3.13.2 antes de la Entrega A')
    for name,expected in EXPECTED.items():
        path=BASE/name;source=STAGE/name
        if not source.is_file() or not path.is_file():raise RuntimeError('Falta fuente: '+name)
        if sha(path)!=expected and sha(path)!=sha(source):
            raise RuntimeError('Cambios no reconocidos, se evita sobrescribir: '+name)
    for name in NEW:
        path=BASE/name;source=STAGE/name
        if not source.is_file() or (path.exists() and sha(path)!=sha(source)):
            raise RuntimeError('Conflicto con clase nueva: '+name)
    gradle=GRADLE.read_text(encoding='utf-8')
    previous="versionCode 58", "versionName '3.13.2'"
    current="versionCode 59", "versionName '3.13.3'"
    if not all(x in gradle for x in previous) and not all(x in gradle for x in current):
        raise RuntimeError('Versión inesperada, no cambiar configuración de firma')
    if "applicationId 'pe.agendaclara.app'" not in gradle or 'signingConfig signingConfigs.development' not in gradle:
        raise RuntimeError('No se puede verificar identidad y firma de Agenda Clara')
    # All preflight checks pass; write changed source and change only the version.
    for name in tuple(EXPECTED)+NEW:
        target=BASE/name;source=STAGE/name
        if not target.exists() or sha(target)!=sha(source):shutil.copyfile(source,target)
    if all(x in gradle for x in previous):
        GRADLE.write_text(gradle.replace(previous[0],current[0],1).replace(previous[1],current[1],1),encoding='utf-8')
    print('PASS Entrega A: cambios instalados de forma idempotente, versión 3.13.3 (59)')
    print('PASS: paquete, firma y recursos originales intactos; migración SQLite v1 -> v2 no destructiva')

if __name__=='__main__':run()
