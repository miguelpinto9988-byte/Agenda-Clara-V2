package pe.agendaclara.app;
import android.content.*;
public final class ProposalReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        long id=i.getLongExtra("proposal_id",-1);if(id<=0)return;
        Store.get(c).dismiss(id);Reminders.cancelProposal(c,id);ReviewFlow.changed(c);
    }
}
