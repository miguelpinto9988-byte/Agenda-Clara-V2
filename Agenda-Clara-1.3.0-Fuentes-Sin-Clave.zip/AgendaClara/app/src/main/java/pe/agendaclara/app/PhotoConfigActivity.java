package pe.agendaclara.app;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;

public final class PhotoConfigActivity extends Activity {
    int id;Bitmap bitmap;ImageView preview;TextView note;float zoom=1,x=.5f,y=.5f;boolean contain=false;
    final Runnable updatePreview=()->{if(bitmap==null||isFinishing()||isDestroyed())return;int w=Math.min(800,Math.max(300,preview.getWidth()));preview.setImageBitmap(PhotoWidget.crop(bitmap,w,w*3/4,zoom,x,y,contain));};
    @Override public void onCreate(Bundle state){
        super.onCreate(state);setResult(RESULT_CANCELED);
        id=getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);
        AppWidgetProviderInfo info=AppWidgetManager.getInstance(this).getAppWidgetInfo(id);
        if(id==AppWidgetManager.INVALID_APPWIDGET_ID||info==null||!new ComponentName(this,PhotoWidget.class).equals(info.provider)){finish();return;}
        contain=Prefs.get(this).getBoolean("contain_"+id,false);zoom=Prefs.get(this).getFloat("zoom_"+id,1f);x=Prefs.get(this).getFloat("x_"+id,.5f);y=Prefs.get(this).getFloat("y_"+id,.5f);
        LinearLayout body=new LinearLayout(this);body.setOrientation(1);int pad=WindowLayout.dp(this,18);body.setPadding(pad,pad,pad,pad);body.setBackgroundColor(0xfff4f7ff);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(body);setContentView(scroll);WindowLayout.apply(this,scroll);
        TextView title=new TextView(this);title.setText("Tu foto, a tu medida");title.setTextSize(25);title.setTextColor(0xff101d43);body.addView(title);
        note=new TextView(this);note.setText("Toca la foto dos veces para volver aquí. Elige otra imagen o ajusta el zoom y el encuadre. Para cambiar el tamaño exterior, mantén pulsado el widget en el inicio.");note.setPadding(0,20,0,20);body.addView(note);
        preview=new ImageView(this);preview.setBackgroundColor(0xffe9f0ff);body.addView(preview,new LinearLayout.LayoutParams(-1,WindowLayout.dp(this,220)));
        Button choose=new Button(this);choose.setText("Cambiar imagen");body.addView(choose);
        choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,81);});
        CheckBox fit=new CheckBox(this);fit.setText("Mostrar imagen completa");fit.setChecked(contain);body.addView(fit);fit.setOnCheckedChangeListener((v,on)->{contain=on;refresh();});
        slider(body,"Zoom",0);slider(body,"Posición horizontal",1);slider(body,"Posición vertical",2);
        Button save=new Button(this);save.setText("Guardar widget");body.addView(save);
        save.setOnClickListener(v->save());
        File f=new File(getFilesDir(),PhotoWidget.filename(id));if(f.isFile()){bitmap=BitmapFactory.decodeFile(f.toString());refresh();}
    }
    private void slider(LinearLayout body,String title,int field){
        TextView t=new TextView(this);t.setText(title);body.addView(t);
        SeekBar bar=new SeekBar(this);bar.setMax(100);bar.setProgress((int)(field==0?(zoom-1)*50:field==1?x*100:y*100));body.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}
            public void onProgressChanged(SeekBar s,int n,boolean user){if(field==0)zoom=1+n/50f;else if(field==1)x=n/100f;else y=n/100f;refresh();}
        });
    }
    private void refresh(){if(bitmap==null)return;preview.removeCallbacks(updatePreview);preview.postOnAnimation(updatePreview);}
    @Override protected void onDestroy(){if(preview!=null)preview.removeCallbacks(updatePreview);super.onDestroy();}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(request!=81||result!=RESULT_OK||data==null||data.getData()==null)return;
        note.setText("Cargando imagen…");
        new Thread(()->{
            try{
                Bitmap b;
                if(Build.VERSION.SDK_INT>=28){
                    ImageDecoder.Source src=ImageDecoder.createSource(getContentResolver(),data.getData());
                    b=ImageDecoder.decodeBitmap(src,(decoder,info,source)->{
                        int w=info.getSize().getWidth(),h=info.getSize().getHeight();float s=Math.min(1f,1400f/Math.max(w,h));decoder.setTargetSize(Math.max(1,(int)(w*s)),Math.max(1,(int)(h*s)));decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                    });
                }else{
                    BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;
                    try(InputStream in=getContentResolver().openInputStream(data.getData())){BitmapFactory.decodeStream(in,null,options);}
                    options.inSampleSize=1;while(Math.max(options.outWidth,options.outHeight)/options.inSampleSize>1400)options.inSampleSize*=2;options.inJustDecodeBounds=false;
                    try(InputStream in=getContentResolver().openInputStream(data.getData())){b=BitmapFactory.decodeStream(in,null,options);}
                }
                if(b==null)throw new IOException("image");
                final Bitmap chosen=b;runOnUiThread(()->{if(isFinishing()||isDestroyed()){chosen.recycle();return;}bitmap=chosen;note.setText("Ajusta el zoom y la posición. La imagen se guarda dentro de la app.");refresh();});
            }catch(Exception|OutOfMemoryError e){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())note.setText("No se pudo abrir esta imagen. Elige otra.");});}
        },"photo-load").start();
    }
    private void save(){
        if(bitmap==null){Toast.makeText(this,"Elige una foto.",Toast.LENGTH_SHORT).show();return;}
        try(FileOutputStream out=new FileOutputStream(new File(getFilesDir(),PhotoWidget.filename(id)))){
            if(!bitmap.compress(Bitmap.CompressFormat.JPEG,90,out))throw new IOException("write");
            Prefs.get(this).edit().putFloat("zoom_"+id,zoom).putFloat("x_"+id,x).putFloat("y_"+id,y).putBoolean("contain_"+id,contain).apply();
            PhotoWidget.update(this,id);setResult(RESULT_OK,new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id));finish();
        }catch(IOException e){note.setText("No se pudo guardar la foto. Inténtalo de nuevo.");}
    }
}
