#!/usr/bin/env python3
import argparse
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument("--ecj", type=Path, required=True)
a = p.parse_args()
root = Path(__file__).resolve().parents[1]
out = root / "build/core-tests"
out.mkdir(parents=True, exist_ok=True)
src = root / "app/src/main/java/pe/agendaclara/app"
subprocess.run(["java", "-jar", str(a.ecj.resolve()), "-17", "-nowarn", "-encoding", "UTF-8",
                "-d", str(out), *[str(src / x) for x in ["Task.java", "TaskLogic.java", "MessageParser.java", "ActivityClassifier.java", "ConversationAnalyzer.java", "HistoryTextParser.java", "TextHash.java", "DoubleTapGate.java"]],
                str(root / "tests/CoreTests.java"), str(root / "tests/ConversationTests.java")], check=True)
for test in ["CoreTests", "ConversationTests"]:
    subprocess.run(["java", "-ea", "-cp", str(out), test], check=True)
