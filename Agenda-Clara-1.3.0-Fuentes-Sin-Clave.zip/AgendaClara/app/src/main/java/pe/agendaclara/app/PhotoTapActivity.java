package pe.agendaclara.app;

import android.app.*;
import android.appwidget.*;
import android.content.*;
import android.os.*;
import android.view.ViewConfiguration;

/** Direct Activity PendingIntent keeps widget launches compatible with Android restrictions. */
public final class PhotoTapActivity extends Activity {
    @Override public void onCreate(Bundle state){
        super.onCreate(state);overridePendingTransition(0,0);
        if(state!=null){finish();return;}
        handleTap(getIntent());
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);setIntent(intent);handleTap(intent);
    }
    private void handleTap(Intent intent){
        int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID);
        AppWidgetProviderInfo info=AppWidgetManager.getInstance(this).getAppWidgetInfo(id);
        if(info!=null&&new ComponentName(this,PhotoWidget.class).equals(info.provider)){
            long now=SystemClock.elapsedRealtime();String key="photo_tap_"+id;
            SharedPreferences prefs=Prefs.get(this);long previous=prefs.getLong(key,-1);
            // RemoteViews deliver clicks through activities, sometimes queued together.
            // Count distinct deliveries even in the same millisecond, with a forgiving window.
            int window=Math.max(900,ViewConfiguration.getDoubleTapTimeout());
            if(DoubleTapGate.completes(previous,now,window)){
                prefs.edit().remove(key).apply();
                startActivity(new Intent(this,PhotoConfigActivity.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }else prefs.edit().putLong(key,now).apply();
        }
        finish();overridePendingTransition(0,0);
    }
}
