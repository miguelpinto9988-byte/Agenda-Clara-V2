package pe.agendaclara.app;

public final class Task {
    public long id, due, created, completedAt, eventId=-1, calendarId=-1;
    public String title="", notes="", source="", originKey="", offsets="1440,60,0";
    public boolean done, urgent, calendarEnabled;
    public int duration=60, repeatMinutes=0;
}
