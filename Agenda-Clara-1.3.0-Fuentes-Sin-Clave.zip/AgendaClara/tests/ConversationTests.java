import pe.agendaclara.app.*;
import java.time.*;
import java.util.*;

public final class ConversationTests {
    static int checks;
    static ZoneId zone=ZoneId.of("America/Lima");
    static long now=ZonedDateTime.of(2026,10,21,8,0,0,0,zone).toInstant().toEpochMilli();
    static void check(boolean b,String label){checks++;if(!b)throw new AssertionError(label);}
    static ConversationAnalyzer.Message msg(String id,String body,long time,String sender){ConversationAnalyzer.Message m=new ConversationAnalyzer.Message();m.id=id;m.body=body;m.time=time;m.sender=sender;return m;}
    public static void main(String[] args)throws Exception{
        String[] negatives={"Trabajo","tarea","Pagar","Reunión","Hola, buenos días","¿Qué tarea tenemos mañana?","¿La reunión es mañana a las 5 pm?","Alguien sabe qué hay que entregar mañana","¿Podemos entregar el informe mañana?","Creo que hay examen mañana","Quizá entregar informe mañana a las 3 pm","Si puedes enviar el informe mañana","Me gusta ese proyecto para mañana","El trabajo de Juan está muy bonito","Hoy fui al trabajo","Nos vemos mañana en el trabajo","Estoy en el trabajo hasta mañana","Por fin terminé ese trabajo","Gracias por enviar el informe mañana","No hay examen mañana","Se cancela la reunión de mañana","Reunión cancelada mañana a las 5 pm","Ya envié el informe","Ya entregué el trabajo mañana a las 3 pm","Ya terminé la tarea","No tengo que entregar el informe mañana","La reunión fue el 20/10/2026","Me dijeron que la reunión de mañana es aburrida","El informe tiene una nueva fecha","Entrega realizada ayer","Mañana salí del trabajo a las 3 pm","El proyecto me parece interesante","Mañana es un buen día","Reunión mañana a las 3 pm, tal vez"};
        for(String s:negatives)check(MessageParser.parse(s,now,zone,false).isEmpty(),"No proposal for: "+s);
        String[] positives={"Entregar el informe mañana a las 3 pm","Enviar los archivos mañana a las 15:00","Reunión de equipo mañana a las 4 pm","Examen de química pasado mañana a las 10 am","Taller mañana a las 4 pm","Evento mañana a las 2 pm","Completar el formulario","Hay que leer la página cinco","Tienen que resolver los ejercicios mañana","Tengo que entregar el trabajo mañana","No olviden enviar el informe","Recuerden completar el formulario","La tarea consiste en leer el capítulo dos","Tarea: resolver los ejercicios del 1 al 5","Por favor manden la ficha mañana","Llevar calculadora mañana","La práctica será mañana a las 8 am","Mañana habrá un taller de lectura a las 3 pm","Vamos a reunirnos mañana a las 10 am","La fecha límite del proyecto es mañana","El pago vence el 23/10/2026","Para el viernes: entregar informe","Importante: revisar los documentos mañana","Tenemos reunión mañana a las 5 pm","La entrega del informe es mañana"};
        for(String s:positives)check(!MessageParser.parse(s,now,zone,false).isEmpty(),"Proposal for: "+s);
        long old=now-40*86400000L;
        ConversationAnalyzer.Message original=msg("a","Entregar informe mañana a las 3 pm",old,"profesor");
        List<ConversationAnalyzer.Finding> found=ConversationAnalyzer.analyze(Arrays.asList(original),zone,now);
        check(found.size()==1,"Historical instruction retained");
        check(Instant.ofEpochMilli(found.get(0).proposal.due).atZone(zone).toLocalDate().equals(Instant.ofEpochMilli(old).atZone(zone).toLocalDate().plusDays(1)),"Tomorrow is relative to original timestamp");
        check(found.get(0).proposal.reason.contains("Fecha pasada"),"Past date is unconfirmed, not presumed pending");
        ConversationAnalyzer.Message cancel=msg("b","Se cancela esa entrega",old+60000,"profesor");cancel.reply="a";
        check(ConversationAnalyzer.analyze(Arrays.asList(original,cancel),zone,now).isEmpty(),"Explicit quoted cancellation suppresses historical suggestion");
        ConversationAnalyzer.Message other=msg("c","Ya entregué el informe",old+60000,"otro alumno");other.reply="a";
        found=ConversationAnalyzer.analyze(Arrays.asList(original,other),zone,now);check(found.size()==1&&found.get(0).proposal.reason.contains("Otro miembro"),"Another member's completion does not complete user's assignment");
        other.fromMe=true;check(ConversationAnalyzer.analyze(Arrays.asList(original,other),zone,now).isEmpty(),"User's own quoted completion suppresses proposal");
        ConversationAnalyzer.Message update=msg("d","Hasta mañana a las 5 pm",now,"profesor");update.reply="a";update.quoted=original.body;
        found=ConversationAnalyzer.analyze(Arrays.asList(original,update),zone,now);check(found.size()==1,"Quoted schedule update replaces rather than duplicates suggestion");
        check(found.get(0).key.equals("a:0"),"Quoted update preserves proposal origin");
        check(Instant.ofEpochMilli(found.get(0).proposal.due).atZone(zone).getHour()==17,"Quoted update uses the new time");
        List<MessageParser.Proposal> multiline=MessageParser.parse("Entregar el informe\nHasta mañana a las 3 pm",now,zone,false);
        check(multiline.size()==1&&multiline.get(0).dateKnown&&multiline.get(0).timeKnown,"Date in continuation belongs to instruction");
        String export="21/10/2026, 08:00 - Profesor: Entregar el informe\nHasta mañana a las 3 pm\n21/10/2026, 08:02 - Los mensajes están cifrados.\n[21/10/26, 9:30:00 p. m.] Ana: ¿Qué tarea tenemos?\n21/10/2026, 22:00 - Ana: Gracias";
        List<ConversationAnalyzer.Message> imported=HistoryTextParser.parse(new java.io.ByteArrayInputStream(export.getBytes(java.nio.charset.StandardCharsets.UTF_8)),zone);
        check(imported.size()==3,"Android and iOS messages imported; system notice ignored");
        check(imported.get(0).body.contains("Hasta mañana"),"Multiline body preserved");
        check(Instant.ofEpochMilli(imported.get(1).time).atZone(zone).getHour()==21,"iOS dotted p. m. parsed");
        check(imported.get(0).id.equals(HistoryTextParser.parse(new java.io.ByteArrayInputStream(export.getBytes(java.nio.charset.StandardCharsets.UTF_8)),zone).get(0).id),"Repeated export has stable identity");
        check(ConversationAnalyzer.analyze(imported,zone,now).size()==1,"Imported casual and question messages excluded");
        byte[] huge=new byte[8*1024*1024+1];boolean rejected=false;try{HistoryTextParser.parse(new java.io.ByteArrayInputStream(huge),zone);}catch(java.io.IOException expected){rejected=true;}check(rejected,"Import size is bounded");
        long start=System.nanoTime();List<ConversationAnalyzer.Message> many=new ArrayList<>();for(int j=0;j<4000;j++)many.add(msg("m"+j,j%10==0?"Entregar informe mañana a las 3 pm":"Gracias, buenos días",old+j*1000L,"profesor"));
        found=ConversationAnalyzer.analyze(many,zone,now);long elapsed=(System.nanoTime()-start)/1000000;
        check(found.size()==400,"Bounded 4000-message synthetic history analyzed");
        System.out.println("{\"checks\":"+checks+",\"passed\":"+checks+",\"failed\":0,\"synthetic_history_messages\":4000,\"elapsed_ms\":"+elapsed+",\"scope\":\"Local rules and quoted context, synthetic data only\"}");
    }
}
